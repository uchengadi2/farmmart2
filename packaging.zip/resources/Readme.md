# ext-theme-neptune-81693c0e-72b3-45aa-a120-5aea5fdb44bb/resources

This folder contains static resources (typically an `"images"` folder as well).
