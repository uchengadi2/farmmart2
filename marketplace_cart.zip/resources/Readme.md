# ext-theme-neptune-de2d364f-6e40-4e51-bf96-58c26a93b54b/resources

This folder contains static resources (typically an `"images"` folder as well).
