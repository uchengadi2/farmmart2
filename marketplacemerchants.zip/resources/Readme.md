# ext-theme-neptune-2369d0a3-a3e8-4406-85d1-e6d14d3eb207/resources

This folder contains static resources (typically an `"images"` folder as well).
