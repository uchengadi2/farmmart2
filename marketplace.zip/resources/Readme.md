# ext-theme-neptune-cd3dbffa-dcac-491c-a49d-0e5021062d30/resources

This folder contains static resources (typically an `"images"` folder as well).
