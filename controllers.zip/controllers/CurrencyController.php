<?php

class CurrencyController extends Controller
{
	/**
	 * @var string the default layout for the views. Defaults to '//layouts/column2', meaning
	 * using two-column layout. See 'protected/views/layouts/column2.php'.
	 */
	public $layout='//layouts/column2';

	/**
	 * @return array action filters
	 */
	public function filters()
	{
		return array(
			'accessControl', // perform access control for CRUD operations
			'postOnly + delete', // we only allow deletion via POST request
		);
	}

	/**
	 * Specifies the access control rules.
	 * This method is used by the 'accessControl' filter.
	 * @return array access control rules
	 */
	public function accessRules()
	{
		return array(
			array('allow',  // allow all users to perform 'index' and 'view' actions
				'actions'=>array('index','view'),
				'users'=>array('*'),
			),
			array('allow', // allow authenticated user to perform 'create' and 'update' actions
				'actions'=>array('create','update','getThisCountryCurrency','deleteonecurrency','addnewcurrency','updatecurrency'),
				'users'=>array('@'),
			),
			array('allow', // allow admin user to perform 'admin' and 'delete' actions
				'actions'=>array('admin','delete'),
				'users'=>array('admin'),
			),
			array('deny',  // deny all users
				'users'=>array('*'),
			),
		);
	}

	/**
         * This is the function that retrieves the name of the country of the cuirrency
         */
        public function actiongetThisCountryCurrency(){
            
            $country_id = $_REQUEST['country_id'];
            
           $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='country_id=:currid';
            $criteria->params = array(':currid'=>$country_id);
            $currency= Currency::model()->findAll($criteria);
            
                if($currency===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                            "currency" => $currency
                          
                           
                           
                          
                       ));
                       
                }
            
            
            
        }
        
        
        
        /**
         * This is the function to create new currency
         */
        public function actionaddnewcurrency(){
            
            $model=new Currency;
            
           $model->name = $_POST['name'];
           $model->country_id = $_POST['country_id'];
            if(isset($_POST['description'])){
                $model->description = $_POST['description'];
            }
            $model->create_user_id = Yii::app()->user->id;
            $model->create_time = new CDbExpression('NOW()');
            
            $icon_error_counter = 0;
                
                 if($_FILES['symbol']['name'] != ""){
                    if($model->isIconTypeAndSizeLegal()){
                        
                       $icon_filename = $_FILES['symbol']['name'];
                      //$icon_size = $_FILES['flag']['size'];
                        
                    }else{
                       
                        $icon_error_counter = $icon_error_counter + 1;
                         
                    }//end of the determine size and type statement
                }else{
                    $icon_filename = NULL;   
                   //$icon_size = 0;
             
                }//end of the if icon is empty statement
                
                if($icon_error_counter ==0){
                   if($model->validate()){
                           $model->symbol = $model->moveTheIconToItsPathAndReturnTheIconName($model,$icon_filename);
                           //$model->flag_size = $icon_size;
                           
                       if($model->save()) {
                        
                                $msg = "'$model->name' was updated successful";
                                 header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                 "success" => mysqli_connect_errno() == 0,
                                  "msg" => $msg)
                            );
                         
                        }else{
                            //delete all the moved files in the directory when validation error is encountered
                            $msg = 'Validaion Error: Check your file fields for correctness';
                            header('Content-Type: application/json');
                            echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                        "msg" => $msg)
                               );
                          }
                            }else{
                                
                                //delete all the moved files in the directory when validation error is encountered
                            $msg = "Validation Error: '$model->name'  was not updated";
                            header('Content-Type: application/json');
                            echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                        "msg" => $msg)
                            );
                          }
                   }elseif($icon_error_counter > 0){
                        $msg = "Please check the image you uploaded and ensure that they meet the requirements. Note that the images must have a minimum size of 1000px by 1000px and they must either be in  .png or .jpg file format";
                            header('Content-Type: application/json');
                                    echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                    "msg" => $msg)
                            );
                         
                        }
                      
           
           
            
            
        }
        
        
        
        /**
         * This is the function to update currency
         */
        public function actionupdatecurrency(){
            
           $_id = $_POST['id'];
           $model=  Currency::model()->findByPk($_id);
           $model->name = $_POST['name'];
           $model->country_id = $_POST['country_id'];
            if(isset($_POST['description'])){
                $model->description = $_POST['description'];
            }
            $model->update_user_id = Yii::app()->user->id;
            $model->update_time = new CDbExpression('NOW()');
            
            $icon_error_counter = 0;
                
                 if($_FILES['symbol']['name'] != ""){
                    if($model->isIconTypeAndSizeLegal()){
                        
                       $icon_filename = $_FILES['symbol']['name'];
                      //$icon_size = $_FILES['flag']['size'];
                        
                    }else{
                       
                        $icon_error_counter = $icon_error_counter + 1;
                         
                    }//end of the determine size and type statement
                }else{
                    $icon_filename = $model->retrieveThePreviousIconName($_id); 
                   //$icon_size = 0;
             
                }//end of the if icon is empty statement
                
                if($icon_error_counter ==0){
                   if($model->validate()){
                           $model->symbol = $model->moveTheIconToItsPathAndReturnTheIconName($model,$icon_filename);
                           //$model->flag_size = $icon_size;
                           
                       if($model->save()) {
                        
                                $msg = "'$model->name' was updated successful";
                                 header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                 "success" => mysqli_connect_errno() == 0,
                                  "msg" => $msg)
                            );
                         
                        }else{
                            //delete all the moved files in the directory when validation error is encountered
                            $msg = 'Validaion Error: Check your file fields for correctness';
                            header('Content-Type: application/json');
                            echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                        "msg" => $msg)
                               );
                          }
                            }else{
                                
                                //delete all the moved files in the directory when validation error is encountered
                            $msg = "Validation Error: '$model->name'  was not updated";
                            header('Content-Type: application/json');
                            echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                        "msg" => $msg)
                            );
                          }
                   }elseif($icon_error_counter > 0){
                        $msg = "Please check the image you uploaded and ensure that they meet the requirements. Note that the images must have a minimum size of 1000px by 1000px and they must either be in  .png or .jpg file format";
                            header('Content-Type: application/json');
                                    echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                    "msg" => $msg)
                            );
                         
                        }
     
        }
        
        
        /**
         * This is the function that deletes a currency from the database
         */
        public function actiondeleteonecurrency(){
            
            $_id = $_POST['id'];
            $model=  Currency::model()->findByPk($_id);
            
            
            if($model->isTheRemovalOfCurrencySymbolASuccess($_id)){
                //get the currency name
            $currency_name = $model->getThisCurrencyName($_id);
            if($model === null){
                $data['success'] = 'undefined';
                $data['msg'] = 'No such record exist';
                header('Content-Type: application/json');
                echo CJSON::encode($data);
                                      
            }else if($model->delete()){
                    $data['success'] = 'true';
                    $data['msg'] = "'$currency_name' was successfully deleted";
                     header('Content-Type: application/json');
                    echo CJSON::encode($data);
            } else {
                    $data['success'] = 'false';
                    $data['msg'] = 'deletion was unsuccessful';
                     header('Content-Type: application/json');
                    echo CJSON::encode($data);
                            
                }
                
            }else{
                $data['success'] = 'false';
                    $data['msg'] = 'deletion was unsuccessful';
                     header('Content-Type: application/json');
                    echo CJSON::encode($data);
            }
            
            
            
        }
}
