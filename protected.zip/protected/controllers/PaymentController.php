<?php

class PaymentController extends Controller
{
	/**
	 * @var string the default layout for the views. Defaults to '//layouts/column2', meaning
	 * using two-column layout. See 'protected/views/layouts/column2.php'.
	 */
	public $layout='//layouts/column2';

	/**
	 * @return array action filters
	 */
	public function filters()
	{
		return array(
			'accessControl', // perform access control for CRUD operations
			'postOnly + delete', // we only allow deletion via POST request
		);
	}

	/**
	 * Specifies the access control rules.
	 * This method is used by the 'accessControl' filter.
	 * @return array access control rules
	 */
	public function accessRules()
	{
		return array(
			array('allow',  // allow all users to perform 'index' and 'view' actions
				'actions'=>array('index','view'),
				'users'=>array('*'),
			),
			array('allow', // allow authenticated user to perform 'create' and 'update' actions
				'actions'=>array('create','update','listAllPendingPayments','listAllPendingPayments','listAllUnconfirmedPayments','listAllFailedPayments',
                                    'listAllConfirmedPayments','retrieveorderpayment','confirmingorderpayment'),
				'users'=>array('@'),
			),
			array('allow', // allow admin user to perform 'admin' and 'delete' actions
				'actions'=>array('admin','delete'),
				'users'=>array('admin'),
			),
			array('deny',  // deny all users
				'users'=>array('*'),
			),
		);
	}

	/**
         * 
         * This is the function that list all pending payments
         */
        public function actionlistAllPendingPayments(){
            $model = new Payment;
            
            $criteria = new CDbCriteria();
              $criteria->select = '*';
              $criteria->condition='status=:status';
              $criteria->params = array(':status'=>"pending");
              $payment= Payment::model()->findAll($criteria);
              
              header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "payment" => $payment,
                                   
                    
                            ));
        }
        
        
        /**
         * 
         * This is the function that list all failed payments
         */
        public function actionlistAllFailedPayments(){
            $model = new Payment;
            
            $criteria = new CDbCriteria();
              $criteria->select = '*';
              $criteria->condition='status=:status';
              $criteria->params = array(':status'=>"failed");
              $payment= Payment::model()->findAll($criteria);
              
              header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "payment" => $payment,
                                   
                    
                            ));
        }
        
        
        /**
         * 
         * This is the function that list all unconfirmed payments
         */
        public function actionlistAllUnconfirmedPayments(){
            $model = new Payment;
            
            $criteria = new CDbCriteria();
              $criteria->select = '*';
              $criteria->condition='status=:status';
              $criteria->params = array(':status'=>"unconfirmed");
              $payment= Payment::model()->findAll($criteria);
              
              header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "payment" => $payment,
                                   
                    
                            ));
        }
        
        
        
        /**
         * 
         * This is the function that list all confirmed payments
         */
        public function actionlistAllConfirmedPayments(){
            $model = new Payment;
            
            $criteria = new CDbCriteria();
              $criteria->select = '*';
              $criteria->condition='status=:status';
              $criteria->params = array(':status'=>"confirmed");
              $payment= Payment::model()->findAll($criteria);
              
              header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "payment" => $payment,
                                   
                    
                            ));
        }
        
        
        /**
         * This is the function that retrieves the payment details of an order
         */
        public function actionretrieveorderpayment(){
            
            $model = new Payment;
            
            $order_id = $_REQUEST['order_id'];
            
            $criteria = new CDbCriteria();
              $criteria->select = '*';
              $criteria->condition='order_id=:orderid';
              $criteria->params = array(':orderid'=>$order_id);
              $payment= Payment::model()->findAll($criteria);
              
              header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "payment" => $payment,
                                   
                    
                            ));
            
            
        }
        
        
        /**
         * This is the function that confirms an order payment
         */
        public function actionconfirmingorderpayment(){
            
            $payment_id = $_REQUEST['id'];
            
            $model= Payment::model()->findByPk($payment_id);
            
            $model->status ="confirmed";
            $model->order_id =$_REQUEST['order_id'];
            $model->amount_paid =$_REQUEST['amount_paid'];
            $model->order_total_amount =$_REQUEST['order_total_amount'];
            $model->payment_confirmed_by = Yii::app()->user->id;
            $model->date_of_confirmation = new CDbExpression('NOW()');
             
            if($model->save()){
                $msg = "This payment is succefully confirmed";
                          header('Content-Type: application/json');
                          echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                        "msg" => $msg)
                           );
            }else{
                $msg = "Attempt to confirm this payment was not successful";
                         header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                        "msg" => $msg)
                           );
                
            }
        }
}
