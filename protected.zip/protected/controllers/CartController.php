<?php

class CartController extends Controller
{
	/**
	 * @var string the default layout for the views. Defaults to '//layouts/column2', meaning
	 * using two-column layout. See 'protected/views/layouts/column2.php'.
	 */
	public $layout='//layouts/column2';

	/**
	 * @return array action filters
	 */
	public function filters()
	{
		return array(
			'accessControl', // perform access control for CRUD operations
			'postOnly + delete', // we only allow deletion via POST request
		);
	}

	/**
	 * Specifies the access control rules.
	 * This method is used by the 'accessControl' filter.
	 * @return array access control rules
	 */
	public function accessRules()
	{
		return array(
			array('allow',  // allow all users to perform 'index' and 'view' actions
				'actions'=>array('index','view'),
				'users'=>array('*'),
			),
			array('allow', // allow authenticated user to perform 'create' and 'update' actions
				'actions'=>array('create','update','confirmiftheauthencityofthiscart','confirmthatthiscartidisauthentic'),
				'users'=>array('@'),
			),
			array('allow', // allow admin user to perform 'admin' and 'delete' actions
				'actions'=>array('admin','delete'),
				'users'=>array('admin'),
			),
			array('deny',  // deny all users
				'users'=>array('*'),
			),
		);
	}

	/**
	 * Displays a particular model.
	 * @param integer $id the ID of the model to be displayed
	 */
	public function actionView($id)
	{
		$this->render('view',array(
			'model'=>$this->loadModel($id),
		));
	}

	/**
         * This is the function that confirms the authenticity of a cart id
         */
        public function actionconfirmiftheauthencityofthiscart(){
            $model = new Cart;
            $user_id = Yii::app()->user->id;
            
            $cart_id = $_REQUEST['cart_id'];
            $person_in_care_of = $_REQUEST['person_in_care_of'];
            $receiver_mobile_number = $_REQUEST['receiver_mobile_number'];
            $address_landmark = $_REQUEST['address_landmark'];
            $nearest_bus_stop = $_REQUEST['nearest_bus_stop'];
            $delivery_address = $_REQUEST['delivery_address'];
            $other_relevent_information = $_REQUEST['other_relevent_information'];
            $delivery_city_id = $_REQUEST['delivery_city_id'];
            $delivery_preference = $_REQUEST['delivery_preference'];
            
             //this is the function that confirms if payment on delivery could be implemented in this city
            $is_payment_on_delivery_for_city = $this->isPaymentOnDeliveryAllowedForThisCity($delivery_city_id);
            
            
             //get policy and setting details
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            //$criteria->condition='id=:id';
            //$criteria->params = array(':id'=>$delivery_city_id);
            $policy = GeneralPolicyAndSettings::model()->find($criteria);
            
            if($model->isUserWithOpenCart($user_id)){
                if($model->isThisCartForThisUser($cart_id,$user_id)){
                    
                    $criteria = new CDbCriteria();
                    $criteria->select = '*';
                    $criteria->condition='id=:id';
                    $criteria->params = array(':id'=>$delivery_city_id);
                    $city = City::model()->find($criteria);
                    
                    $delivery_cost = $this->getTheDeliveryCostOfTheItemsInTheCart($cart_id,$delivery_city_id,$delivery_preference);
                    
                    $is_authentic = true;
                    header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "is_authentic"=>$is_authentic,
                                    "user_id"=>$user_id,
                                    "cart_id"=>$cart_id,
                                    "person_in_care_of"=>$person_in_care_of,
                                    "receiver_mobile_number"=>$receiver_mobile_number,
                                    "address_landmark"=>$address_landmark,
                                    "nearest_bus_stop"=>$nearest_bus_stop,
                                    "delivery_address"=>$delivery_address,
                                    "other_relevent_information"=>$other_relevent_information,
                                    "delivery_city_id"=>$delivery_city_id,
                                    "delivery_preference"=>$delivery_preference,
                                    "city"=>$city,
                                    "delivery_cost"=>$delivery_cost,
                                    "policy"=>$policy,
                                    "is_payment_on_delivery_for_city"=>$is_payment_on_delivery_for_city
                                   
                    
                            ));
                }else{
                     $is_authentic = false;
                    header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "is_authentic"=>$is_authentic,
                                    "user_id"=>$user_id,
                                    "cart_id"=>$cart_id
                                   
                    
                            ));
                }
                
                
            }else{
                 $is_authentic = false;
                    header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "is_authentic"=>$is_authentic,
                                    "user_id"=>$user_id,
                                    "cart_id"=>$cart_id
                                   
                    
                            ));
            }
            
            
            
        }
        
        
         /**
     * This is the function that determines if payment on delivery is permitted for a city
     */    
       public function isPaymentOnDeliveryAllowedForThisCity($delivery_city_id){
           $model = new CityWhitelist;
           return $model->isPaymentOnDeliveryAllowedForThisCity($delivery_city_id);
       } 
    
       /**
        * This is the function that retrieves the payment on delivery thredshold
        */
       public function getThePaymentOnDeliveryThreadshold(){
           $model = new GeneralPolicyAndSettings;
           return $model->getThePaymentOnDeliveryThreadshold();
       }
        
        
        /**
         * This is the function that will calculate the delivery cost of the items in a cart
         */
        public function getTheDeliveryCostOfTheItemsInTheCart($cart_id,$delivery_city_id,$delivery_preference){
            $model = new Order;
            return $model->getTheDeliveryCostOfTheItemsInTheCart($cart_id,$delivery_city_id,$delivery_preference);
        }
        
        
        
        /**
         * This is the function that confirms the authenticity of a cart id
         */
        public function actionconfirmthatthiscartidisauthentic(){
            $model = new Cart;
            $user_id = Yii::app()->user->id;
            
            $cart_id = $_REQUEST['cart_id'];
                        
                       
             //get policy and setting details
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            //$criteria->condition='id=:id';
            //$criteria->params = array(':id'=>$delivery_city_id);
            $policy = GeneralPolicyAndSettings::model()->find($criteria);
            
            if($model->isUserWithOpenCart($user_id)){
                if($model->isThisCartForThisUser($cart_id,$user_id)){
                    
                                      
                    $is_authentic = true;
                    header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "is_authentic"=>$is_authentic,
                                    "cart_id"=>$cart_id,
                                    "user_id"=>$user_id
                                   
                                   
                    
                            ));
                }else{
                     $is_authentic = false;
                    header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "is_authentic"=>$is_authentic,
                                   
                    
                            ));
                }
                
                
            }else{
                 $is_authentic = false;
                    header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "is_authentic"=>$is_authentic,
                                    "user_id"=>$user_id,
                                    "cart_id"=>$cart_id
                                   
                    
                            ));
            }
            
            
            
        }
}
