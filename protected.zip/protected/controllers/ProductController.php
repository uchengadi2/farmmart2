<?php

class ProductController extends Controller
{
	/**
	 * @var string the default layout for the views. Defaults to '//layouts/column2', meaning
	 * using two-column layout. See 'protected/views/layouts/column2.php'.
	 */
	public $layout='//layouts/column2';

	/**
	 * @return array action filters
	 */
	public function filters()
	{
		return array(
			'accessControl', // perform access control for CRUD operations
			'postOnly + delete', // we only allow deletion via POST request
		);
	}

	/**
	 * Specifies the access control rules.
	 * This method is used by the 'accessControl' filter.
	 * @return array access control rules
	 */
	public function accessRules()
	{
		return array(
			array('allow',  // allow all users to perform 'index' and 'view' actions
				'actions'=>array('index','view','listallproductforsale','listallproductsinacategory','listallproductsinaclassification','listallproductswithinacity','listallproductsonpromotion',
                                    'productdetailsinformation','theprevailingmeasurementunitsofthisproduct','allwarehouselocationswherethisproductisstored','getTheProductDetailsBaseOnThisParameters',
                                    'getTheProductParamterDetailsForANewLocation','confirmtheauthenticityofthisorderparameters','confirmorderparametersbeforeeffectingpayment',
                                    'retrievealltheproductsinthemarketplace', 'retrievethedetailsofthisproduct','thisproductdetailsinformation','productdetailsinformationformobile','confirmorderparametersbeforeeffectingpaymentbymobile',
                                    'listallproductsinacategoryperunittype','listallproductsinacategoryperunittypeforngadi','isproductavailableforthisclassification','SendingEmail','Sms',
                                    'retrieveallproductsinaslot'),
				'users'=>array('*'),
			),
			array('allow', // allow authenticated user to perform 'create' and 'update' actions
				'actions'=>array('create','update','listProductTypeMerchantProducts','modifyproduct','addnewproduct','deleteoneproduct','listAllMerchantProducts',
                                    'listAllProducts','listAllWarehouseProducts','listThisMerchantAllProducts','confirmiftheauthencityofthiscart','retrieveallinactiveproducts',
                                    'makethisproductactive','retrieveallactiveproducts','makethisproductinactive'),
				'users'=>array('@'),
			),
			array('allow', // allow admin user to perform 'admin' and 'delete' actions
				'actions'=>array('admin','delete'),
				'users'=>array('admin'),
			),
			array('deny',  // deny all users
				'users'=>array('*'),
			),
		);
	}

	/**
         * This is the function that list all products of a product type and belonging to a merchant
         */
        public function actionlistProductTypeMerchantProducts(){
            $model = new User;
            
            $user_id = Yii::app()->user->id;
            
            $merchant_id = $model->getTheMerchantIdOfThisUser($user_id);
            
            $type_id = $_REQUEST['type_id'];
            
             $criteria = new CDbCriteria();
              $criteria->select = '*';
              $criteria->condition='product_type_id=:typeid and merchant_id=:merid';
              $criteria->params = array(':typeid'=>$type_id,':merid'=>$merchant_id);
              $products= Product::model()->findAll($criteria);
              if($products===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                         header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "product" => $products,
                                    "merchant_id"=>$merchant_id
                                   
                    
                            ));
                       
                       
                }
        }
        
        
        /**
         * This is the function that adds new product to a product type
         */
        public function actionaddnewproduct(){
            $model = new Product;
            $user_id = Yii::app()->user->id;
            $merchant_id = $model->getTheMerchantIdOfThisUser($user_id);
            
            $model->product_type_id = $_POST['product_type_id'];
            $model->name  = $_POST['name'];
            if(isset($_POST['description'])){
                $model->description = $_POST['description'];
            }
            $model->merchant_id = $merchant_id;
            $model->classification_id = $_POST['classification'];
            $model->create_time = new CDbExpression('NOW()');
            $model->create_user_id = Yii::app()->user->id;
            
             $icon_error_counter = 0;
                
                 if($_FILES['icon']['name'] != ""){
                    if($model->isImageTypeAndSizeLegal()){
                        
                       $icon_filename = $_FILES['icon']['name'];
                      //$icon_size = $_FILES['flag']['size'];
                        
                    }else{
                       
                        $icon_error_counter = $icon_error_counter + 1;
                         
                    }//end of the determine size and type statement
                }else{
                    $icon_filename = NULL;   
                   //$icon_size = 0;
             
                }//end of the if icon is empty statement
                
                
                //front view image
                if($_FILES['product_front_view']['name'] != ""){
                    if($model->isFrontImageTypeAndSizeLegal()){
                        
                       $front_filename = $_FILES['product_front_view']['name'];
                      //$icon_size = $_FILES['flag']['size'];
                        
                    }else{
                       
                        $icon_error_counter = $icon_error_counter + 1;
                         
                    }//end of the determine size and type statement
                }else{
                    $front_filename = NULL;   
                   //$icon_size = 0;
             
                }//end of the if icon is empty statement
                
                
                 //right side view image
                if($_FILES['product_right_side_view']['name'] != ""){
                    if($model->isRightImageTypeAndSizeLegal()){
                        
                       $right_filename = $_FILES['product_right_side_view']['name'];
                      //$icon_size = $_FILES['flag']['size'];
                        
                    }else{
                       
                        $icon_error_counter = $icon_error_counter + 1;
                         
                    }//end of the determine size and type statement
                }else{
                    $right_filename = NULL;   
                   //$icon_size = 0;
             
                }//end of the if icon is empty statement
                
                
                
                //top view image
                if($_FILES['product_top_view']['name'] != ""){
                    if($model->isTopImageTypeAndSizeLegal()){
                        
                       $top_filename = $_FILES['product_top_view']['name'];
                      //$icon_size = $_FILES['flag']['size'];
                        
                    }else{
                       
                        $icon_error_counter = $icon_error_counter + 1;
                         
                    }//end of the determine size and type statement
                }else{
                    $top_filename = NULL;   
                   //$icon_size = 0;
             
                }//end of the if icon is empty statement
                
                
                
                //inside view image
                if($_FILES['product_inside_view']['name'] != ""){
                    if($model->isInsideImageTypeAndSizeLegal()){
                        
                       $inside_filename = $_FILES['product_inside_view']['name'];
                      //$icon_size = $_FILES['flag']['size'];
                        
                    }else{
                       
                        $icon_error_counter = $icon_error_counter + 1;
                         
                    }//end of the determine size and type statement
                }else{
                    $inside_filename = NULL;   
                   //$icon_size = 0;
             
                }//end of the if icon is empty statement
                
                
                //back view image
                if($_FILES['product_back_view']['name'] != ""){
                    if($model->isBackImageTypeAndSizeLegal()){
                        
                       $back_filename = $_FILES['product_back_view']['name'];
                      //$icon_size = $_FILES['flag']['size'];
                        
                    }else{
                       
                        $icon_error_counter = $icon_error_counter + 1;
                         
                    }//end of the determine size and type statement
                }else{
                    $back_filename = NULL;   
                   //$icon_size = 0;
             
                }//end of the if icon is empty statement
                
                
                      //left side view image
                if($_FILES['product_left_side_view']['name'] != ""){
                    if($model->isLeftImageTypeAndSizeLegal()){
                        
                       $left_filename = $_FILES['product_left_side_view']['name'];
                      //$icon_size = $_FILES['flag']['size'];
                        
                    }else{
                       
                        $icon_error_counter = $icon_error_counter + 1;
                         
                    }//end of the determine size and type statement
                }else{
                    $left_filename = NULL;   
                   //$icon_size = 0;
             
                }//end of the if icon is empty statement
                
                
                
                   //bottom view image
                if($_FILES['product_bottom_view']['name'] != ""){
                    if($model->isBottomImageTypeAndSizeLegal()){
                        
                       $bottom_filename = $_FILES['product_bottom_view']['name'];
                      //$icon_size = $_FILES['flag']['size'];
                        
                    }else{
                       
                        $icon_error_counter = $icon_error_counter + 1;
                         
                    }//end of the determine size and type statement
                }else{
                    $bottom_filename = NULL;   
                   //$icon_size = 0;
             
                }//end of the if icon is empty statement
                
                
                if($icon_error_counter ==0){
                   if($model->validate()){
                           $model->icon = $model->moveTheIconToItsPathAndReturnTheFilename($model,$icon_filename);
                           $model->product_front_view = $model->moveTheFrontImageToItsPathAndReturnTheFilename($model,$front_filename);
                           $model->product_right_side_view = $model->moveTheRightImageToItsPathAndReturnTheFilename($model,$right_filename);
                           $model->product_top_view = $model->moveTheTopToItsPathAndReturnTheFilename($model,$top_filename);
                           $model->product_inside_view = $model->moveTheInsideImageToItsPathAndReturnTheFilename($model,$inside_filename);
                           $model->product_back_view = $model->moveTheBackImageToItsPathAndReturnTheFilename($model,$back_filename);
                           $model->product_left_side_view = $model->moveTheLeftImageToItsPathAndReturnTheFilename($model,$left_filename);
                           $model->product_bottom_view = $model->moveTheBottomImageToItsPathAndReturnTheFilename($model,$bottom_filename);
                          
                         if($model->areTheProductImagesUnique($model->icon,$model->product_front_view,$model->product_right_side_view,$model->product_top_view,$model->product_inside_view,$model->product_back_view,$model->product_left_side_view,$model->product_bottom_view)){
                             
                             if($model->save()) {
                        
                                $msg = "'$model->name' product was added successful";
                                 header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                 "success" => mysqli_connect_errno() == 0,
                                  "msg" => $msg)
                            );
                         
                        }else{
                            //delete all the moved files in the directory when validation error is encountered
                            $msg = 'Validaion Error: Check your file fields for correctness';
                            header('Content-Type: application/json');
                            echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                        "msg" => $msg)
                               );
                          }
                             
                         }else{
                             
                                   //delete all the moved files in the directory when validation error is encountered
                            $msg = "illegal operation: 'You are trying to use same image for different side(s) of the product.Please ensure that your images are unique for each side of the product";
                            header('Content-Type: application/json');
                            echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                        "msg" => $msg)
                            );
                             
                           
                             
                         }  
                           
                       
                            }else{
                                   //delete all the moved files in the directory when validation error is encountered
                            $msg = 'Validaion Error: Check your file fields for correctness';
                            header('Content-Type: application/json');
                            echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                        "msg" => $msg)
                               );
                          
                          }
                   }elseif($icon_error_counter > 0){
                        $msg = "Please check the image you uploaded and ensure that they meet the requirements. Note that the images must have a minimum size of 1000px by 1000px and they must either be in  .png or .jpg file format";
                            header('Content-Type: application/json');
                                    echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                    "msg" => $msg)
                            );
                         
                        } 
            
            
        }
        
        
        
        
         /**
         * This is the function that updates a product info
         */
        public function actionmodifyproduct(){
            
            $_id = $_POST['id'];
             $model=Product::model()->findByPk($_id);
            $merchant_id = $_POST['merchant_id'];
            
            $model->product_type_id = $_POST['product_type_id'];
            $model->name  = $_POST['name'];
            if(isset($_POST['description'])){
                $model->description = $_POST['description'];
            }
            $model->merchant_id = $merchant_id;
            $model->classification_id = $_POST['classification'];
            $model->create_time = new CDbExpression('NOW()');
            $model->create_user_id = Yii::app()->user->id;
            
             $icon_error_counter = 0;
                
                 if($_FILES['icon']['name'] != ""){
                    if($model->isImageTypeAndSizeLegal()){
                        
                       $icon_filename = $_FILES['icon']['name'];
                      //$icon_size = $_FILES['flag']['size'];
                        
                    }else{
                       
                        $icon_error_counter = $icon_error_counter + 1;
                         
                    }//end of the determine size and type statement
                }else{
                    $icon_filename = $model->retrieveThePreviousIconImage($_id);   
                   //$icon_size = 0;
             
                }//end of the if icon is empty statement
                
                
                //front view image
                if($_FILES['product_front_view']['name'] != ""){
                    if($model->isFrontImageTypeAndSizeLegal()){
                        
                       $front_filename = $_FILES['product_front_view']['name'];
                      //$icon_size = $_FILES['flag']['size'];
                        
                    }else{
                       
                        $icon_error_counter = $icon_error_counter + 1;
                         
                    }//end of the determine size and type statement
                }else{
                    $front_filename = $model->retrieveThePreviousFrontImage($_id);  
                   //$icon_size = 0;
             
                }//end of the if icon is empty statement
                
                
                 //right side view image
                if($_FILES['product_right_side_view']['name'] != ""){
                    if($model->isRightImageTypeAndSizeLegal()){
                        
                       $right_filename = $_FILES['product_right_side_view']['name'];
                      //$icon_size = $_FILES['flag']['size'];
                        
                    }else{
                       
                        $icon_error_counter = $icon_error_counter + 1;
                         
                    }//end of the determine size and type statement
                }else{
                    $right_filename = $model->retrieveThePreviousRightImage($_id);   
                   //$icon_size = 0;
             
                }//end of the if icon is empty statement
                
                
                
                //top view image
                if($_FILES['product_top_view']['name'] != ""){
                    if($model->isTopImageTypeAndSizeLegal()){
                        
                       $top_filename = $_FILES['product_top_view']['name'];
                      //$icon_size = $_FILES['flag']['size'];
                        
                    }else{
                       
                        $icon_error_counter = $icon_error_counter + 1;
                         
                    }//end of the determine size and type statement
                }else{
                    $top_filename = $model->retrieveThePreviousTopImage($_id); 
                   //$icon_size = 0;
             
                }//end of the if icon is empty statement
                
                
                
                //inside view image
                if($_FILES['product_inside_view']['name'] != ""){
                    if($model->isInsideImageTypeAndSizeLegal()){
                        
                       $inside_filename = $_FILES['product_inside_view']['name'];
                      //$icon_size = $_FILES['flag']['size'];
                        
                    }else{
                       
                        $icon_error_counter = $icon_error_counter + 1;
                         
                    }//end of the determine size and type statement
                }else{
                    $inside_filename = $model->retrieveThePreviousInsideImage($_id); 
                   //$icon_size = 0;
             
                }//end of the if icon is empty statement
                
                
                //back view image
                if($_FILES['product_back_view']['name'] != ""){
                    if($model->isBackImageTypeAndSizeLegal()){
                        
                       $back_filename = $_FILES['product_back_view']['name'];
                      //$icon_size = $_FILES['flag']['size'];
                        
                    }else{
                       
                        $icon_error_counter = $icon_error_counter + 1;
                         
                    }//end of the determine size and type statement
                }else{
                    $back_filename = $model->retrieveThePreviousBackImage($_id); 
                   //$icon_size = 0;
             
                }//end of the if icon is empty statement
                
                
                      //left side view image
                if($_FILES['product_left_side_view']['name'] != ""){
                    if($model->isLeftImageTypeAndSizeLegal()){
                        
                       $left_filename = $_FILES['product_left_side_view']['name'];
                      //$icon_size = $_FILES['flag']['size'];
                        
                    }else{
                       
                        $icon_error_counter = $icon_error_counter + 1;
                         
                    }//end of the determine size and type statement
                }else{
                    $left_filename =$model->retrieveThePreviousLeftImage($_id); 
                   //$icon_size = 0;
             
                }//end of the if icon is empty statement
                
                
                
                   //bottom view image
                if($_FILES['product_bottom_view']['name'] != ""){
                    if($model->isBottomImageTypeAndSizeLegal()){
                        
                       $bottom_filename = $_FILES['product_bottom_view']['name'];
                      //$icon_size = $_FILES['flag']['size'];
                        
                    }else{
                       
                        $icon_error_counter = $icon_error_counter + 1;
                         
                    }//end of the determine size and type statement
                }else{
                    $bottom_filename = $model->retrieveThePreviousBottonImage($_id); 
                   //$icon_size = 0;
             
                }//end of the if icon is empty statement
                
                
                if($icon_error_counter ==0){
                   if($model->validate()){
                           $model->icon = $model->moveTheIconToItsPathAndReturnTheFilename($model,$icon_filename);
                           $model->product_front_view = $model->moveTheFrontImageToItsPathAndReturnTheFilename($model,$front_filename);
                           $model->product_right_side_view = $model->moveTheRightImageToItsPathAndReturnTheFilename($model,$right_filename);
                           $model->product_top_view = $model->moveTheTopToItsPathAndReturnTheFilename($model,$top_filename);
                           $model->product_inside_view = $model->moveTheInsideImageToItsPathAndReturnTheFilename($model,$inside_filename);
                           $model->product_back_view = $model->moveTheBackImageToItsPathAndReturnTheFilename($model,$back_filename);
                           $model->product_left_side_view = $model->moveTheLeftImageToItsPathAndReturnTheFilename($model,$left_filename);
                           $model->product_bottom_view = $model->moveTheBottomImageToItsPathAndReturnTheFilename($model,$bottom_filename);
                         
                           if($model->areTheProductImagesUnique($model->icon,$model->product_front_view,$model->product_right_side_view,$model->product_top_view,$model->product_inside_view,$model->product_back_view,$model->product_left_side_view,$model->product_bottom_view)){
                               
                                if($model->save()) {
                        
                                $msg = "'$model->name' product was updated successful";
                                 header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                 "success" => mysqli_connect_errno() == 0,
                                  "msg" => $msg)
                            );
                         
                        }else{
                            //delete all the moved files in the directory when validation error is encountered
                            $msg = 'Validaion Error: Check your file fields for correctness';
                            header('Content-Type: application/json');
                            echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                        "msg" => $msg)
                               );
                          }
                               
                           }else{
                                   //delete all the moved files in the directory when validation error is encountered
                                $msg = "illegal operation: 'You are trying to use same image for different side(s) of the product.Please ensure that your images are unique for each side of the product";
                                header('Content-Type: application/json');
                                 echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                        "msg" => $msg)
                                );
                               
                               
                           }
                           
                      
                            }else{
                                
                                //delete all the moved files in the directory when validation error is encountered
                            $msg = "Validation Error: '$model->name' product  was not updated";
                            header('Content-Type: application/json');
                            echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                        "msg" => $msg)
                            );
                          }
                   }elseif($icon_error_counter > 0){
                        $msg = "Please check the image you uploaded and ensure that they meet the requirements. Note that the images must have a minimum size of 1000px by 1000px and they must either be in  .png or .jpg file format";
                            header('Content-Type: application/json');
                                    echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                    "msg" => $msg)
                            );
                         
                        } 
            
            
        }
        
        
        
        /**
         * This is the function that deletes a product from a product ty[e
         */
        public function actiondeleteoneproduct(){
            
             $_id = $_POST['id'];
             $model=Product::model()->findByPk($_id);
            
            if($model->isTheRemovalOfProductImagesASuccess($_id)){
               
            $name = $_REQUEST['name'];
            if($model === null){
                $data['success'] = 'undefined';
                $data['msg'] = 'No such record exist';
                header('Content-Type: application/json');
                echo CJSON::encode($data);
                                      
            }else if($model->delete()){
                    $data['success'] = 'true';
                    $data['msg'] = "'$name' was successfully deleted";
                     header('Content-Type: application/json');
                    echo CJSON::encode($data);
            } else {
                    $data['success'] = 'false';
                    $data['msg'] = 'deletion was unsuccessful';
                     header('Content-Type: application/json');
                    echo CJSON::encode($data);
                            
                }
                
            }else{
                $data['success'] = 'false';
                    $data['msg'] = 'deletion was unsuccessful';
                     header('Content-Type: application/json');
                    echo CJSON::encode($data);
            }
        }
        
        
        
        /**
         * This is the function that list all merchants products
         */
        public function actionlistAllMerchantProducts(){
            
            $model = new Product;
            
            $merchant_id = $_REQUEST['merchant_id'];
             $criteria = new CDbCriteria();
              $criteria->select = '*';
              $criteria->condition='merchant_id=:merid';
              $criteria->params = array(':merid'=>$merchant_id);
              $products= Product::model()->findAll($criteria);
              
              if($products===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                         header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "product" => $products,
                                    "merchant_id"=>$merchant_id
                                   
                    
                            ));
                       
                       
                }
              
            
        }
        
        
        
        /**
         * This is the function that list all products
         */
        public function actionlistAllProducts(){
            
             $model = new Product;
            
             $products = Product::model()->findAll();
                if($products===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                        header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "product" => $products,
                                   
                    
                            ));
                       
                }
        }
        
        
        /**
         * This is the function that list all products in a warehouse
         */
        public function actionlistAllWarehouseProducts(){
            $model = new Inventory;
            $warehouse_id = $_REQUEST['warehouse_id'];
            
            //get all the products in this warehouse
            $products = $model->getAllProductsInThisWarehouse($warehouse_id);
            $target = [];
            foreach($products as $product){
               $criteria = new CDbCriteria();
              $criteria->select = '*';
              $criteria->condition='id=:id';
              $criteria->params = array(':id'=>$product);
              $prod= Product::model()->find($criteria);
              $target[] = $prod;
           
            }
            
            if($products===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else{
                        header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "product" => $target,
                                   
                    
                            ));
                       
                }
               
        }
        
        
        
         /**
         * This is the function that list all merchants products
         */
        public function actionlistThisMerchantAllProducts(){
            
            $model = new User;
            $user_id = Yii::app()->user->id;
            $merchant_id = $model->getTheMerchantIdOfThisUser($user_id);
            
             $criteria = new CDbCriteria();
              $criteria->select = '*';
              $criteria->condition='merchant_id=:merid';
              $criteria->params = array(':merid'=>$merchant_id);
              $products= Product::model()->findAll($criteria);
              
              if($products===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                         header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "product" => $products,
                                    "merchant_id"=>$merchant_id
                                   
                    
                            ));
                       
                       
                }
              
            
        }
        
        
        /**
         * This is the function that list all products for sale
         */
        public function actionlistallproductforsale(){
             $data = [];
            $q = "select a.*, c.price_per_unit as 'price', (select symbol from measurement_type where id=c.measurement_type_id) as unit  from product a 
                    JOIN inventory b ON a.id=b.product_id
                    JOIN pricing c ON b.id=c.inventory_id 
                    where c.is_default_price=1 group by a.name";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "product"=>$data
                                   
                    
                            ));
        }
        
        
        
        
        /**
         * This is the function that list all products with default pricing in a category
         */
        public function actionlistallproductsinacategory(){
           $category = $_REQUEST['category'];
           $data = [];
            $q = "select a.id as category_id, a.name as category_name,d.*, f.price_per_unit as 'price',f.prime_customer_discount_rate,f.id as pricing_id,e.id as inventory_id, e.warehouse_id as warehouse_id,
                f.measurement_type_id as unit_id,f.minimum_order_quantity,f.is_pricing_on_promotion,g.id as promotion_id,g.type,g.condition,g.x_quantity,
                g.y_quantity,g.y_product,g.y_product_quantity,g.y_percentage,g.status,g.start_date,g.end_date,g.available_cities,
                    (select count(*) from promotion where end_date >= NOW() and pricing_id=f.id) as is_promotion_active,
                    (select count(*) from pricing where inventory_id in (select id from inventory where product_id=d.id)) as is_price_variation_applicable,
                    (select name from city where id=(select city_id from warehouse where id=e.warehouse_id)) as city,
                    (select id from city where id=(select city_id from warehouse where id=e.warehouse_id)) as city_id, 
                    (select name from merchant where id=d.merchant_id) as merchant,
                    (select symbol from measurement_type where id=f.measurement_type_id) as unit  from category a 
                    JOIN sub_category b ON a.id=b.category_id
                    JOIN product_type c ON b.id=c.subcategory_id
                    JOIN product d ON c.id=d.product_type_id 
                    JOIN inventory e ON d.id=e.product_id 
                    JOIN pricing f ON e.id=f.inventory_id 
                    JOIN promotion g On f.id=g.pricing_id
                    where (f.is_default_price=1 and d.status='active') and a.code='$category'
                    group by d.name";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "product"=>$data,
                                    "size"=>sizeof($data)    
                                   
                    
                            ));
        }
        
        
        
         /**
         * This is the function that list all products with default pricing based on their classification
         */
        public function actionlistallproductsinaclassification(){
            $classification = $_REQUEST['classification']; 
          
            $data = [];
            $q = "select a.id as category_id, a.name as category_name,d.*, f.price_per_unit as 'price',f.prime_customer_discount_rate,f.id as pricing_id,e.id as inventory_id, e.warehouse_id as warehouse_id,f.measurement_type_id as unit_id,
                    (select count(*) from promotion where end_date >= NOW() and pricing_id=f.id) as is_pricing_on_promotion,
                    (select count(*) from pricing where inventory_id in (select id from inventory where product_id=d.id)) as is_price_variation_applicable,
                    (select name from city where id=(select city_id from warehouse where id=e.warehouse_id)) as city, 
                    (select id from city where id=(select city_id from warehouse where id=e.warehouse_id)) as city_id, 
                    (select symbol from measurement_type where id=f.measurement_type_id) as unit  from category a 
                    JOIN sub_category b ON a.id=b.category_id
                    JOIN product_type c ON b.id=c.subcategory_id
                    JOIN product d ON c.id=d.product_type_id 
                    JOIN inventory e ON d.id=e.product_id 
                    JOIN pricing f ON e.id=f.inventory_id 
                    where (f.is_default_price=1 and d.status='active') and  d.classification='$classification'
                    group by d.name";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "product"=>$data,
                                    "size"=>sizeof($data)    
                                   
                    
                            ));
        }
        
        
        /**
         * This is the function that list all products with pricing with promotion
         */
        public function actionlistallproductsonpromotion(){
                  
            $data = [];
            $q = "select a.id as category_id, a.name as category_name,d.*, f.price_per_unit as 'price',f.prime_customer_discount_rate,f.id as pricing_id,e.id as inventory_id, e.warehouse_id as warehouse_id,f.measurement_type_id as unit_id,
                    (select count(*) from promotion where end_date >= NOW() and pricing_id=f.id) as is_pricing_on_promotion,
                    (select count(*) from pricing where inventory_id in (select id from inventory where product_id=d.id)) as is_price_variation_applicable,
                    (select name from city where id=(select city_id from warehouse where id=e.warehouse_id)) as city,
                    (select id from city where id=(select city_id from warehouse where id=e.warehouse_id)) as city_id, 
                    (select symbol from measurement_type where id=f.measurement_type_id) as unit  from category a 
                    JOIN sub_category b ON a.id=b.category_id
                    JOIN product_type c ON b.id=c.subcategory_id
                    JOIN product d ON c.id=d.product_type_id 
                    JOIN inventory e ON d.id=e.product_id 
                    JOIN pricing f ON e.id=f.inventory_id
                    JOIN promotion g ON f.id=g.pricing_id
                    where (f.is_default_price=1 and d.status='active') and (f.is_pricing_on_promotion=1 and g.status='active')
                    group by d.name";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "product"=>$data,
                                    "size"=>sizeof($data)    
                                   
                    
                            ));
        }
        
        
        
         /**
         * This is the function that list products  with default prices stored in the warehouses in a city
         */
        public function actionlistallproductswithinacity(){
           $city_id = $_REQUEST['city'];  
           $data = [];
            $q = "select (select name from product where id=c.product_id)as name,(select description from product where id=c.product_id)as description, 
                (select merchant_id from product where id=c.product_id)as merchant_id,
                (select product_type_id from product where id=c.product_id)as product_type_id,
                (select product_front_view from product where id=c.product_id)as product_front_view,
                (select product_right_side_view from product where id=c.product_id)as product_right_side_view,
                (select product_top_view from product where id=c.product_id)as product_top_view,
                (select product_inside_view from product where id=c.product_id)as product_inside_view,
                (select product_back_view from product where id=c.product_id)as product_back_view,
                (select product_left_side_view from product where id=c.product_id)as product_left_side_view,
                (select product_bottom_view from product where id=c.product_id)as product_bottom_view,
                (select product_video from product where id=c.product_id)as product_video,
                (select status from product where id=c.product_id)as status,
                d.id as pricing_id,c.id as inventory_id, c.warehouse_id as warehouse_id,d.measurement_type_id as unit_id, a.id as city_id, a.name as city,
                (select icon from product where id=c.product_id)as icon, (select id from product where id=c.product_id)as id,
                (select classification from product where id=c.product_id)as classification,
                (select count(*) from pricing where inventory_id in (select id from inventory where product_id=(select id from product where id=c.product_id))) as is_price_variation_applicable,
                (select name from category where id=(select category_id from sub_category where id=(select subcategory_id from product_type where id=(select product_type_id from product where id=c.product_id)))) as category_name,
                (select id from category where id=(select category_id from sub_category where id=(select subcategory_id from product_type where id=(select product_type_id from product where id=c.product_id)))) as category_id,
                d.price_per_unit as 'price', d.prime_customer_discount_rate,(select count(*) from promotion where end_date >= NOW() and pricing_id=d.id) as is_pricing_on_promotion,
                (select symbol from measurement_type where id=d.measurement_type_id) as unit, a.name as city  from city a 
                    JOIN warehouse b ON a.id=b.city_id
                    JOIN inventory c ON b.id=c.warehouse_id
                    JOIN pricing d ON c.id=d.inventory_id 
                    where d.is_default_price=1 and a.id=$city_id
                    group by name";	
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "product"=>$data,
                                    "size"=>sizeof($data)    
                                   
                    
                            ));
        }
        
        
        /**
         * This is the function that retrieves the details of a product
        
        public function actionproductdetailsinformation(){
            $model = new Pricing;
            $product_id = $_REQUEST['product_id'];
            $data = [];
            if($model->isThisProductDefaultPricingOnPromotion($product_id) == false){
                $q = "select a.*, c.id as pricing_id, c.inventory_id,c.price_per_unit as 'price', c.prime_customer_discount_rate,c.minimum_order_quantity,
                    c.is_default_price,(select symbol from measurement_type where id=c.measurement_type_id) as unit,c.measurement_type_id as measurement_type_id,
                    (select name from city where id=(select city_id from warehouse where id=b.warehouse_id)) as city, 
                    (select id from city where id=(select city_id from warehouse where id=b.warehouse_id)) as warehouse_location_id, 
                    (select count(*) from pricing where inventory_id in (select id from inventory where product_id=a.id)) as is_price_variation_applicable,
                    (select name from category where id=(select category_id from sub_category where id=(select subcategory_id from product_type where id=(select product_type_id from product where id=a.id)))) as category_name,
                    (select id from category where id=(select category_id from sub_category where id=(select subcategory_id from product_type where id=(select product_type_id from product where id=a.id)))) as category_id,
                    (select name from merchant where id=(select merchant_id from product where id=a.id)) as merchant_name,
                    (select count(*) from promotion where end_date >= NOW() and pricing_id=c.id) as is_pricing_on_promotion from product a
                    JOIN inventory b ON a.id=b.product_id
                    JOIN pricing c ON b.id=c.inventory_id
                     where a.id=$product_id and c.is_default_price =1
                    group by a.name";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "product"=>$data,
                                    
                                   
                    
                            ));
                
                
            }else{
                $q = "select a.*,c.price_per_unit as 'price', c.inventory_id, c.prime_customer_discount_rate, c.price_per_unit as 'price', (select symbol from measurement_type where id=c.measurement_type_id) as unit,c.measurement_type_id as measurement_type_id,c.minimum_order_quantity,
                    d.id as promotion_id, d.type, d.pricing_id,d.condition, d.x_quantity, d.y_quantity, d.y_product, d.y_product_quantity,d.y_percentage,d.start_date,d.end_date,
                    (select name from city where id=(select city_id from warehouse where id=b.warehouse_id)) as city, 
                    (select id from city where id=(select city_id from warehouse where id=b.warehouse_id)) as warehouse_location_id, 
                    (select count(*) from pricing where inventory_id in (select id from inventory where product_id=a.id)) as is_price_variation_applicable,
                    (select name from category where id=(select category_id from sub_category where id=(select subcategory_id from product_type where id=(select product_type_id from product where id=a.id)))) as category_name,
                    (select id from category where id=(select category_id from sub_category where id=(select subcategory_id from product_type where id=(select product_type_id from product where id=a.id)))) as category_id,
                    (select name from merchant where id=(select merchant_id from product where id=a.id)) as merchant_name,
                    (select count(*) from promotion where end_date >= NOW() and pricing_id=c.id) as is_pricing_on_promotion from product a
                    JOIN inventory b ON a.id=b.product_id
                    JOIN pricing c ON b.id=c.inventory_id
                    JOIN promotion d ON c.id=d.pricing_id 
                   where a.id=$product_id and c.is_default_price =1
                    group by a.name";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "product"=>$data,
                                    
                    
                            ));
                
            }
           
            
            
        } **/
        
        
        /**
         * This is the function that retrieves the details of a product
         */
        public function actionproductdetailsinformation(){
            $model = new Pricing;
            $product_id = $_REQUEST['product_id'];
            $data = [];
            
                $q = "select a.*,c.price_per_unit as 'price', c.inventory_id, c.prime_customer_discount_rate, c.price_per_unit as 'price', (select symbol from measurement_type where id=c.measurement_type_id) as unit,c.measurement_type_id as measurement_type_id,c.minimum_order_quantity,
                    d.id as promotion_id, d.type, d.pricing_id,d.condition, d.x_quantity, d.y_quantity, d.y_product, d.y_product_quantity,d.y_percentage,d.start_date,d.end_date,
                    (select name from city where id=(select city_id from warehouse where id=b.warehouse_id)) as city, 
                    (select id from city where id=(select city_id from warehouse where id=b.warehouse_id)) as warehouse_location_id, 
                    (select count(*) from pricing where inventory_id in (select id from inventory where product_id=a.id)) as is_price_variation_applicable,
                    (select name from category where id=(select category_id from sub_category where id=(select subcategory_id from product_type where id=(select product_type_id from product where id=a.id)))) as category_name,
                    (select id from category where id=(select category_id from sub_category where id=(select subcategory_id from product_type where id=(select product_type_id from product where id=a.id)))) as category_id,
                    (select name from merchant where id=(select merchant_id from product where id=a.id)) as merchant_name,
                    (select count(*) from promotion where end_date >= NOW() and pricing_id=c.id) as is_pricing_on_promotion from product a
                    JOIN inventory b ON a.id=b.product_id
                    JOIN pricing c ON b.id=c.inventory_id
                    JOIN promotion d ON c.id=d.pricing_id 
                   where d.status='active' and a.id=$product_id and c.is_default_price =1
                    group by a.name";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "product"=>$data,
                                    
                    
                            ));
                
            
           
            
            
        }
        
        
        /**
         * This is the function that retrieves the prevailing measurement units of a product category or classification
         */
        public function actiontheprevailingmeasurementunitsofthisproduct(){
            $model = new GeneralPolicyAndSettings;
            
            $prevailing_measurement_type = $model->getThePreferredMeasurementType();
            
            if($prevailing_measurement_type == "product_classification"){
                //retrieve all the measurement type of a classification
              $criteria = new CDbCriteria();
              $criteria->select = '*';
              $criteria->condition='classification_id=:class';
              $criteria->params = array(':class'=>$_REQUEST['classification']);
              $units= ClassificationMeasurementType::model()->findAll($criteria);
              $data = [];
              foreach($units as $unit){
                  $data[] = $unit['measurement_type_id'];
              }
            }else{
                  //retrieve all the measurement type of a category
              $criteria = new CDbCriteria();
              $criteria->select = '*';
              $criteria->condition='category_id=:catid';
              $criteria->params = array(':catid'=>$_REQUEST['category_id']);
              $units= CategoryMeasurementType::model()->findAll($criteria);
              
              foreach($units as $unit){
                  $data[] = $unit['measurement_type_id'];
              }
            }
            
            $target = [];
            
            foreach($data as $dat){
              $criteria = new CDbCriteria();
              $criteria->select = '*';
              $criteria->condition='id=:id';
              $criteria->params = array(':id'=>$dat);
              $type= MeasurementType::model()->find($criteria);
              $target[] = $type;
            }
            
             header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "unit"=>$target,
                                    
                    
                            ));
            
        }
        
        
        /**
         * This is the function that retrieves all warehouse locations where this product is stored
         */
        public function actionallwarehouselocationswherethisproductisstored(){
            $model = new Warehouse;
            $product_id = $_REQUEST['product_id'];
            
            //retrieve all warehouse ids where this product is stored
            $warehouses = $model->getAllWarehousesForThisProduct($product_id);
            
            $cities = [];
            
            foreach($warehouses as $warehouse){
                $cities[] = $model->getTheCityWhereThisWarehouseIsLocated($warehouse);
            }
            
            $target = [];
            //retrieve the details of these cities
            foreach($cities as $cit){
              $criteria = new CDbCriteria();
              $criteria->select = '*';
              $criteria->condition='id=:id';
              $criteria->params = array(':id'=>$cit);
              $city= City::model()->find($criteria);
              $target[] = $city;
            }
            
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "location"=>$target,
                                    
                    
                            ));
        }
        
        
               
        
         /**
         * This is the function that gets a product details base on some parameters
         
        public function actiongetTheProductDetailsBaseOnThisParameters(){
            $model = new Pricing;
             $warehouse_location_id = $_REQUEST['location_id'];
            $merchant_id = $_REQUEST['merchant_id'];
            $product_id = $_REQUEST['product_id'];
            $unit_type_id = $_REQUEST['unit_type_id'];
           
            $data = [];
            if($model->isThisProductPricingOnPromotion($product_id,$warehouse_location_id,$unit_type_id) == false){
                $q = "select a.*, c.id as pricing_id, c.price_per_unit as 'price', c.prime_customer_discount_rate,c.inventory_id,c.minimum_order_quantity,
                    (select symbol from measurement_type where id=$unit_type_id) as unit, c.measurement_type_id as measurement_type_id,
                    (select name from city where id=$warehouse_location_id) as city, 
                    (select id from city where id=$warehouse_location_id and merchant_id=$merchant_id) as warehouse_location_id,
                    (select count(*) from promotion where end_date >= NOW() and pricing_id=c.id) as is_pricing_on_promotion from product a
                    JOIN inventory b ON a.id=b.product_id
                    JOIN pricing c ON b.id=c.inventory_id
                     where c.id =(select id from pricing where inventory_id=(select id from inventory where warehouse_id=(select id from warehouse where product_id=$product_id and city_id=$warehouse_location_id and merchant_id=$merchant_id)) and measurement_type_id=$unit_type_id)
                    group by a.name";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "product"=>$data,
                                    
                                   
                    
                            ));
                
                
            }else{
                $q ="select a.*,c.id as pricing_id, c.price_per_unit as 'price', c.prime_customer_discount_rate,c.inventory_id,c.minimum_order_quantity,
                    d.id as promotion_id, d.type, d.pricing_id,d.condition, d.x_quantity, d.y_quantity, d.y_product, d.y_product_quantity,d.y_percentage,d.start_date,d.end_date,
                    (select symbol from measurement_type where id=$unit_type_id) as unit,c.measurement_type_id as measurement_type_id,
                    (select name from city where id=$warehouse_location_id) as city, 
                    (select id from city where id=$warehouse_location_id and merchant_id=$merchant_id) as warehouse_location_id,
                    (select count(*) from promotion where end_date >= NOW() and pricing_id=c.id) as is_pricing_on_promotion,
                    (select count(*) from promotion where end_date >= NOW() and pricing_id=c.id) as is_pricing_on_promotion from product a
                    JOIN inventory b ON a.id=b.product_id
                    JOIN pricing c ON b.id=c.inventory_id
                    JOIN promotion d ON c.id=d.pricing_id 
                   where c.id =(select id from pricing where inventory_id=(select id from inventory where warehouse_id=(select id from warehouse where product_id=$product_id and city_id=$warehouse_location_id and merchant_id=$merchant_id)) and measurement_type_id=$unit_type_id)   
                    group by a.name";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "product"=>$data,
                                    
                    
                            ));
                
            }
           
            
            
        }
          * 
          * 
          */
        
        /**
         * This is the function that gets a product details base on some parameters
         */
        public function actiongetTheProductDetailsBaseOnThisParameters(){
            $model = new Pricing;
             $warehouse_location_id = $_REQUEST['location_id'];
            $merchant_id = $_REQUEST['merchant_id'];
            $product_id = $_REQUEST['product_id'];
            $unit_type_id = $_REQUEST['unit_type_id'];
           
            $data = [];
            
                $q ="select a.*,c.id as pricing_id, c.price_per_unit as 'price', c.prime_customer_discount_rate,c.inventory_id,c.minimum_order_quantity,c.is_pricing_on_promotion,
                    d.id as promotion_id, d.type, d.pricing_id,d.condition, d.x_quantity, d.y_quantity, d.y_product, d.y_product_quantity,d.y_percentage,d.start_date,d.end_date,
                    (select symbol from measurement_type where id=$unit_type_id) as unit,c.measurement_type_id as measurement_type_id,
                    (select name from city where id=$warehouse_location_id) as city, 
                    (select id from city where id=$warehouse_location_id) as warehouse_location_id,
                    (select count(*) from promotion where end_date >= NOW() and pricing_id=c.id) as is_pricing_on_promotion,
                    (select count(*) from promotion where end_date >= NOW() and pricing_id=c.id) as is_promotion_active from product a
                    JOIN inventory b ON a.id=b.product_id
                    JOIN pricing c ON b.id=c.inventory_id
                    JOIN promotion d ON c.id=d.pricing_id 
                   where a.status='active' and c.id =(select id from pricing where measurement_type_id = $unit_type_id and inventory_id=(select id from inventory where product_id=$product_id and warehouse_id=(select id from warehouse where city_id=$warehouse_location_id and merchant_id=$merchant_id)))   
                    group by a.name";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "product"=>$data,
                                    
                    
                            ));
                
            
           
            
            
        }
        
        
        
        
        /**
         * This is the function that gets a product paramter details for a new location
         
        public function actiongetTheProductParamterDetailsForANewLocation(){
            $model = new Pricing;
             $warehouse_location_id = $_REQUEST['location_id'];
            $merchant_id = $_REQUEST['merchant_id'];
            $product_id = $_REQUEST['product_id'];
            $unit_type_id = $_REQUEST['unit_type_id'];
            
            $data = [];
            if($model->isThisProductPricingOnPromotion($product_id,$warehouse_location_id,$unit_type_id) == false){
                $q = "select a.*, c.id as pricing_id, c.price_per_unit as 'price', c.prime_customer_discount_rate,c.inventory_id,c.minimum_order_quantity,
                    (select symbol from measurement_type where id=$unit_type_id) as unit, c.measurement_type_id as measurement_type_id,
                    (select name from city where id=$warehouse_location_id) as city, 
                    (select id from city where id=$warehouse_location_id and merchant_id=$merchant_id) as warehouse_location_id,
                    (select count(*) from promotion where end_date >= NOW() and pricing_id=c.id) as is_pricing_on_promotion from product a
                    JOIN inventory b ON a.id=b.product_id
                    JOIN pricing c ON b.id=c.inventory_id
                     where c.id =(select id from pricing where inventory_id=(select id from inventory where warehouse_id=(select id from warehouse where product_id=$product_id and city_id=$warehouse_location_id and merchant_id=$merchant_id)) and measurement_type_id=$unit_type_id)
                    group by a.name";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "product"=>$data,
                                    
                                   
                    
                            ));
                
                
            }else{
                $q ="select a.*,c.id as pricing_id, c.price_per_unit as 'price', c.prime_customer_discount_rate,c.inventory_id,c.minimum_order_quantity,
                    d.id as promotion_id, d.type, d.pricing_id,d.condition, d.x_quantity, d.y_quantity, d.y_product, d.y_product_quantity,d.y_percentage,d.start_date,d.end_date,
                    (select symbol from measurement_type where id=$unit_type_id) as unit, c.measurement_type_id as measurement_type_id,
                    (select name from city where id=$warehouse_location_id) as city, 
                    (select id from city where id=$warehouse_location_id and merchant_id=$merchant_id) as warehouse_location_id,
                    (select count(*) from promotion where end_date >= NOW() and pricing_id=c.id) as is_pricing_on_promotion,
                    (select count(*) from promotion where end_date >= NOW() and pricing_id=c.id) as is_pricing_on_promotion from product a
                    JOIN inventory b ON a.id=b.product_id
                    JOIN pricing c ON b.id=c.inventory_id
                    JOIN promotion d ON c.id=d.pricing_id 
                    where c.id =(select id from pricing where inventory_id=(select id from inventory where warehouse_id=(select id from warehouse where product_id=$product_id and city_id=$warehouse_location_id and merchant_id=$merchant_id)) and measurement_type_id=$unit_type_id)   
                    group by a.name";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "product"=>$data,
                                    
                    
                            ));
                
            }
           
            
            
        }
         * 
         */
        
        
        
        
        /**
         * This is the function that gets a product paramter details for a new location
         */
        public function actiongetTheProductParamterDetailsForANewLocation(){
            
             $model = new Pricing;
             $warehouse_location_id = $_REQUEST['location_id'];
            $merchant_id = $_REQUEST['merchant_id'];
            $product_id = $_REQUEST['product_id'];
            $unit_type_id = $_REQUEST['unit_type_id'];
            
            $data = [];
            
                $q ="select a.*,c.id as pricing_id, c.price_per_unit as 'price', c.prime_customer_discount_rate,c.inventory_id,c.minimum_order_quantity,c.is_pricing_on_promotion,
                    d.id as promotion_id, d.type, d.pricing_id,d.condition, d.x_quantity, d.y_quantity, d.y_product, d.y_product_quantity,d.y_percentage,d.start_date,d.end_date,
                    (select symbol from measurement_type where id=$unit_type_id) as unit, c.measurement_type_id as measurement_type_id,
                    (select name from city where id=$warehouse_location_id) as city, 
                    (select id from city where id=$warehouse_location_id and merchant_id=$merchant_id) as warehouse_location_id,
                    (select count(*) from promotion where end_date >= NOW() and pricing_id=c.id) as is_pricing_on_promotion,
                    (select count(*) from promotion where end_date >= NOW() and pricing_id=c.id) as is_promotion_active from product a
                    JOIN inventory b ON a.id=b.product_id
                    JOIN pricing c ON b.id=c.inventory_id
                    JOIN promotion d ON c.id=d.pricing_id 
                    where d.status='active' and c.id =(select id from pricing where inventory_id=(select id from inventory where warehouse_id=(select id from warehouse where product_id=$product_id and city_id=$warehouse_location_id and merchant_id=$merchant_id)) and measurement_type_id=$unit_type_id)   
                    group by a.name";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "product"=>$data,
                                    
                    
                            ));
                
            
           
            
            
        }
        
        /**
         * This is the function that confirms if some parameters from the url is authentic and accurate
         */
        public function actionconfirmtheauthenticityofthisorderparameters(){
            $model = new Pricing;
            $product_id = $_REQUEST['product_id'];
            $pricing_id = $_REQUEST['pricing_id'];
            $prime_customer_discount_rate = $_REQUEST['prime_customer_discount_rate'];
            $measurement_type_id = $_REQUEST['measurement_type_id'];
            $unit_type = $_REQUEST['unit_type'];
            $promotion_id = $_REQUEST['promotion_id'];
            $promotion_type = $_REQUEST['promotion_type'];
            $is_pricing_on_promotion = $_REQUEST['is_pricing_on_promotion'];
            $price = $_REQUEST['price'];
            $warehouse_location_id = $_REQUEST['warehouse_location_id'];
            $quantity = $_REQUEST['quantity'];
            $total_price = $_REQUEST['total_price'];
            $promotion = $_REQUEST['promotion'];
            $cart_id = $_REQUEST['cart_id'];
            $user_id = $_REQUEST['user_id'];
                    
            $counter = 0;
            
            //get some of the pricing information
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$pricing_id);
            $pricing = Pricing::model()->find($criteria);
            
            //confirm if the pricing details are correct
            if($model->isThisPricingAuthentic($pricing_id,$prime_customer_discount_rate,$measurement_type_id,$price,$is_pricing_on_promotion) == false){
                $counter = $counter + 1;
            }
            //confirm if the promotion is for this pricing
            if($model->isThisPromotionForThisPricing($pricing_id,$promotion_id,$is_pricing_on_promotion,$promotion_type) == false){
                 $counter = $counter + 1;
            }
            
            //confirm if this pricing is for this product
            if($model->isPricingForThisProduct($product_id,$pricing_id,$warehouse_location_id) == false){
                $counter = $counter + 1;
            }
            
            if($counter == 0){
                $result = true;
            }else{
                $result = false;
            }
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "is_authentic"=>true,
                                    "price_per_unit"=>$pricing['price_per_unit'],
                                    "product_id"=>$product_id,
                                    "pricing_id"=>$pricing_id,
                                    "prime_customer_discount_rate"=>$prime_customer_discount_rate,
                                    "measurement_type_id"=>$measurement_type_id,
                                    "unit_type"=>$unit_type,
                                    "promotion_id"=>$promotion_id,
                                    "promotion_type"=>$promotion_type,
                                    "is_pricing_on_promotion"=>$is_pricing_on_promotion,
                                    "price"=>$price,
                                    "warehouse_location_id"=>$warehouse_location_id,
                                    "quantity"=>$quantity,
                                    "total_price"=>$total_price,
                                    "promotion"=>$promotion,
                                    "cart_id"=>$cart_id,
                                    "user_id"=>$user_id
                                    
                    
                            ));
        }
        
        
        
        
        /**
         * This is the function that confirms if some parameters from the url is authentic and accurate before payment is effected
         */
        public function actionconfirmorderparametersbeforeeffectingpayment(){
            $model = new Pricing;
            $product_id = $_REQUEST['product_id'];
            $pricing_id = $_REQUEST['pricing_id'];
            $prime_customer_discount_rate = $_REQUEST['prime_customer_discount_rate'];
            $measurement_type_id = $_REQUEST['measurement_type_id'];
            $unit_type = $_REQUEST['unit_type'];
            $promotion_id = $_REQUEST['promotion_id'];
            $promotion_type = $_REQUEST['promotion_type'];
            $is_pricing_on_promotion = $_REQUEST['is_pricing_on_promotion'];
            $price = $_REQUEST['price'];
            $warehouse_location_id = $_REQUEST['warehouse_location_id'];
            $quantity = $_REQUEST['quantity'];
            $total_price = $_REQUEST['total_price'];
            $promotion_text = $_REQUEST['promotion'];
            $person_in_care_of = $_REQUEST['person_in_care_of'];
            $receiver_mobile_number = $_REQUEST['receiver_mobile_number'];
            $address_landmark = $_REQUEST['address_landmark'];
            $nearest_bus_stop = $_REQUEST['nearest_bus_stop'];
            $delivery_address = $_REQUEST['delivery_address'];
            $other_relevent_information = $_REQUEST['other_relevent_information'];
            $delivery_city_id = $_REQUEST['delivery_city_id'];
            $delivery_preference = $_REQUEST['delivery_preference'];
            $cart_id = $_REQUEST['cart_id'];
            $user_id = $_REQUEST['user_id'];
            $is_promotion_active = $_REQUEST['is_promotion_active'];
                                 
            $counter = 0;
            
            //get some of the pricing information
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$pricing_id);
            $pricing = Pricing::model()->find($criteria);
            
            //confirm if the pricing details are correct
            if($model->isThisPricingAuthentic($pricing_id,$prime_customer_discount_rate,$measurement_type_id,$price,$is_pricing_on_promotion) == false){
                $counter = $counter + 1;
            }
            //confirm if the promotion is for this pricing
            if($model->isThisPromotionForThisPricing($pricing_id,$promotion_id,$is_pricing_on_promotion,$promotion_type) == false){
                 $counter = $counter + 1;
            }
            
            //confirm if this pricing is for this product
            if($model->isPricingForThisProduct($product_id,$pricing_id,$warehouse_location_id) == false){
                $counter = $counter + 1;
            }
            
            //get some product details
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$product_id);
            $product = Product::model()->find($criteria);
            
            //get delivery city details
             //get some product details
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$delivery_city_id);
            $city = City::model()->find($criteria);
            
            if($counter == 0){
                $result = true;
            }else{
                $result = false;
            }
            
            
            //this is the function that confirms if payment on delivery could be implemented in this city
            $is_payment_on_delivery_for_city = $this->isPaymentOnDeliveryAllowedForThisCity($delivery_city_id);
            
            
            
            
             //get policy and setting details
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            //$criteria->condition='id=:id';
            //$criteria->params = array(':id'=>$delivery_city_id);
            $policy = GeneralPolicyAndSettings::model()->find($criteria);
            
            if($is_pricing_on_promotion == 1){
              //get promotion details
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='id=:id and status=:status';
             $criteria->params = array(':id'=>$promotion_id,':status'=>"active");
             $promotion = Promotion::model()->find($criteria); 
                
             
             //confirm if promotion is applicable to this city
            if($promotion['available_cities'] == $delivery_city_id){
                $is_promotion_applicable_to_city = true;
            }else if($promotion['available_cities'] == NULL){
                $is_promotion_applicable_to_city = true;
            }else if($promotion['available_cities'] == " "){
                $is_promotion_applicable_to_city = true;
            }else{
                $is_promotion_applicable_to_city = false;
            }
            }else{
                $promotion = null;
                $is_promotion_applicable_to_city = false;
            }
            
            //obtain the delivery cost of this order
            $delivery_cost = $this->getTheDeliveryCostOfThisOrder($delivery_city_id,$measurement_type_id,$warehouse_location_id,$quantity,$delivery_preference);
            
            
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "is_authentic"=>$result,
                                    "price_per_unit"=>$pricing['price_per_unit'],
                                    "product_id"=>$product_id,
                                    "pricing_id"=>$pricing_id,
                                    "prime_customer_discount_rate"=>$prime_customer_discount_rate,
                                    "measurement_type_id"=>$measurement_type_id,
                                    "unit_type"=>$unit_type,
                                    "promotion_id"=>$promotion_id,
                                    "promotion_type"=>$promotion_type,
                                    "is_pricing_on_promotion"=>$is_pricing_on_promotion,
                                    "price"=>$price,
                                    "warehouse_location_id"=>$warehouse_location_id,
                                    "quantity"=>$quantity,
                                    "total_price"=>$total_price,
                                    "promotion_text"=>$promotion_text,
                                    "person_in_care_of"=>$person_in_care_of,
                                    "receiver_mobile_number"=>$receiver_mobile_number,
                                    "address_landmark"=>$address_landmark,
                                    "nearest_bus_stop"=>$nearest_bus_stop,
                                    "delivery_address"=>$delivery_address,
                                    "other_relevent_information"=>$other_relevent_information,
                                    "delivery_city_id"=>$delivery_city_id,
                                    "delivery_preference"=>$delivery_preference,
                                    "product"=>$product,
                                    "city"=>$city,
                                    "is_payment_on_delivery_for_city"=>$is_payment_on_delivery_for_city,
                                    "policy"=>$policy,
                                    "promotion"=>$promotion,
                                    "delivery_cost"=>$delivery_cost,
                                    "cart_id"=>$cart_id,
                                    "user_id"=>$user_id,
                                    "is_promotion_applicable_to_city"=>$is_promotion_applicable_to_city,
                                    "is_promotion_active"=>$is_promotion_active
                           
                    
                            ));
        }
        
        
        
    /**
     * This is the function that determines if payment on delivery is permitted for a city
     */    
       public function isPaymentOnDeliveryAllowedForThisCity($delivery_city_id){
           $model = new CityWhitelist;
           return $model->isPaymentOnDeliveryAllowedForThisCity($delivery_city_id);
       } 
    
       /**
        * This is the function that retrieves the payment on delivery thredshold
        */
       public function getThePaymentOnDeliveryThreadshold(){
           $model = new GeneralPolicyAndSettings;
           return $model->getThePaymentOnDeliveryThreadshold();
       }
       
       
       /**
        * This is the function that returns the delivery cost of an order
        */
       public function getTheDeliveryCostOfThisOrder($delivery_city_id,$measurement_type_id,$warehouse_location_id,$quantity,$delivery_preference){
           $model =new Order;
           return $model->getTheDeliveryCostOfThisOrder($delivery_city_id,$measurement_type_id,$warehouse_location_id,$quantity,$delivery_preference);
       }
        
       
       
       /**
        * This is the function that list all products in the marketplace
        */
       
     /**   public function actionretrievealltheproductsinthemarketplace(){
            $data = [];
            $q = "select a.product_id, b.id as pricing_id,b.is_pricing_on_promotion, b.measurement_type_id,a.warehouse_id,
                (select city_id from warehouse where id=a.warehouse_id)as warehouse_location_id from inventory a
                    JOIN pricing b ON a.id=b.inventory_id
                     group by b.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "product"=>$data,
                                    "count"=>sizeof($data)
                                   
                    
                            ));
        }
      * 
      */
        
        
        /**
         * This is the function that retrieves the details of a product
         */
        public function actionretrievethedetailsofthisproduct(){
            
            $product_id = $_REQUEST['product_id'];
            $pricing_id = $_REQUEST['pricing_id'];
            $is_pricing_on_promotion = $_REQUEST['is_pricing_on_promotion'];
            $measurement_type_id = $_REQUEST['measurement_type_id'];
            $warehouse_location_id = $_REQUEST['warehouse_location_id'];
            $warehouse_id = $_REQUEST['warehouse_id'];
            
            if($is_pricing_on_promotion == 0){
                $q = "select a.*, c.id as pricing_id, c.price_per_unit as 'price', c.prime_customer_discount_rate,c.inventory_id,
                    (select symbol from measurement_type where id=$measurement_type_id) as unit, c.measurement_type_id as measurement_type_id,
                    (select name from city where id=$warehouse_location_id) as city, 
                    (select id from city where id=$warehouse_location_id and merchant_id=(select merchant_id from product where id=$product_id)) as warehouse_location_id,
                    (select count(*) from promotion where end_date >= NOW() and pricing_id=c.id) as is_pricing_on_promotion from product a
                    JOIN inventory b ON a.id=b.product_id
                    JOIN pricing c ON b.id=c.inventory_id
                     where c.id =$pricing_id
                    group by a.name";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "product"=>$data,
                                    
                                   
                    
                            ));
                
                
                
                
            }else{
                $q ="select a.*,c.id as pricing_id, c.price_per_unit as 'price', c.prime_customer_discount_rate,c.inventory_id,
                    d.id as promotion_id, d.type, d.pricing_id,d.condition, d.x_quantity, d.y_quantity, d.y_product, d.y_product_quantity,d.y_percentage,d.start_date,d.end_date,
                    (select symbol from measurement_type where id=$measurement_type_id) as unit, c.measurement_type_id as measurement_type_id,
                    (select name from city where id=$warehouse_location_id) as city, 
                    (select id from city where id=$warehouse_location_id and merchant_id=(select merchant_id from product where id=$product_id)) as warehouse_location_id,
                    (select count(*) from promotion where end_date >= NOW() and pricing_id=c.id) as is_pricing_on_promotion,
                    (select count(*) from promotion where end_date >= NOW() and pricing_id=c.id) as is_pricing_on_promotion from product a
                    JOIN inventory b ON a.id=b.product_id
                    JOIN pricing c ON b.id=c.inventory_id
                    JOIN promotion d ON c.id=d.pricing_id 
                    where c.id =$pricing_id   
                    group by a.name";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "product"=>$data,
                                    
                    
                            ));
                
                
            }
        }
        
        
        
        /**
        * This is the function that retrieves all products in the marketplace
        */
       
        public function actionretrievealltheproductsinthemarketplace(){
            $model = new User;
            
            $user_id = Yii::app()->user->id;
            if($user_id != null){
                $user_name = $model->getTheNameOfThisUser($user_id);
             }else{
                 $user_name = null;
             }
            
            
            
            $data = [];
            $q ="select a.*,c.id as pricing, c.price_per_unit as 'price', c.prime_customer_discount_rate,c.inventory_id,c.is_default_price,
                    d.id as promotion_id, d.type, d.pricing_id,d.condition, d.x_quantity, d.y_quantity, d.y_product, d.y_product_quantity,d.y_percentage,d.start_date,d.end_date,
                    (select symbol from measurement_type where id=c.measurement_type_id) as unit, c.measurement_type_id as measurement_type_id,
                    (select name from city where id=(select city_id from warehouse where id=(select warehouse_id from inventory where id=c.inventory_id))) as city, 
                    (select city_id from warehouse where id=(select warehouse_id from inventory where id=c.inventory_id)) as watehouse_location_id, 
                    (select count(*) from promotion where end_date >= NOW() and pricing_id=c.id) as is_pricing_on_promotion,
                    (select id from category where id=(select category_id from sub_category where id=(select subcategory_id from product_type where id=(select product_type_id from product where id=a.id)))) as category_id,
                    (select count(*) from promotion where end_date >= NOW() and pricing_id=c.id) as is_pricing_on_promotion from product a
                    JOIN inventory b ON a.id=b.product_id
                    JOIN pricing c ON b.id=c.inventory_id
                    JOIN promotion d ON c.id=d.pricing_id 
                    where c.is_default_price=1 and a.status='active'
                    group by a.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "product"=>$data,
                                    "user_id"=>$user_id,
                                    "user_name"=>$user_name,
                                    "count"=>sizeof($data)
                                    
                    
                            ));
        }
        
        
        /**
         * This is the function that retrieves the details of a particular product
        */
        public function actionthisproductdetailsinformation(){
            
            $model = new User;
            
            $user_id = Yii::app()->user->id;
            if($user_id != null){
                $user_name = $model->getTheNameOfThisUser($user_id);
             }else{
                 $user_name = null;
             }
            
            $product_id = $_REQUEST['product_id'];
            $pricing_id = $_REQUEST['pricing_id'];
            $inventory_id = $_REQUEST['inventory_id'];
            $promotion_id = $_REQUEST['promotion_id'];
            
            $q ="select a.*,c.id as pricing_id, c.price_per_unit as 'price', c.prime_customer_discount_rate,c.inventory_id,c.minimum_order_quantity, c.is_pricing_on_promotion,
                    d.id as promotion_id, d.type, d.pricing_id,d.condition, d.x_quantity, d.y_quantity, d.y_product, d.y_product_quantity,d.y_percentage,d.start_date,d.end_date,
                    (select symbol from measurement_type where id=(select measurement_type_id from pricing where id=c.id)) as unit,c.measurement_type_id as measurement_type_id,
                    (select name from city where id=(select city_id from warehouse where id=(select warehouse_id from inventory where id=$inventory_id and product_id=$product_id))) as city, 
                    (select id from city where id=(select city_id from warehouse where id=(select warehouse_id from inventory where id=$inventory_id and product_id=$product_id))) as warehouse_location_id,
                   (select count(*) from pricing where inventory_id in (select id from inventory where product_id=a.id)) as is_price_variation_applicable,
                   (select name from category where id=(select category_id from sub_category where id=(select subcategory_id from product_type where id=(select product_type_id from product where id=a.id)))) as category_name,
                    (select id from category where id=(select category_id from sub_category where id=(select subcategory_id from product_type where id=(select product_type_id from product where id=a.id)))) as category_id,
                    (select name from merchant where id=(select merchant_id from product where id=a.id)) as merchant_name,
                    (select count(*) from promotion where end_date >= NOW() and pricing_id=c.id) as is_promotion_active from product a
                    JOIN inventory b ON a.id=b.product_id
                    JOIN pricing c ON b.id=c.inventory_id
                    JOIN promotion d ON c.id=d.pricing_id 
                    where d.status='active' and c.id =$pricing_id and d.id=$promotion_id";   
                    
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "product"=>$data,
                                    "user_id"=>$user_id,
                                    "user_name"=>$user_name
                                    
                    
                            ));
            
        }
        
        
        /**
         * This is the function that retrieves the details of a product for a mobile site
         */
        public function actionproductdetailsinformationformobile(){
            $model = new Pricing;
            $product_id = $_REQUEST['product_id'];
            $pricing_id = $_REQUEST['pricing_id'];
            $promotion_id = $_REQUEST['promotion_id'];
            $is_a_prime_member = $_REQUEST['is_a_prime_member'];
            $total_price = $_REQUEST['total_price'];
            $cart_id = $_REQUEST['cart_id'];
            $quantity = $_REQUEST['quantity'];
            $data = [];
            
                $q = "select a.*,c.price_per_unit as 'price', c.inventory_id, c.prime_customer_discount_rate, c.price_per_unit as 'price', (select symbol from measurement_type where id=c.measurement_type_id) as unit,c.measurement_type_id as measurement_type_id,c.minimum_order_quantity,c.is_pricing_on_promotion,
                    d.id as promotion_id, d.type, d.pricing_id,d.condition, d.x_quantity, d.y_quantity, d.y_product, d.y_product_quantity,d.y_percentage,d.start_date,d.end_date,
                    (select name from city where id=(select city_id from warehouse where id=b.warehouse_id)) as city, 
                    (select id from city where id=(select city_id from warehouse where id=b.warehouse_id)) as warehouse_location_id, 
                    (select count(*) from pricing where inventory_id in (select id from inventory where product_id=a.id)) as is_price_variation_applicable,
                    (select name from category where id=(select category_id from sub_category where id=(select subcategory_id from product_type where id=(select product_type_id from product where id=a.id)))) as category_name,
                    (select id from category where id=(select category_id from sub_category where id=(select subcategory_id from product_type where id=(select product_type_id from product where id=a.id)))) as category_id,
                    (select name from merchant where id=(select merchant_id from product where id=a.id)) as merchant_name,
                    (select count(*) from promotion where end_date >= NOW() and pricing_id=c.id) as is_promotion_active from product a
                    JOIN inventory b ON a.id=b.product_id
                    JOIN pricing c ON b.id=c.inventory_id
                    JOIN promotion d ON c.id=d.pricing_id 
                   where d.id=$promotion_id and a.id=$product_id
                    group by a.name";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "product"=>$data,
                                    "is_a_prime_member"=>$is_a_prime_member,
                                    "total_price"=>$total_price,
                                    "cart_id"=>$cart_id,
                                    "quantity"=>$quantity
                                        
                                    
                    
                            ));
                
            
           
            
            
        }
        
        
        /**
         * This is the function that list all products with default pricing in a category
         */
        public function actionlistallproductsinacategoryperunittype(){
           $category = $_REQUEST['category'];
           $unit = $_REQUEST['unit'];
           $is_a_prime_member = $_REQUEST['is_a_prime_member'];
           
           if($is_a_prime_member == 0){
               $data = [];
            $q = "select a.id as category_id, a.name as category_name,d.*, f.price_per_unit as 'price',f.prime_customer_discount_rate,f.id as pricing_id,e.id as inventory_id, e.warehouse_id as warehouse_id,
                f.measurement_type_id as unit_id,f.minimum_order_quantity,f.is_pricing_on_promotion,g.id as promotion_id,g.type,g.condition,g.x_quantity,
                g.y_quantity,g.y_product,g.y_product_quantity,g.y_percentage,g.status,g.start_date,g.end_date,g.available_cities,
                    (select count(*) from promotion where end_date >= NOW() and pricing_id=f.id) as is_promotion_active,
                    (select count(*) from pricing where inventory_id in (select id from inventory where product_id=d.id)) as is_price_variation_applicable,
                    (select name from city where id=(select city_id from warehouse where id=e.warehouse_id)) as city,
                    (select id from city where id=(select city_id from warehouse where id=e.warehouse_id)) as city_id, 
                    (select name from merchant where id=d.merchant_id) as merchant,
                    (select symbol from measurement_type where id=f.measurement_type_id) as unit  from category a 
                    JOIN sub_category b ON a.id=b.category_id
                    JOIN product_type c ON b.id=c.subcategory_id
                    JOIN product d ON c.id=d.product_type_id 
                    JOIN inventory e ON d.id=e.product_id 
                    JOIN pricing f ON e.id=f.inventory_id 
                    JOIN promotion g On f.id=g.pricing_id
                    where f.measurement_type_id=$unit and a.name='$category'
                    group by d.name";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "product"=>$data
                                   
                    
                            ));
               
               
           }else{
               
               
           }
           
        }
        
        
        
        /**
         * This is the function that list all products with default pricing in a category
         */
        public function actionlistallproductsinacategoryperunittypeforngadi(){
           $category = $_REQUEST['category'];
           $unit = $_REQUEST['unit'];
           $is_a_prime_member = $_REQUEST['is_a_prime_member'];
           $location = $_REQUEST['location'];
           $is_with_measurement = $_REQUEST['is_with_measurement'];
           $type = $_REQUEST['type'];
           
           if($location>0){
                if($is_a_prime_member == 0){
               
               if($is_with_measurement == 1){
                  if($unit>0){
                     $data = [];
                 $q = "select a.id as category_id, a.name as category_name,d.*, f.price_per_unit as 'price',f.prime_customer_discount_rate,f.id as pricing_id,e.id as inventory_id, e.warehouse_id as warehouse_id,
                    f.measurement_type_id as unit_id,f.minimum_order_quantity,f.is_pricing_on_promotion,g.id as promotion_id,g.type,g.condition,g.x_quantity,
                    g.y_quantity,g.y_product,g.y_product_quantity,g.y_percentage,g.status,g.start_date,g.end_date,g.available_cities, c.is_with_measurement,
                    (select count(*) from promotion where end_date >= NOW() and pricing_id=f.id) as is_promotion_active,
                    (select count(*) from pricing where inventory_id in (select id from inventory where product_id=d.id)) as is_price_variation_applicable,
                    (select name from city where id=(select city_id from warehouse where id=e.warehouse_id)) as city,
                    (select id from city where id=(select city_id from warehouse where id=e.warehouse_id)) as city_id, 
                    (select name from merchant where id=d.merchant_id) as merchant,
                    (select symbol from measurement_type where id=f.measurement_type_id) as unit  from category a 
                    JOIN sub_category b ON a.id=b.category_id
                    JOIN product_type c ON b.id=c.subcategory_id
                    JOIN product d ON c.id=d.product_type_id 
                    JOIN inventory e ON d.id=e.product_id 
                    JOIN pricing f ON e.id=f.inventory_id 
                    JOIN promotion g On f.id=g.pricing_id
                    where d.status='active' and (a.id=$category and c.id=$type) and (f.measurement_type_id=$unit and e.id in (select id from inventory where warehouse_id in (select id from warehouse where city_id=$location)))
                    group by d.name";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "product"=>$data,
                                   
                                   
                    
                            ));
                       
                   }else{
                          $data = [];
                $q = "select a.id as category_id, a.name as category_name,d.*, f.price_per_unit as 'price',f.prime_customer_discount_rate,f.id as pricing_id,e.id as inventory_id, e.warehouse_id as warehouse_id,
                    f.measurement_type_id as unit_id,f.minimum_order_quantity,f.is_pricing_on_promotion,g.id as promotion_id,g.type,g.condition,g.x_quantity,
                    g.y_quantity,g.y_product,g.y_product_quantity,g.y_percentage,g.status,g.start_date,g.end_date,g.available_cities, c.is_with_measurement,
                    (select count(*) from promotion where end_date >= NOW() and pricing_id=f.id) as is_promotion_active,
                    (select count(*) from pricing where inventory_id in (select id from inventory where product_id=d.id)) as is_price_variation_applicable,
                    (select name from city where id=(select city_id from warehouse where id=e.warehouse_id)) as city,
                    (select id from city where id=(select city_id from warehouse where id=e.warehouse_id)) as city_id, 
                    (select name from merchant where id=d.merchant_id) as merchant,
                    (select symbol from measurement_type where id=f.measurement_type_id) as unit  from category a 
                    JOIN sub_category b ON a.id=b.category_id
                    JOIN product_type c ON b.id=c.subcategory_id
                    JOIN product d ON c.id=d.product_type_id 
                    JOIN inventory e ON d.id=e.product_id 
                    JOIN pricing f ON e.id=f.inventory_id 
                    JOIN promotion g On f.id=g.pricing_id
                    where d.status='active' and (a.id=$category and c.id=$type) and e.id in (select id from inventory where warehouse_id in (select id from warehouse where city_id=$location))
                    group by d.name";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "product"=>$data,
                                   
                                   
                    
                            ));
                   }
                 
                   
                   
                   
               }else{
                    $data = [];
                $q = "select a.id as category_id, a.name as category_name,d.*, f.price_per_unit as 'price',f.prime_customer_discount_rate,f.id as pricing_id,e.id as inventory_id, e.warehouse_id as warehouse_id,
                    f.measurement_type_id as unit_id,f.minimum_order_quantity,f.is_pricing_on_promotion,g.id as promotion_id,g.type,g.condition,g.x_quantity,
                    g.y_quantity,g.y_product,g.y_product_quantity,g.y_percentage,g.status,g.start_date,g.end_date,g.available_cities,c.is_with_measurement,
                    (select count(*) from promotion where end_date >= NOW() and pricing_id=f.id) as is_promotion_active,
                    (select count(*) from pricing where inventory_id in (select id from inventory where product_id=d.id)) as is_price_variation_applicable,
                    (select name from city where id=(select city_id from warehouse where id=e.warehouse_id)) as city,
                    (select id from city where id=(select city_id from warehouse where id=e.warehouse_id)) as city_id, 
                    (select name from merchant where id=d.merchant_id) as merchant,
                    (select symbol from measurement_type where id=f.measurement_type_id) as unit  from category a 
                    JOIN sub_category b ON a.id=b.category_id
                    JOIN product_type c ON b.id=c.subcategory_id
                    JOIN product d ON c.id=d.product_type_id 
                    JOIN inventory e ON d.id=e.product_id 
                    JOIN pricing f ON e.id=f.inventory_id 
                    JOIN promotion g On f.id=g.pricing_id
                    where d.status='active' and (a.id=$category and c.id=$type) and e.id in (select id from inventory where warehouse_id in (select id from warehouse where city_id=$location))
                    group by d.name";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "product"=>$data
                                   
                    
                            ));
                   
                   
               }
               
               
               
           }else{
               
               
           }
               
           }else{
                if($is_a_prime_member == 0){
               
               if($is_with_measurement == 1){
                   
                   if($unit>0){
                       $data = [];
                $q = "select a.id as category_id, a.name as category_name,d.*, f.price_per_unit as 'price',f.prime_customer_discount_rate,f.id as pricing_id,e.id as inventory_id, e.warehouse_id as warehouse_id,
                    f.measurement_type_id as unit_id,f.minimum_order_quantity,f.is_pricing_on_promotion,g.id as promotion_id,g.type,g.condition,g.x_quantity,
                    g.y_quantity,g.y_product,g.y_product_quantity,g.y_percentage,g.status,g.start_date,g.end_date,g.available_cities, c.is_with_measurement,
                    (select count(*) from promotion where end_date >= NOW() and pricing_id=f.id) as is_promotion_active,
                    (select count(*) from pricing where inventory_id in (select id from inventory where product_id=d.id)) as is_price_variation_applicable,
                    (select name from city where id=(select city_id from warehouse where id=e.warehouse_id)) as city,
                    (select id from city where id=(select city_id from warehouse where id=e.warehouse_id)) as city_id, 
                    (select name from merchant where id=d.merchant_id) as merchant,
                    (select symbol from measurement_type where id=f.measurement_type_id) as unit  from category a 
                    JOIN sub_category b ON a.id=b.category_id
                    JOIN product_type c ON b.id=c.subcategory_id
                    JOIN product d ON c.id=d.product_type_id 
                    JOIN inventory e ON d.id=e.product_id 
                    JOIN pricing f ON e.id=f.inventory_id 
                    JOIN promotion g On f.id=g.pricing_id
                    where (d.status='active' and a.id=$category) and (c.id=$type and f.measurement_type_id=$unit)
                    group by d.name";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "product"=>$data,
                                   
                                   
                    
                            ));
                       
                       
                   }else{
                       $data = [];
                $q = "select a.id as category_id, a.name as category_name,d.*, f.price_per_unit as 'price',f.prime_customer_discount_rate,f.id as pricing_id,e.id as inventory_id, e.warehouse_id as warehouse_id,
                    f.measurement_type_id as unit_id,f.minimum_order_quantity,f.is_pricing_on_promotion,g.id as promotion_id,g.type,g.condition,g.x_quantity,
                    g.y_quantity,g.y_product,g.y_product_quantity,g.y_percentage,g.status,g.start_date,g.end_date,g.available_cities, c.is_with_measurement,
                    (select count(*) from promotion where end_date >= NOW() and pricing_id=f.id) as is_promotion_active,
                    (select count(*) from pricing where inventory_id in (select id from inventory where product_id=d.id)) as is_price_variation_applicable,
                    (select name from city where id=(select city_id from warehouse where id=e.warehouse_id)) as city,
                    (select id from city where id=(select city_id from warehouse where id=e.warehouse_id)) as city_id, 
                    (select name from merchant where id=d.merchant_id) as merchant,
                    (select symbol from measurement_type where id=f.measurement_type_id) as unit  from category a 
                    JOIN sub_category b ON a.id=b.category_id
                    JOIN product_type c ON b.id=c.subcategory_id
                    JOIN product d ON c.id=d.product_type_id 
                    JOIN inventory e ON d.id=e.product_id 
                    JOIN pricing f ON e.id=f.inventory_id 
                    JOIN promotion g On f.id=g.pricing_id
                    where d.status='active' and (a.id=$category and c.id=$type)
                    group by d.name";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "product"=>$data,
                                   
                                   
                    
                            ));
                       
                   }
                    
                   
                   
                   
               }else{
                    $data = [];
                $q = "select a.id as category_id, a.name as category_name,d.*, f.price_per_unit as 'price',f.prime_customer_discount_rate,f.id as pricing_id,e.id as inventory_id, e.warehouse_id as warehouse_id,
                    f.measurement_type_id as unit_id,f.minimum_order_quantity,f.is_pricing_on_promotion,g.id as promotion_id,g.type,g.condition,g.x_quantity,
                    g.y_quantity,g.y_product,g.y_product_quantity,g.y_percentage,g.status,g.start_date,g.end_date,g.available_cities,c.is_with_measurement,
                    (select count(*) from promotion where end_date >= NOW() and pricing_id=f.id) as is_promotion_active,
                    (select count(*) from pricing where inventory_id in (select id from inventory where product_id=d.id)) as is_price_variation_applicable,
                    (select name from city where id=(select city_id from warehouse where id=e.warehouse_id)) as city,
                    (select id from city where id=(select city_id from warehouse where id=e.warehouse_id)) as city_id, 
                    (select name from merchant where id=d.merchant_id) as merchant,
                    (select symbol from measurement_type where id=f.measurement_type_id) as unit  from category a 
                    JOIN sub_category b ON a.id=b.category_id
                    JOIN product_type c ON b.id=c.subcategory_id
                    JOIN product d ON c.id=d.product_type_id 
                    JOIN inventory e ON d.id=e.product_id 
                    JOIN pricing f ON e.id=f.inventory_id 
                    JOIN promotion g On f.id=g.pricing_id
                    where d.status='active' and (a.id=$category and c.id=$type)
                    group by d.name";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "product"=>$data
                                   
                    
                            ));
                   
                   
               }
               
               
               
           }else{
               
               
           }
               
           }
           
          
           
        }
        
        
        
        /**
         * This is the function that confirms if a product classification is with items
         */
        public function actionisproductavailableforthisclassification(){
            
            $model = new Product;
            
            $classification = $_REQUEST['classification'];
            
            if($model->isThisClassificationWithProducts($classification)){
                $is_available = true;
                
            }else{
                $is_available = false; 
                
            }
            
            header('Content-Type: application/json');
                            echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                        "is_available" => $is_available
                                    )
                               );
        }
        
        
        
        /**
         * This is the function that retrieves all inactive products
         */
        public function actionretrieveallinactiveproducts(){
            
              $criteria = new CDbCriteria();
              $criteria->select = '*';
              $criteria->condition='status=:status';
              $criteria->params = array(':status'=>"inactive");
              $products= Product::model()->findAll($criteria);
              
              if($products===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                         header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "product" => $products,
                                                                      
                    
                            ));
                       
                       
                }
            
        }
        
        /**
         * This is the function that makes a product active on the platform
         */
        public function actionmakethisproductactive(){
            
            $_id = $_POST['id'];
            $model=Product::model()->findByPk($_id);
            
            $model->status = "active";
            
            if($model->save()){
                 header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "msg" => "'$model->name' product is activated successfully",
                                                                      
                    
                            ));
            }else{
                header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                    "msg" => "Attempt to activate the '$model->name' product was not successful",
                                                                      
                    
                            ));
            }
        }
        
        
        
        
         /**
         * This is the function that retrieves all active products
         */
        public function actionretrieveallactiveproducts(){
            
              $criteria = new CDbCriteria();
              $criteria->select = '*';
              $criteria->condition='status=:status';
              $criteria->params = array(':status'=>"active");
              $products= Product::model()->findAll($criteria);
              
              if($products===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                         header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "product" => $products,
                                                                      
                    
                            ));
                       
                       
                }
            
        }
        
        
         /**
         * This is the function that makes a product active on the platform
         */
        public function actionmakethisproductinactive(){
            
            $_id = $_POST['id'];
            $model=Product::model()->findByPk($_id);
            
            $model->status = "inactive";
            
            if($model->save()){
                 header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "msg" => "'$model->name' product is deactivated successfully",
                                                                      
                    
                            ));
            }else{
                header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                    "msg" => "Attempt to deactivate the '$model->name' product was not successful",
                                                                      
                    
                            ));
            }
        }
        
        public static function actionnnnnSendingEmail(){
            
            //$mail = new YYiiMailer();
            $mail = new YiiMailer();
           
            //$mail->CharSet = 'UTF-8';
            //$mail->Encoding = 'base64';
            $sender = 'info@ngadi.com.ng';
            $senderName = 'Ngadi Uche';
            $recipient = 'info@aftertaste.com.ng';
            $usernameSmtp = 'AKIA4CGY2U3DFWRBR2XT';
            $passwordSmtp = 'BMTvWnxmz9XiyYeQremM/E8hlDMSyF99Wwc32xDNk1us';
             //$configurationSet = 'ConfigSet';
            // endpoint in the appropriate region.
            $host = 'email-smtp.us-east-1.amazonaws.com';
             $port = 587;
            $subject = 'Amazon SES test (SMTP interface accessed using PHP)';
            // The plain-text body of the email
            $bodyText =  'Email Test.This email was sent through the Amazon SES SMTP interface using the PHPMailer class.';
            // The HTML-formatted body of the email
            $bodyHtml = 'Hello, my friend This message uses non HTML!';
            
            $mailContent = "<h1>Send HTML Email using SMTP in PHP</h1>
                            <p>This is a test email I’m sending using SMTP mail server with PHPMailer.</p>";
            
             //$mail->SMTPDebug = 4;
              // Specify the SMTP settings.
                $mail->isSMTP();
                $mail->setFrom($sender, $senderName);
                $mail->Username   = $usernameSmtp;
                $mail->Password   = $passwordSmtp;
                $mail->Host       = $host;
                $mail->Port       = $port;
                //$mail->ContentType = "text/html; charset=UTF-8";
               $mail->SMTPAuth   = true;
               $mail->SMTPSecure = 'tls';
            
               
                //$mail->addCustomHeader('X-SES-CONFIGURATION-SET', $configurationSet);

                // Specify the message recipients.
                $mail->addAddress($recipient);
                // You can also add CC, BCC, and additional To recipients here.

                // Specify the content of the message.
                
                $mail->Subject    = $subject;
                $mail->Body = $mailContent;
                $mail->isHTML(true);
                $mail->AltBody = $mail->setAltText("this is the alternative test");
                              
                echo $mail->Body;
                if($mail->Send()){
                    echo 'Message has been sent';
                }else{
                    echo $mail->AltBody;
                    echo 'Message could not be sent.';
                    echo 'Mailer Error: ' . $mail->ErrorInfo;
                 }
             
            
  }
        
        
        public function actionSendingEmail(){
           $recipients = array('uchengadi@yahoo.com');		
           $recipientsName = array('Uche Ngadi P.');
            $mail = Yii::app()->sendgrid->sendMail($recipients, $recipientsName, '', 'Subject', 'Sent with SendGrid from Mr Iacobelli', 'text', 'uchengadi@naijafarmmart.com.ng', 'uchengadi@naijafarmmart.com.ng', 'FromName', 'uchengadi@naijafarmmart.com.ng');
            
             header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "msg" => $mail,
                                                                      
                    
                            ));
        }
        
        
         public function actionSms(){
           $recipients = array('uchengadi@yahoo.com');		
           $recipientsName = array('Uche Ngadi P.');
            $mail = Yii::app()->sendgrid->sendMail($recipients, $recipientsName, '', 'Subject', 'Sent with SendGrid from Mr Iacobelli', 'text', 'uchengadi@naijafarmmart.com.ng', 'uchengadi@naijafarmmart.com.ng', 'FromName', 'uchengadi@naijafarmmart.com.ng');
            
             header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "msg" => $mail,
                                                                      
                    
                            ));
        }
        
        
        
        /**
         * This is the function that retrieves all the products in a slot
         * 
         */
        public function actionretrieveallproductsinaslot(){
            $model = new BuyerCommunity;
            $slot_id = $_REQUEST['slot_id'];
            $community_id = $_REQUEST['community_id'];
            
           $required_community_membership_number = (int)$model->getTheRequiredCommunityMembershipNumberOfThisCommunity($community_id);
                       
        
           
           if($required_community_membership_number == 5){
                $q = "select b.*,FORMAT(ROUND((b.price_per_unit - (b.price_per_unit * b.at_5_items_bulk_purchase_discount_rate/100) ),2),2) as 'price',d.*,  a.required_quantity ,
                (select symbol from measurement_type where id=b.measurement_type_id) as unit  from slot_has_product a 
                    JOIN pricing b ON a.pricing_id=b.id 
                    JOIN inventory c ON b.inventory_id=c.id 
                    JOIN product d ON c.product_id=d.id
                    where d.status='active' and a.slot_id=$slot_id
                    group by b.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
              header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "product"=>$data,
                                   
                                   
                    
                            ));
               
           }else if($required_community_membership_number == 10){
               $q = "select b.*,FORMAT(ROUND((b.price_per_unit - (b.price_per_unit * b.at_10_items_bulk_purchase_discount_rate/100) ),2),2) as 'price',d.*,  a.required_quantity ,
                (select symbol from measurement_type where id=b.measurement_type_id) as unit  from slot_has_product a 
                    JOIN pricing b ON a.pricing_id=b.id 
                    JOIN inventory c ON b.inventory_id=c.id 
                    JOIN product d ON c.product_id=d.id
                    where d.status='active' and a.slot_id=$slot_id
                    group by b.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
              header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "product"=>$data,
                                   
                                   
                    
                            ));
               
           }else if($required_community_membership_number == 20){
               $q = "select b.*,FORMAT(ROUND((b.price_per_unit - (b.price_per_unit * b.at_20_items_bulk_purchase_discount_rate/100) ),2),2) as 'price',d.*,  a.required_quantity ,
                (select symbol from measurement_type where id=b.measurement_type_id) as unit  from slot_has_product a 
                    JOIN pricing b ON a.pricing_id=b.id 
                    JOIN inventory c ON b.inventory_id=c.id 
                    JOIN product d ON c.product_id=d.id
                    where d.status='active' and a.slot_id=$slot_id
                    group by b.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
              header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "product"=>$data,
                                   
                                   
                    
                            ));
               
           }else if($required_community_membership_number == 30){
               $q = "select b.*,FORMAT(ROUND((b.price_per_unit - (b.price_per_unit * b.at_30_items_bulk_purchase_discount_rate/100) ),2),2) as 'price',d.*,  a.required_quantity ,
                (select symbol from measurement_type where id=b.measurement_type_id) as unit  from slot_has_product a 
                    JOIN pricing b ON a.pricing_id=b.id 
                    JOIN inventory c ON b.inventory_id=c.id 
                    JOIN product d ON c.product_id=d.id
                    where d.status='active' and a.slot_id=$slot_id
                    group by b.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
              header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "product"=>$data,
                                   
                                   
                    
                            ));
               
               
           }else if($required_community_membership_number == 40){
               
               $q = "select b.*,FORMAT(ROUND((b.price_per_unit - (b.price_per_unit * b.at_40_items_bulk_purchase_discount_rate/100) ),2),2) as 'price',d.*,  a.required_quantity ,
                (select symbol from measurement_type where id=b.measurement_type_id) as unit  from slot_has_product a 
                    JOIN pricing b ON a.pricing_id=b.id 
                    JOIN inventory c ON b.inventory_id=c.id 
                    JOIN product d ON c.product_id=d.id
                    where d.status='active' and a.slot_id=$slot_id
                    group by b.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
              header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "product"=>$data,
                                   
                                   
                    
                            ));
               
           }else if($required_community_membership_number == 50){
               $q = "select b.*,FORMAT(ROUND((b.price_per_unit - (b.price_per_unit * b.at_50_items_bulk_purchase_discount_rate/100) ),2),2) as 'price',d.*,  a.required_quantity ,
                (select symbol from measurement_type where id=b.measurement_type_id) as unit  from slot_has_product a 
                    JOIN pricing b ON a.pricing_id=b.id 
                    JOIN inventory c ON b.inventory_id=c.id 
                    JOIN product d ON c.product_id=d.id
                    where d.status='active' and a.slot_id=$slot_id
                    group by b.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
              header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "product"=>$data,
                                   
                                   
                    
                            ));
               
               
           }else if($required_community_membership_number == 60){
               $q = "select b.*,FORMAT(ROUND((b.price_per_unit - (b.price_per_unit * b.at_60_items_bulk_purchase_discount_rate/100) ),2),2) as 'price',d.*,  a.required_quantity ,
                (select symbol from measurement_type where id=b.measurement_type_id) as unit  from slot_has_product a 
                    JOIN pricing b ON a.pricing_id=b.id 
                    JOIN inventory c ON b.inventory_id=c.id 
                    JOIN product d ON c.product_id=d.id
                    where d.status='active' and a.slot_id=$slot_id
                    group by b.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
              header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "product"=>$data,
                                   
                                   
                    
                            ));
               
               
           }else if($required_community_membership_number == 70){
               $q = "select b.*,FORMAT(ROUND((b.price_per_unit - (b.price_per_unit * b.at_70_items_bulk_purchase_discount_rate/100) ),2),2) as 'price',d.*,  a.required_quantity ,
                (select symbol from measurement_type where id=b.measurement_type_id) as unit  from slot_has_product a 
                    JOIN pricing b ON a.pricing_id=b.id 
                    JOIN inventory c ON b.inventory_id=c.id 
                    JOIN product d ON c.product_id=d.id
                    where d.status='active' and a.slot_id=$slot_id
                    group by b.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
              header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "product"=>$data,
                                   
                                   
                    
                            ));
               
               
           }else if($required_community_membership_number == 80){
                $q = "select b.*,FORMAT(ROUND((b.price_per_unit - (b.price_per_unit * b.at_80_items_bulk_purchase_discount_rate/100) ),2),2) as 'price',d.*,  a.required_quantity ,
                (select symbol from measurement_type where id=b.measurement_type_id) as unit  from slot_has_product a 
                    JOIN pricing b ON a.pricing_id=b.id 
                    JOIN inventory c ON b.inventory_id=c.id 
                    JOIN product d ON c.product_id=d.id
                    where d.status='active' and a.slot_id=$slot_id
                    group by b.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
              header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "product"=>$data,
                                   
                                   
                    
                            ));
               
               
           }elseif($required_community_membership_number == 90){
                $q = "select b.*,FORMAT(ROUND((b.price_per_unit - (b.price_per_unit * b.at_90_items_bulk_purchase_discount_rate/100) ),2),2) as 'price',d.*,  a.required_quantity ,
                (select symbol from measurement_type where id=b.measurement_type_id) as unit  from slot_has_product a 
                    JOIN pricing b ON a.pricing_id=b.id 
                    JOIN inventory c ON b.inventory_id=c.id 
                    JOIN product d ON c.product_id=d.id
                    where d.status='active' and a.slot_id=$slot_id
                    group by b.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
              header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "product"=>$data,
                                   
                                   
                    
                            ));
               
               
           }else if($required_community_membership_number == 100){
               
                $q = "select b.*, FORMAT(ROUND((b.price_per_unit - (b.price_per_unit * b.at_100_items_bulk_purchase_discount_rate/100) ),2),2) as 'price',d.*,  a.required_quantity ,
                (select symbol from measurement_type where id=b.measurement_type_id) as unit  from slot_has_product a 
                    JOIN pricing b ON a.pricing_id=b.id 
                    JOIN inventory c ON b.inventory_id=c.id 
                    JOIN product d ON c.product_id=d.id
                    where d.status='active' and a.slot_id=$slot_id
                    group by b.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
              header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "product"=>$data,
                                    "members"=>$required_community_membership_number
                                   
                                   
                    
                            ));
               
               
           }else if($required_community_membership_number == 150){
                $q = "select b.*, FORMAT(ROUND((b.price_per_unit - (b.price_per_unit * b.at_150_items_bulk_purchase_discount_rate/100) ),2),2) as 'price',d.*,  a.required_quantity ,
                (select symbol from measurement_type where id=b.measurement_type_id) as unit  from slot_has_product a 
                    JOIN pricing b ON a.pricing_id=b.id 
                    JOIN inventory c ON b.inventory_id=c.id 
                    JOIN product d ON c.product_id=d.id
                    where d.status='active' and a.slot_id=$slot_id
                    group by b.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
              header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "product"=>$data,
                                    "members"=>$required_community_membership_number
                                   
                                   
                    
                            ));
               
           }else if($required_community_membership_number == 200){
                $q = "select b.*,FORMAT(ROUND((b.price_per_unit - (b.price_per_unit * b.at_200_items_bulk_purchase_discount_rate/100) ),2),2) as 'price',d.*,  a.required_quantity ,
                (select symbol from measurement_type where id=b.measurement_type_id) as unit  from slot_has_product a 
                    JOIN pricing b ON a.pricing_id=b.id 
                    JOIN inventory c ON b.inventory_id=c.id 
                    JOIN product d ON c.product_id=d.id
                    where d.status='active' and a.slot_id=$slot_id
                    group by b.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
              header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "product"=>$data,
                                   "members"=>$required_community_membership_number
                                   
                    
                            ));
               
           }
           
        }
        
}
