<?php

class ClassificationController extends Controller
{
	/**
	 * @var string the default layout for the views. Defaults to '//layouts/column2', meaning
	 * using two-column layout. See 'protected/views/layouts/column2.php'.
	 */
	public $layout='//layouts/column2';

	/**
	 * @return array action filters
	 */
	public function filters()
	{
		return array(
			'accessControl', // perform access control for CRUD operations
			'postOnly + delete', // we only allow deletion via POST request
		);
	}

	/**
	 * Specifies the access control rules.
	 * This method is used by the 'accessControl' filter.
	 * @return array access control rules
	 */
	public function accessRules()
	{
		return array(
			array('allow',  // allow all users to perform 'index' and 'view' actions
				'actions'=>array('index','view'),
				'users'=>array('*'),
			),
			array('allow', // allow authenticated user to perform 'create' and 'update' actions
				'actions'=>array('create','update','listAllClassifications','addnewclassification','deleteoneclassification','updateclassification'),
				'users'=>array('@'),
			),
			array('allow', // allow admin user to perform 'admin' and 'delete' actions
				'actions'=>array('admin','delete'),
				'users'=>array('admin'),
			),
			array('deny',  // deny all users
				'users'=>array('*'),
			),
		);
	}

	
         /**
         * This is the function that list all classifcations on the platform
         */
        public function actionlistAllClassifications(){
            
            $model = new Classification;
            
             $classifications = Classification::model()->findAll();
                if($classifications===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                        header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "classification" => $classifications,
                                   
                    
                            ));
                       
                }
        }
        
        
         /**
         * This is the function that adds new Classification
         */
        public function actionaddnewclassification(){
            
            $model=new Classification;

		
		$model->name = $_POST['name'];
               if(isset($_POST['description'])){
                   $model->description = $_POST['description']; 
                }
                if(isset($_POST['code'])){
                   $model->code = $_POST['code']; 
                }
                $model->create_time = new CDbExpression('NOW()');
                $model->create_user_id = Yii::app()->user->id;
                if($model->isThisCodeUnique($model->code)){
                     if($model->save()){
                         // $result['success'] = 'true';
                          $msg = 'Successfully created new classification';
                          header('Content-Type: application/json');
                          echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                        "msg" => $msg)
                           );
                     }else {
                         //$result['success'] = 'false';
                         $msg = 'New classification creation was unsuccessful';
                         header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                        "msg" => $msg)
                           );
                    } 
                    
                    
                }else{
                     $msg = 'The classification code you provided is already in use. Please use another and try again';
                         header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                        "msg" => $msg)
                           );
                    
                }
              
        
            
        }
        
        
         /**
         * This is the function that updates classification
         */
        public function actionupdateclassification(){
            
           $_id = $_POST['id'];
            
           $model= Classification::model()->findByPk($_id);

		
               $model->name = $_POST['name'];
               if(isset($_POST['description'])){
                   $model->description = $_POST['description']; 
                }
                 if(isset($_POST['code'])){
                   $model->code = $_POST['code']; 
                }
                $model->update_time = new CDbExpression('NOW()');
                $model->update_user_id = Yii::app()->user->id;
               if($model->isThisUpdatedDomainCodeUnique($model->code,$_id)){
                   if($model->save()){
                         // $result['success'] = 'true';
                          $msg = "Successfully updated the '$model->name'  classification";
                          header('Content-Type: application/json');
                          echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                        "msg" => $msg)
                           );
                     }else {
                         //$result['success'] = 'false';
                         $msg = "Attempt to update the '$model->name' classification was unsuccessful";
                         header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                        "msg" => $msg)
                           );
                    } 
                   
                   
               }else{
                   $msg = 'Duplicate Code: This code is already in use. Please use another';
                            header('Content-Type: application/json');
                            echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                        "msg" => $msg)
                               );
                        
                   
                   
               }  
               
        
            
        }
        
        
        /**
	 * Deletes a particular model instance
	 * 
         **/
	public function actiondeleteoneclassification()
	{
            
            $_id = $_REQUEST['id'];
            $model= Classification::model()->findByPk($_id);
            
           if($model === null){
                $data['success'] = 'undefined';
                $data['msg'] = 'No such record exist';
                header('Content-Type: application/json');
                echo CJSON::encode($data);
                                      
            }else if($model->delete()){
                    $data['success'] = 'true';
                    $data['msg'] = "'$model->name' classification was successfully deleted";
                     header('Content-Type: application/json');
                    echo CJSON::encode($data);
            } else {
                    $data['success'] = 'false';
                    $data['msg'] = 'deletion unsuccessful';
                     header('Content-Type: application/json');
                    echo CJSON::encode($data);
                            
                }
	}

	
        
        
}
