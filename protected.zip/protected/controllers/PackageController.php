<?php

class PackageController extends Controller
{
	/**
	 * @var string the default layout for the views. Defaults to '//layouts/column2', meaning
	 * using two-column layout. See 'protected/views/layouts/column2.php'.
	 */
	public $layout='//layouts/column2';

	/**
	 * @return array action filters
	 */
	public function filters()
	{
		return array(
			'accessControl', // perform access control for CRUD operations
			'postOnly + delete', // we only allow deletion via POST request
		);
	}

	/**
	 * Specifies the access control rules.
	 * This method is used by the 'accessControl' filter.
	 * @return array access control rules
	 */
	public function accessRules()
	{
		return array(
			array('allow',  // allow all users to perform 'index' and 'view' actions
				'actions'=>array('index','view'),
				'users'=>array('*'),
			),
			array('allow', // allow authenticated user to perform 'create' and 'update' actions
				'actions'=>array('create','update','listAllOpenPackagesForAnOrderCreatedByAUser','removepackage','createnewpackage',
                                    'modifythispackage','getpackagedetails','openpackage','closepackage','listAllPackagesForAnOrderCreatedByAUser',
                                    'listallPackagesForDeliveryWithinACityAssignedToACourier'),
				'users'=>array('@'),
			),
			array('allow', // allow admin user to perform 'admin' and 'delete' actions
				'actions'=>array('admin','delete'),
				'users'=>array('admin'),
			),
			array('deny',  // deny all users
				'users'=>array('*'),
			),
		);
	}

	

	/**
         * This is the function that list all open packages for an order created by this user
         */
        public function actionlistAllOpenPackagesForAnOrderCreatedByAUser(){
            
            $user_id = Yii::app()->user->id;
            
            $order_id = $_REQUEST['order_id'];
            
            $criteria = new CDbCriteria();
              $criteria->select = '*';
              $criteria->condition='order_id=:orderid and (create_user_id=:userid and status=:status)';
              $criteria->params = array(':status'=>"open",':orderid'=>$order_id,':userid'=>$user_id);
              $packages= Package::model()->findAll($criteria);
              
              header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "package" => $packages,
                                   
                    
                            ));
            
        }
        
        
        /**
         * This is the function that list all open packages for an order created by this user
         */
        public function actionlistAllPackagesForAnOrderCreatedByAUser(){
            
            $user_id = Yii::app()->user->id;
            
            $order_id = $_REQUEST['order_id'];
            
            $criteria = new CDbCriteria();
              $criteria->select = '*';
              $criteria->condition='order_id=:orderid and create_user_id=:userid';
              $criteria->params = array(':orderid'=>$order_id,':userid'=>$user_id);
              $packages= Package::model()->findAll($criteria);
              
              header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "package" => $packages,
                                   
                    
                            ));
            
        }
        
        
        /**
         * This is the function that adds or creates new package
         */
        public function actioncreatenewpackage(){
            $model = new Package;
            
             $model->name = $_REQUEST['name'];
             $model->order_id = $_REQUEST['order_id'];
             $model->package_type = $_REQUEST['package_type'];
             $model->status = "open";
             
             $model->create_time = new CDbExpression('NOW()');
             $model->create_user_id = Yii::app()->user->id;
             
             if($model->save()){
                 $msg = "'$model->name' package is created successfully";
                                 header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                 "success" => mysqli_connect_errno() == 0,
                                  "msg" => $msg)
                            );
                 
             }else{
                  $msg = 'Validaion Error: Attempt to create this new package failed. Please try again';
                            header('Content-Type: application/json');
                            echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                        "msg" => $msg)
                               );
             }
        }
        
        
        /**
         * This is the function that adds or creates new package
         */
        public function actionmodifythispackage(){
             $id = $_POST['id'];
             $model= Package::model()->findByPk($id);
            
             $model->name = $_REQUEST['name'];
             $model->order_id = $_REQUEST['order_id'];
             $model->package_type = $_REQUEST['package_type'];
             $model->status = "open";
             
             $model->update_time = new CDbExpression('NOW()');
             $model->update_user_id = Yii::app()->user->id;
             
             if($model->save()){
                 $msg = "'$model->name' package is updated successfully";
                                 header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                 "success" => mysqli_connect_errno() == 0,
                                  "msg" => $msg)
                            );
                 
             }else{
                  $msg = 'Validaion Error: Attempt to update this package failed. Please try again';
                            header('Content-Type: application/json');
                            echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                        "msg" => $msg)
                               );
             }
        }
        
        
        
        /**
         * This is the function that deletes a package from the database
         */
        public function actionremovepackage(){
            
            $_id = $_POST['package_id'];
            $model=Package::model()->findByPk($_id);
                
            
            if($model->delete()){
                $msg = "This package is removed successfully";
                                 header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                 "success" => mysqli_connect_errno() == 0,
                                  "msg" => $msg)
                            );
            }else{
                 $msg = 'Error: Attempt to remove this package failed. Please try again';
                            header('Content-Type: application/json');
                            echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                        "msg" => $msg)
                               );
            }
            
            
            
        }
        
        
        /**
         * This is the function that gets a package details
         */
        public function actiongetpackagedetails(){
            $model = new Package;
            
            $package_id = $_REQUEST['package_id'];
            
             $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$package_id);
            $items= Package::model()->findAll($criteria);
            
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    //"order" => $items,
                                    "pack"=>$items,
                                   
                            ));
            
        }
        
        /**
         * This is the function that closes a package
         */
        public function actionclosepackage(){
            
            $_id = $_POST['package_id'];
            $model=Package::model()->findByPk($_id);
              
            $model->status = "closed";
            
            if($model->isThisPackageOpen($_id)){
                if($model->save()){
                $msg = "This package is successfully closed";
                                 header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                 "success" => mysqli_connect_errno() == 0,
                                  "msg" => $msg)
                            );
            }else{
                 $msg = 'Error: Attempt to close this package failed';
                            header('Content-Type: application/json');
                            echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                        "msg" => $msg)
                               );
            }
                
                
            }else{
                $msg = 'This package is already closed, therefore the request is ignored';
                            header('Content-Type: application/json');
                            echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                        "msg" => $msg)
                               );
                
            }
            
            
            
            
            
        }
        
        
         /**
         * This is the function that opens a package
         */
        public function actionopenpackage(){
            
            $_id = $_POST['package_id'];
            $model=Package::model()->findByPk($_id);
              
            $model->status = "open";
            
            if($model->isThisPackageOpen($_id)== false){
                if($model->save()){
                $msg = "This package is successfully opened";
                                 header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                 "success" => mysqli_connect_errno() == 0,
                                  "msg" => $msg)
                            );
            }else{
                 $msg = 'Error: Attempt to open this package failed';
                            header('Content-Type: application/json');
                            echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                        "msg" => $msg)
                               );
            }
                
                
            }else{
                $msg = 'This package is already open, therefore the request is ignored';
                            header('Content-Type: application/json');
                            echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                        "msg" => $msg)
                               );
                
            }
            
            
            
            
            
        }
        
        
        /**
         * This is the function that list all packages for delivery for a courier within a city 
         */
        public function actionlistallPackagesForDeliveryWithinACityAssignedToACourier(){
            
             $model = new User;
            
            $user_id = Yii::app()->user->id;
            
            //get the contractor id of this user
            $contractor_id = $model->getTheContractorIdOfThisUser($user_id);
            
            $city_id = $_REQUEST['city_id'];
            
            //get all the open orders assigned to this carrier in this city
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='delivery_city_id=:delid  and status=:status';
            $criteria->params = array(':delid'=>$city_id,':status'=>"open");
            $orders= Order::model()->findAll($criteria);
            
            $target = [];
            $package_orders = [];
            
            //get the package orders
            foreach($orders as $order){
                if($this->isThisOrderAssignedToThisCarrier($order['id'],$contractor_id)){
                    $package_orders[] = $order['id'];
                }
            }
            
            //retrieve all the packages
            foreach($package_orders as $pack){
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='order_id=:orderid  and status=:status';
                $criteria->params = array(':orderid'=>$pack,':status'=>"closed");
                $packages= Package::model()->findAll($criteria);
                
                foreach($packages as $pack){
                     $target[] = $pack;
                }
               
                
            }
            
             header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                        "package" => $target)
                           );
        }
        
        
        /**
         * this is the function that confirms if an order is assigned to a contractor
         */
        public function isThisOrderAssignedToThisCarrier($order_id,$contractor_id){
            $model = new OrderItem;
            return $model->isThisOrderAssignedToThisCarrier($order_id,$contractor_id);
        }
        
        
       
        
}
