<?php

class MembershipController extends Controller
{
	/**
	 * @var string the default layout for the views. Defaults to '//layouts/column2', meaning
	 * using two-column layout. See 'protected/views/layouts/column2.php'.
	 */
	public $layout='//layouts/column2';

	/**
	 * @return array action filters
	 */
	public function filters()
	{
		return array(
			'accessControl', // perform access control for CRUD operations
			'postOnly + delete', // we only allow deletion via POST request
		);
	}

	/**
	 * Specifies the access control rules.
	 * This method is used by the 'accessControl' filter.
	 * @return array access control rules
	 */
	public function accessRules()
	{
		return array(
			array('allow',  // allow all users to perform 'index' and 'view' actions
				'actions'=>array('index','view'),
				'users'=>array('*'),
			),
			array('allow', // allow authenticated user to perform 'create' and 'update' actions
				'actions'=>array('create','update','addnewMembershipSubscription','updateMembershipSubcription'),
				'users'=>array('@'),
			),
			array('allow', // allow admin user to perform 'admin' and 'delete' actions
				'actions'=>array('admin','delete'),
				'users'=>array('admin'),
			),
			array('deny',  // deny all users
				'users'=>array('*'),
			),
		);
	}

	 /**
         * This is the function that adds a new membersip type
         */
        public function actionaddnewMembershipSubscription(){
            
            $model = new Membership;
            
           
            if($model->isThisUserAlreadyMember($_REQUEST['user_id']) == false){
                $duration = $_REQUEST['duration'];
                $period = $_REQUEST['period'];
                $subscription_end_date = $model->getSubscriptionEndDate($duration,"$period");
                $total_amount = (double)$_REQUEST['total_amount'];
                $model->member_id = $_REQUEST['user_id'];
                $model->monthly_membership_fee =$_REQUEST['amount_per_duration'];
                $model->membership_type = $_REQUEST['type'];
                $model->status = "pending_activation";
                $model->membership_number = $model->generateMembershipNumber();
                $model->subscription_start_date = new CDbExpression('NOW()');
                $model->membership_start_date = new CDbExpression('NOW()');
                $model->subscription_end_date = $subscription_end_date;
                $model->total_amount_paid=$total_amount;
                $model->payment_status="pending";
                
                if($model->save()){
                    header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                        "amount" => $total_amount,
                                        "membership_number"=>$model->membership_number,
                                        "is_a_member"=>0,
                                        "email"=>$this->getTheEmailAddressOfThisUser($model->member_id)
                                )
                           );
                
                    
                }else{
                    $msg ="Validation issues: Please check your input data and try again";
                    header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                        "msg" => $msg,
                                        
                                )
                           );
                
                }
            
                
            }else{
                $msg = "You are already a Prime Member in Ngadi  marketplace. You may however choose to renew your membership if it had expired.Use the 'Account' button for that";
                header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                        "msg" => $msg,
                                        "is_a_member"=>1
                                        
                                )
                           );
                
            }
                        
            
        }
        
        
        /**
         * This is the function that retrieves the email address of a user
         */
        public function getTheEmailAddressOfThisUser($user_id){
            $model = new User;
            return $model->getTheEmailAddressOfThisUser($user_id);
            
        }
        
        
        /**
         * This is the function that updates membership information
         */
        public function actionupdateMembershipSubcription(){
             $_id = $_POST['membership_id'];
             $model= Membership::model()->findByPk($_id);
             
                $duration = $_REQUEST['duration'];
                $period = $_REQUEST['period'];
                $subscription_end_date = $model->getSubscriptionEndDate($duration,"$period");
                $total_amount = (double)$_REQUEST['total_amount'];
                $model->member_id = $_REQUEST['user_id'];
                $model->monthly_membership_fee =$_REQUEST['amount_per_duration'];
                $model->membership_type = $_REQUEST['type'];
                $model->subscription_start_date = new CDbExpression('NOW()');
                $model->subscription_end_date = $subscription_end_date;
                $model->total_amount_paid=$total_amount;
                $model->payment_status="pending";
                
                $membership_number = $model->membership_number . $model->generateTheRandomNumber();
                
                if($model->save()){
                    header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                        "amount" => $total_amount,
                                        "membership_number"=>$membership_number,
                                        "is_a_member"=>0,
                                        "email"=>$this->getTheEmailAddressOfThisUser($model->member_id)
                                )
                           );
                
                    
                }else{
                    $msg ="Validation issues: Please check your input data and try again";
                    header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                        "msg" => $msg,
                                        
                                )
                           );
                
                }
             
             
            
        }
}
