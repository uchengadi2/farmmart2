<?php

class ClusterController extends Controller
{
	/**
	 * @var string the default layout for the views. Defaults to '//layouts/column2', meaning
	 * using two-column layout. See 'protected/views/layouts/column2.php'.
	 */
	public $layout='//layouts/column2';

	/**
	 * @return array action filters
	 */
	public function filters()
	{
		return array(
			'accessControl', // perform access control for CRUD operations
			'postOnly + delete', // we only allow deletion via POST request
		);
	}

	/**
	 * Specifies the access control rules.
	 * This method is used by the 'accessControl' filter.
	 * @return array access control rules
	 */
	public function accessRules()
	{
		return array(
			array('allow',  // allow all users to perform 'index' and 'view' actions
				'actions'=>array('index','view'),
				'users'=>array('*'),
			),
			array('allow', // allow authenticated user to perform 'create' and 'update' actions
				'actions'=>array('create','update','listAllcluster','deleteonecluster','addnewcluster','modifycluster','setintraclusterdeliveryrates'),
				'users'=>array('@'),
			),
			array('allow', // allow admin user to perform 'admin' and 'delete' actions
				'actions'=>array('admin','delete'),
				'users'=>array('admin'),
			),
			array('deny',  // deny all users
				'users'=>array('*'),
			),
		);
	}

	/**
         * This is the function that list all cluster
         */
        public function actionlistAllcluster(){
            
            $model = new Cluster;
            
             $cluster = Cluster::model()->findAll();
              header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                    "cluster" => $cluster,
                                   
                    
                            ));
        }
        
        
        /**
         * This is the function that adds a new cluster
         */
        public function actionaddnewcluster(){
            
            $model=new Cluster;

		
		$model->name = $_POST['name'];
                if(isset($_POST['description'])){
                   $model->description = $_POST['description']; 
                }
                
                $model->create_time = new CDbExpression('NOW()');
                $model->create_user_id = Yii::app()->user->id;
                if($model->save()){
                         // $result['success'] = 'true';
                          $msg = 'Successfully created new cluster';
                          header('Content-Type: application/json');
                          echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                        "msg" => $msg)
                           );
                     }else {
                         //$result['success'] = 'false';
                         $msg = 'New cluster creation was unsuccessful';
                         header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysql_errno() != 0,
                                        "msg" => $msg)
                           );
                    } 
            
        }
        
        
         /**
         * This is the function that modifies cluster
         */
        public function actionmodifycluster(){
            
             $_id = $_POST['id'];
             $model= Cluster::model()->findByPk($_id);		
		$model->name = $_POST['name'];
                if(isset($_POST['description'])){
                   $model->description = $_POST['description']; 
                }
                
                $model->update_time = new CDbExpression('NOW()');
                $model->update_user_id = Yii::app()->user->id;
                if($model->save()){
                         // $result['success'] = 'true';
                          $msg = 'Successfully updated cluster information';
                          header('Content-Type: application/json');
                          echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                        "msg" => $msg)
                           );
                     }else {
                         //$result['success'] = 'false';
                         $msg = 'This new cluster update was unsuccessful';
                         header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysql_errno() != 0,
                                        "msg" => $msg)
                           );
                    } 
        }
        
        
        /**
	 * Deletes a particular model instance
	 * 
         **/
	public function actiondeleteonecluster()
	{
            
            $_id = $_REQUEST['id'];
            $model= Cluster::model()->findByPk($_id);
            
            //get the neighbourhood name
            $name = $_REQUEST['name'];
            
            if($model === null){
                $data['success'] = 'undefined';
                $data['msg'] = 'No such record exist';
                header('Content-Type: application/json');
                echo CJSON::encode($data);
                                      
            }else if($model->delete()){
                    $data['success'] = 'true';
                    $data['msg'] = "'$name' cluster was successfully deleted";
                     header('Content-Type: application/json');
                    echo CJSON::encode($data);
            } else {
                    $data['success'] = 'false';
                    $data['msg'] = 'deletion unsuccessful';
                     header('Content-Type: application/json');
                    echo CJSON::encode($data);
                            
                }
	}
        
        
        /**
         * This is the function that sets the intra cluster delivery rate of a cluster
         */
        public function actionsetintraclusterdeliveryrates(){
            
                   
            $_id = $_REQUEST['id'];
            
            $model=  Cluster::model()->findByPk($_id);
            $model->name = $_REQUEST['name'];
            //set standard intra cluster rate
            $model->intra_cluster_base_rate = $_REQUEST['intra_cluster_base_rate'];
            $model->intra_cluster_maximum_base_weight = $_REQUEST['intra_cluster_maximum_base_weight'];
            $model->intra_cluster_per_additional_kg = $_REQUEST['intra_cluster_per_additional_kg'];
            
            //set priority intra cluster rate
            $model->intra_cluster_base_rate_priority = $_REQUEST['intra_cluster_base_rate_priority'];
            $model->intra_cluster_maximum_base_weight_priority = $_REQUEST['intra_cluster_maximum_base_weight_priority'];
            $model->intra_cluster_per_additional_kg_priority = $_REQUEST['intra_cluster_per_additional_kg_priority'];
            
            //set samedaay intra cluster rate
            $model->intra_cluster_base_rate_sameday = $_REQUEST['intra_cluster_base_rate_sameday'];
            $model->intra_cluster_maximum_base_weight_sameday = $_REQUEST['intra_cluster_maximum_base_weight_sameday'];
            $model->intra_cluster_per_additional_kgsameday = $_REQUEST['intra_cluster_per_additional_kgsameday'];
            $model->update_time = new CDbExpression('NOW()');
            //$model->update_user_id = Yii::app()->user->id;
            if($model->save()){
                       // $data['success'] = 'true';
                        $msg = 'The intra cluster delivery rate for this cluster is successfully set or modified';
                         header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                        "msg" => $msg)
                           );
                }else {
                   // $data['success'] = 'false';
                    $msg = 'Attempt to set or modify the intra cluster delivery rate for this cluster failed';
                     header('Content-Type: application/json');
                     echo CJSON::encode(array(
                                    "success" => mysql_errno() != 0,
                                        "msg" => $msg)
                           );
                }
        }
}
