<?php

class NeighbourhoodCitiesController extends Controller
{
	/**
	 * @var string the default layout for the views. Defaults to '//layouts/column2', meaning
	 * using two-column layout. See 'protected/views/layouts/column2.php'.
	 */
	public $layout='//layouts/column2';

	/**
	 * @return array action filters
	 */
	public function filters()
	{
		return array(
			'accessControl', // perform access control for CRUD operations
			'postOnly + delete', // we only allow deletion via POST request
		);
	}

	/**
	 * Specifies the access control rules.
	 * This method is used by the 'accessControl' filter.
	 * @return array access control rules
	 */
	public function accessRules()
	{
		return array(
			array('allow',  // allow all users to perform 'index' and 'view' actions
				'actions'=>array('index','view'),
				'users'=>array('*'),
			),
			array('allow', // allow authenticated user to perform 'create' and 'update' actions
				'actions'=>array('create','update','addcitytoneighbourhood','removecityfromneighbourhood'),
				'users'=>array('@'),
			),
			array('allow', // allow admin user to perform 'admin' and 'delete' actions
				'actions'=>array('admin','delete'),
				'users'=>array('admin'),
			),
			array('deny',  // deny all users
				'users'=>array('*'),
			),
		);
	}

		

	/**
         * This is the function that adds new city to neighbourhood
         */
        public function actionaddcitytoneighbourhood(){
            $model = new NeighbourhoodCities;
            
            $model->city_id = $_REQUEST['city_id'];
            $model->neighbourhood_id = $_REQUEST['hood_id'];
            $hood_name = $_REQUEST['hood_name'];
            
            if($model->isThisCityAlreadyAssignedToANeighbourhood( $model->city_id) == false){
                 if($model->save()){
                $msg = "This city is successfully assigned to the '$hood_name' neighbourhood";
                          header('Content-Type: application/json');
                          echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                        "msg" => $msg)
                           );
            }else{
                $msg = "Attempt to assign this city to the '$hood_name' neighbourhood was unsuccessful";
                         header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                        "msg" => $msg)
                           );
            }
              
            }else{
                $msg = "This city is already assigned to this or another neighbourhood. To reassign this city, you have to first remove it from that neighbourhood";
                         header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                        "msg" => $msg)
                           );
            }
        }
        
        
        
        /**
         * This is the function that removes a city from a neighbourhood
         */
        public function actionremovecityfromneighbourhood(){
            
            
            $city_id = $_REQUEST['city_id'];
            $neighbourhood_id = $_REQUEST['hood_id'];
            $hood_name = $_REQUEST['hood_name'];
            
                       
            if($this->isThisCityAlreadyAssignedToThisNeighbourhood($city_id,$neighbourhood_id)){
                //get the grouping id
                
                $grouping_id= $this->getTheGroupingIdOfThisAssignment($city_id,$neighbourhood_id);
                
                $model= NeighbourhoodCities::model()->findByPk($grouping_id);
                
                 if($model->delete()){
                $msg = "This city is successfully removed from the '$hood_name' neighbourhood";
                          header('Content-Type: application/json');
                          echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                        "msg" => $msg)
                           );
            }else{
                $msg = "Attempt to remove  this city  from the '$hood_name' neighbourhood was unsuccessful";
                         header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                        "msg" => $msg)
                           );
            }
              
            }else{
                $msg = "This city is not currently assigned to the '$hood_name' neighbourhood. Therefore the request is ignored";
                         header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                        "msg" => $msg)
                           );
            }
            
        }
        
        
        
         /**
         * This is the function that retrieves a grouping is 
         */
        public function getTheGroupingIdOfThisAssignment($city_id,$neighbourhood_id){
            $model = new NeighbourhoodCities;
            return $model->getTheGroupingIdOfThisAssignment($city_id,$neighbourhood_id);
        }
        
        /**
         * This is the function that confirms if a city is already assigned to a neigbourhood
         */
        public function isThisCityAlreadyAssignedToThisNeighbourhood($city_id,$neighbourhood_id){
            $model = new NeighbourhoodCities;
            return $model->isThisCityAlreadyAssignedToThisNeighbourhood($city_id,$neighbourhood_id);
        }
}
