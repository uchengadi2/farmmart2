<?php

class OrderItemController extends Controller
{
	/**
	 * @var string the default layout for the views. Defaults to '//layouts/column2', meaning
	 * using two-column layout. See 'protected/views/layouts/column2.php'.
	 */
	public $layout='//layouts/column2';

	/**
	 * @return array action filters
	 */
	public function filters()
	{
		return array(
			'accessControl', // perform access control for CRUD operations
			'postOnly + delete', // we only allow deletion via POST request
		);
	}

	/**
	 * Specifies the access control rules.
	 * This method is used by the 'accessControl' filter.
	 * @return array access control rules
	 */
	public function accessRules()
	{
		return array(
			array('allow',  // allow all users to perform 'index' and 'view' actions
				'actions'=>array('index','view'),
				'users'=>array('*'),
			),
			array('allow', // allow authenticated user to perform 'create' and 'update' actions
				'actions'=>array('create','update','listAllMerchantOpenItems','startpackagingphase','listAllOpenOrderItems',
                                    'assigndeliverytothiscontractor','assignpackagingtothiscontractor','listAllOpenOrderItemsforpackaging','retrieveitemsdetails',
                                    'confirmorderitemreceipt'),
				'users'=>array('@'),
			),
			array('allow', // allow admin user to perform 'admin' and 'delete' actions
				'actions'=>array('admin','delete'),
				'users'=>array('admin'),
			),
			array('deny',  // deny all users
				'users'=>array('*'),
			),
		);
	}

        
        /**
         * This is the function that retrieves all merchant open items in an order
         */
        public function actionlistAllMerchantOpenItems(){
            
            $model = new User;
            $user_id = Yii::app()->user->id;
            
            $merchant_id = $model->getTheMerchantIdOfThisUser($user_id);
            $order_id = $_REQUEST['order_id'];
                        
            //retrieve all the merchant items in this open orders
                   
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='order_id=:orderid';
            $criteria->params = array(':orderid'=>$order_id);
            $items= OrderItem::model()->findAll($criteria);
            
            $target = [];
            foreach($items as $item){
                if($this->isThisOrderWithMerchantProduct($item['order_id'],$merchant_id)){
                    $target[] = $item;
                }
                
            }
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                    //"order" => $items,
                                    "item"=>$target,
                                   
                            ));
        }
        
        
         /**
         * This is the function that confirms if an order containes a merchant's product
         */
        public function isThisOrderWithMerchantProduct($order_id,$merchant_id){
            $model = new OrderItem;
            return $model->isThisOrderWithMerchantProduct($order_id,$merchant_id);
        }
	
        
        /**
         * This is the function that request we proceed to the packaging phase
         */
        public function actionstartpackagingphase(){
            
             $id = $_POST['id'];
             $model=  OrderItem::model()->findByPk($id);
             
             $model->is_ready_for_packaging = 1;
             
             if($model->save()){
                 $msg = "Thanks for the product availability confirmation. We shall proceed to the packaging phase";
                                 header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                 "success" => mysql_errno() == 0,
                                  "msg" => $msg)
                            );
                 
             }else{
                  $msg = 'Validaion Error: Attempt to confirm product availability failed. Please contact customer service';
                            header('Content-Type: application/json');
                            echo CJSON::encode(array(
                                    "success" => mysql_errno() != 0,
                                        "msg" => $msg)
                               );
             }
        }
        
        
        /**
         * This is the function that retrieves all  open items in an order
         */
        public function actionlistAllOpenOrderItems(){
            
            $model = new User;
            $user_id = Yii::app()->user->id;
            
             $order_id = $_REQUEST['order_id'];
                        
            //retrieve all the items in this open orders
                   
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='order_id=:orderid';
            $criteria->params = array(':orderid'=>$order_id);
            $items= OrderItem::model()->findAll($criteria);
            
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                    //"order" => $items,
                                    "item"=>$items,
                                   
                            ));
        }
        
        
        /**
         * This is the function that assigns a packaging of an order item to a contractor
         */
        public function actionassignpackagingtothiscontractor(){
             $id = $_POST['id'];
             
             $model=  OrderItem::model()->findByPk($id);
             
             $model->packager_id = $_REQUEST['packager_id'];
             
             if($model->save()){
                 $msg = "The packaging of this order item is successfully assigned to this contractor";
                                 header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                 "success" => mysql_errno() == 0,
                                  "msg" => $msg)
                            );
                 
             }else{
                  $msg = 'Validaion Error: Attempt to assign the packaging of this order item to this contractor failed. Please contact customer service';
                            header('Content-Type: application/json');
                            echo CJSON::encode(array(
                                    "success" => mysql_errno() != 0,
                                        "msg" => $msg)
                               );
             }
            
        }
        
        
        
         /**
         * This is the function that assigns the delivery of an order item to a contractor
         */
        public function actionassigndeliverytothiscontractor(){
             $id = $_POST['id'];
             
             $model=  OrderItem::model()->findByPk($id);
             
             $model->courier_id = $_REQUEST['courier_id'];
             
             if($model->save()){
                 $msg = "The delivery of this order item is successfully assigned to this contractor";
                                 header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                 "success" => mysql_errno() == 0,
                                  "msg" => $msg)
                            );
                 
             }else{
                  $msg = 'Validaion Error: Attempt to assign the delivery of this order item to this contractor failed. Please contact customer service';
                            header('Content-Type: application/json');
                            echo CJSON::encode(array(
                                    "success" => mysql_errno() != 0,
                                        "msg" => $msg)
                               );
             }
            
        }
        
        
        /**
         * This is the function that list all open order items for packaging
         */
        public function actionlistAllOpenOrderItemsforpackaging(){
            
            $model = new User;
            
            $user_id = Yii::app()->user->id;
            $packager_id = $model->getTheContractorIdOfThisUser($user_id);
            
            //retrieve all the merchant items in this open orders
                   
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='packager_id=:packid and is_ready_for_packaging=1';
            $criteria->params = array(':packid'=>$packager_id);
            $items= OrderItem::model()->findAll($criteria);
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                    //"order" => $items,
                                    "item"=>$items,
                                   
                            ));
            
        }
        
        /**
         * This is the function that retrieves the details of an order item
         */
        public function actionretrieveitemsdetails(){
            
            $model = new OrderItem;
            
            $order_item_id = $_REQUEST['order_item_id'];
            
            //retrieve this item
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$order_item_id);
            $item= OrderItem::model()->find($criteria);
            
            //retrieve the product details
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$item['product_id']);
            $product= Product::model()->find($criteria);
            
            
            //retrieve the order details
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$item['order_id']);
            $order= Order::model()->find($criteria);
            
             //retrieve the city of delivery details
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$order['delivery_city_id']);
            $city= City::model()->find($criteria);
            
            
            //get the state of delivery
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$city['state_id']);
            $state= State::model()->find($criteria);
            
                        
            //retrieve the measurement unit details
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$item['quantity_measurement_type_id']);
            $unit= MeasurementType::model()->find($criteria);
            
             header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                    "product"=>$product,
                                    "order"=>$order,
                                    "unit"=>$unit,
                                    "city"=>$city,
                                    "state"=>$state
                                   
                            ));
            
        }
        
        
        /**
         * this is the function that confirms the receipt of an order item by the recepient
         */
        public function actionconfirmorderitemreceipt(){
             $id = $_POST['order_item_id'];
             
             $model=  OrderItem::model()->findByPk($id);
             
             $model->has_user_confirmed_receipt = $_REQUEST['confirmed'];
             
             if($model->save()){
                 $msg ="You have successfully confirmed the receipt of this item. Thank you for your patronage";
                  header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                    "msg"=>$msg,
                                    
                            ));
             }
        }
}
