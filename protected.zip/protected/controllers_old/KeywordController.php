<?php

class KeywordController extends Controller
{
	/**
	 * @var string the default layout for the views. Defaults to '//layouts/column2', meaning
	 * using two-column layout. See 'protected/views/layouts/column2.php'.
	 */
	public $layout='//layouts/column2';

	/**
	 * @return array action filters
	 */
	public function filters()
	{
		return array(
			'accessControl', // perform access control for CRUD operations
			'postOnly + delete', // we only allow deletion via POST request
		);
	}

	/**
	 * Specifies the access control rules.
	 * This method is used by the 'accessControl' filter.
	 * @return array access control rules
	 */
	public function accessRules()
	{
		return array(
			array('allow',  // allow all users to perform 'index' and 'view' actions
				'actions'=>array('index','view'),
				'users'=>array('*'),
			),
			array('allow', // allow authenticated user to perform 'create' and 'update' actions
				'actions'=>array('create','update','retrieveallkeywordsofthisproduct','addkeywordstoproduct','modifyproductkeywords','removekeywordsfromproduct'),
				'users'=>array('@'),
			),
			array('allow', // allow admin user to perform 'admin' and 'delete' actions
				'actions'=>array('admin','delete'),
				'users'=>array('admin'),
			),
			array('deny',  // deny all users
				'users'=>array('*'),
			),
		);
	}

	/**
         * This is the function that retrieves all keywords of a product
         */
        public function actionretrieveallkeywordsofthisproduct(){
            
            $model = new Keyword;
            $product_id = $_REQUEST['product_id'];
            
            $criteria = new CDbCriteria();
              $criteria->select = '*';
              $criteria->condition='product_id=:prodid';
              $criteria->params = array(':prodid'=>$product_id);
              $keyword= Keyword::model()->find($criteria);
              
              header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                        "keyword" => $keyword
                                       
                                       )
                           );
        }
        
        
        
        /**
         * This is the function that adds keywords to product
         */
        public function actionaddkeywordstoproduct(){
            $model = new Keyword;
            
            $model->product_id = $_REQUEST['product_id'];
            $model->keyword_1 = $_REQUEST['keyword_1'];
            $model->keyword_2 = $_REQUEST['keyword_2'];
            $model->keyword_3 = $_REQUEST['keyword_3'];
            $model->keyword_4 = $_REQUEST['keyword_4'];
            $model->keyword_5 = $_REQUEST['keyword_5'];
            
            $model->create_time = new CDbExpression('NOW()');
            $model->create_user_id = Yii::app()->user->id;
            
            if($model->isThisProductAlreadyWithKeywords($model->product_id) == false){
                if($model->save()){
                $msg = "This keywords are successfully assigned to this product";
                          header('Content-Type: application/json');
                          echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                        "msg" => $msg)
                           );
            }else{
                $msg = "Attempt to assign this keywords to this product was not successful";
                         header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                        "msg" => $msg)
                           );
            }
                
                
            }else{
                $msg = "This product already have some keywords assigned to it. You could only update the keywords or remove them entirely";
                         header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                        "msg" => $msg)
                           );
                
            }
              
        }
        
        
        
        /**
         * This is the function that modifies keywords of a product
         */
        public function actionmodifyproductkeywords(){
            
            
            $product_id = $_REQUEST['product_id'];
            
            //get the keyword id of this product
            $keyword_id = $this->getTheKeywordIDOfThisProduct($product_id);
            
            if($keyword_id != null){
                $model= Keyword::model()->findByPk($keyword_id);
                 if($model->isThisProductAlreadyWithKeywords($product_id)){
                
            
                $model->keyword_1 = $_REQUEST['keyword_1'];
                $model->keyword_2 = $_REQUEST['keyword_2'];
                $model->keyword_3 = $_REQUEST['keyword_3'];
                $model->keyword_4 = $_REQUEST['keyword_4'];
                $model->keyword_5 = $_REQUEST['keyword_5'];
            
                $model->update_time = new CDbExpression('NOW()');
                $model->update_user_id = Yii::app()->user->id;
                if($model->save()){
                $msg = "This product keywords are updated successfully";
                          header('Content-Type: application/json');
                          echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                        "msg" => $msg,
                                        "keyword"=>$model)
                           );
            }else{
                $msg = "Attempt to update this product keywords was not successful";
                         header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                        "msg" => $msg)
                           );
            }
                
                
            }else{
                $msg = "This product do not currently have any keyword assigned to it, therefore the request is ignored";
                         header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                        "msg" => $msg)
                           );
                
            }
                
                
            }else{
                $msg = "This product do not currently have any keyword assigned to it, therefore the request is ignored";
                         header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                        "msg" => $msg)
                           );
                
            }
            
            
              
        }
        
        
        
        /**
         * This is the function that removes all keywords of a product
         */
        public function actionremovekeywordsfromproduct(){
            
            
            $product_id = $_REQUEST['product_id'];
            
            //get the keyword id of this product
            $keyword_id = $this->getTheKeywordIDOfThisProduct($product_id);
            
            if($keyword_id != null){
                 $model= Keyword::model()->findByPk($keyword_id);
             if($model->isThisProductAlreadyWithKeywords($product_id)){
               if($model->delete()){
                $msg = "This product keywords are removed successfully";
                          header('Content-Type: application/json');
                          echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                        "msg" => $msg)
                           );
            }else{
                $msg = "Attempt to remove this product keywords was not successful";
                         header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                        "msg" => $msg)
                           );
            }
                
                
            }else{
                $msg = "This product do not currently have any keyword assigned to it, therefore the request is ignored";
                         header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                        "msg" => $msg)
                           );
                
            }
                
                
            }else{
                $msg = "This product do not currently have any keyword assigned to it, therefore the request is ignored";
                         header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                        "msg" => $msg)
                           );
                
            }
            
            
              
        }
        
        
        /**
         * This is the function that gets the keyword id of a product
         */
        public function getTheKeywordIDOfThisProduct($product_id){
            $model = new Keyword;
            return $model->getTheKeywordIDOfThisProduct($product_id);
        }
}
