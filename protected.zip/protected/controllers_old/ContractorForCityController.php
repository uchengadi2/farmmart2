<?php

class ContractorForCityController extends Controller
{
	/**
	 * @var string the default layout for the views. Defaults to '//layouts/column2', meaning
	 * using two-column layout. See 'protected/views/layouts/column2.php'.
	 */
	public $layout='//layouts/column2';

	/**
	 * @return array action filters
	 */
	public function filters()
	{
		return array(
			'accessControl', // perform access control for CRUD operations
			'postOnly + delete', // we only allow deletion via POST request
		);
	}

	/**
	 * Specifies the access control rules.
	 * This method is used by the 'accessControl' filter.
	 * @return array access control rules
	 */
	public function accessRules()
	{
		return array(
			array('allow',  // allow all users to perform 'index' and 'view' actions
				'actions'=>array('index','view'),
				'users'=>array('*'),
			),
			array('allow', // allow authenticated user to perform 'create' and 'update' actions
				'actions'=>array('create','update','addcontractortocity','removecontractorfromcity'),
				'users'=>array('@'),
			),
			array('allow', // allow admin user to perform 'admin' and 'delete' actions
				'actions'=>array('admin','delete'),
				'users'=>array('admin'),
			),
			array('deny',  // deny all users
				'users'=>array('*'),
			),
		);
	}

	/**
         * This is the function that adds a contractor to a city
         */
        public function actionaddcontractortocity(){
            $model = new ContractorForCity;
            
            $model->city_id = $_REQUEST['city_id'];
            $model->contractor_id = $_REQUEST['contractor_id'];
            $city_name = $_REQUEST['city_name'];
            
            if($model->isThisContractorAlreadyAssignedToThisCity( $model->city_id,$model->contractor_id) == false){
                 if($model->save()){
                $msg = "This contractor is successfully assigned to the '$city_name' city";
                          header('Content-Type: application/json');
                          echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                        "msg" => $msg)
                           );
            }else{
                $msg = "Attempt to assign this contractor to the '$city_name' city was unsuccessful";
                         header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                        "msg" => $msg)
                           );
            }
              
            }else{
                $msg = "This contractor is already assigned to the '$city_name' city. Therefore the request is ignored";
                         header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                        "msg" => $msg)
                           );
            }
            
        }
        
        
        
        /**
         * This is the function that removes a contractor from a city
         */
        public function actionremovecontractorfromcity(){
            
            
            $city_id = $_REQUEST['city_id'];
            $contractor_id = $_REQUEST['contractor_id'];
            $city_name = $_REQUEST['city_name'];
            
                       
            if($this->isThisContractorAlreadyAssignedToThisCity($city_id,$contractor_id)){
                //get the catchment id
                
                $catchment_id = $this->getTheCatchmentIdOfThisAssignment($city_id,$contractor_id);
                
                $model= ContractorForCity::model()->findByPk($catchment_id);
                
                 if($model->delete()){
                $msg = "This contractor is successfully removed from the '$city_name' city";
                          header('Content-Type: application/json');
                          echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                        "msg" => $msg)
                           );
            }else{
                $msg = "Attempt to remove  this contractor  from the '$city_name' city was unsuccessful";
                         header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                        "msg" => $msg)
                           );
            }
              
            }else{
                $msg = "This contractor is not currently assigned to the '$city_name' city. Therefore the request is ignored";
                         header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                        "msg" => $msg)
                           );
            }
            
        }
        
        
        /**
         * This is the function that retrieves a catchment city id
         */
        public function getTheCatchmentIdOfThisAssignment($city_id,$contractor_id){
            $model = new ContractorForCity;
            return $model->getTheCatchmentIdOfThisAssignment($city_id,$contractor_id);
        }
        
        /**
         * This is the function that confirms if a contractor is already assigned to a city
         */
        public function isThisContractorAlreadyAssignedToThisCity($city_id,$contractor_id){
            $model = new ContractorForCity;
            return $model->isThisContractorAlreadyAssignedToThisCity($city_id,$contractor_id);
        }
}
