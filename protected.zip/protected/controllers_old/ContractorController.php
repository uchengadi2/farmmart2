<?php

class ContractorController extends Controller
{
	/**
	 * @var string the default layout for the views. Defaults to '//layouts/column2', meaning
	 * using two-column layout. See 'protected/views/layouts/column2.php'.
	 */
	public $layout='//layouts/column2';

	/**
	 * @return array action filters
	 */
	public function filters()
	{
		return array(
			'accessControl', // perform access control for CRUD operations
			'postOnly + delete', // we only allow deletion via POST request
		);
	}

	/**
	 * Specifies the access control rules.
	 * This method is used by the 'accessControl' filter.
	 * @return array access control rules
	 */
	public function accessRules()
	{
		return array(
			array('allow',  // allow all users to perform 'index' and 'view' actions
				'actions'=>array('index','view'),
				'users'=>array('*'),
			),
			array('allow', // allow authenticated user to perform 'create' and 'update' actions
				'actions'=>array('create','update','modifycontractor','addnewcontractor','deleteonecontractor','listAllContractors',
                                    'listcontractorsforacity','listAllDeliveryContractorsForThisCity','listAllPackagingContractorsForThisCity'),
				'users'=>array('@'),
			),
			array('allow', // allow admin user to perform 'admin' and 'delete' actions
				'actions'=>array('admin','delete'),
				'users'=>array('admin'),
			),
			array('deny',  // deny all users
				'users'=>array('*'),
			),
		);
	}

	/**
         * This is the function that list all contractors on the platform
         */
        public function actionlistAllContractors(){
            
            $model = new Contractor;
            
             $contractor = Contractor::model()->findAll();
                if($contractor===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                        header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                    "contractor" => $contractor,
                                   
                    
                            ));
                       
                }
        }
        
        
        /**
         * This is the function that adds new contractor
         */
        public function actionaddnewcontractor(){
            
            $model=new Contractor;

		
		$model->name = $_POST['name'];
               if(isset($_POST['email'])){
                   $model->email = $_POST['email']; 
                }
                 if(isset($_POST['address'])){
                   $model->address = $_POST['address']; 
                }
                 if(isset($_POST['phone_number'])){
                   $model->phone_number = $_POST['phone_number']; 
                }
                 if(isset($_POST['banker'])){
                   $model->banker = $_POST['banker']; 
                }
                 if(isset($_POST['account_number'])){
                   $model->account_number = $_POST['account_number']; 
                }
                if(isset($_POST['account_title'])){
                   $model->account_title = $_POST['account_title']; 
                }
                if(isset($_POST['bank_swift_code'])){
                   $model->bank_swift_code = $_POST['bank_swift_code']; 
                }
                 if(isset($_POST['tax_identification_pin'])){
                   $model->tax_identification_pin = $_POST['tax_identification_pin']; 
                }
                if(isset($_POST['vat_number'])){
                   $model->vat_number = $_POST['vat_number']; 
                }
                if(isset($_POST['contact_person_name'])){
                   $model->contact_person_name = $_POST['contact_person_name']; 
                }
                if(isset($_POST['contact_person_mobile_number'])){
                   $model->contact_person_mobile_number = $_POST['contact_person_mobile_number']; 
                }
                if(isset($_POST['contact_person_email'])){
                   $model->contact_person_email = $_POST['contact_person_email']; 
                }
                if(isset($_POST['contractor_type'])){
                   $model->contractor_type = $_POST['contractor_type']; 
                }
                $model->contractorid = $model->generateThisContractorID();
               if(isset($_POST['description'])){
                   $model->description = $_POST['description']; 
                }
                
                $model->create_time = new CDbExpression('NOW()');
                $model->create_user_id = Yii::app()->user->id;
                if($model->save()){
                         // $result['success'] = 'true';
                          $msg = 'Successfully created new contractor';
                          header('Content-Type: application/json');
                          echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                        "msg" => $msg)
                           );
                     }else {
                         //$result['success'] = 'false';
                         $msg = 'New contractor creation was unsuccessful';
                         header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysql_errno() != 0,
                                        "msg" => $msg)
                           );
                    } 
            
        }
        
        
        
         /**
         * This is the function that modifies contractor info
         */
        public function actionmodifycontractor(){
            
           $_id = $_POST['id'];
            
            $model=  Contractor::model()->findByPk($_id);
		$model->name = $_POST['name'];
               if(isset($_POST['email'])){
                   $model->email = $_POST['email']; 
                }
                 if(isset($_POST['address'])){
                   $model->address = $_POST['address']; 
                }
                 if(isset($_POST['phone_number'])){
                   $model->phone_number = $_POST['phone_number']; 
                }
                 if(isset($_POST['banker'])){
                   $model->banker = $_POST['banker']; 
                }
                 if(isset($_POST['account_number'])){
                   $model->account_number = $_POST['account_number']; 
                }
                if(isset($_POST['account_title'])){
                   $model->account_title = $_POST['account_title']; 
                }
                if(isset($_POST['bank_swift_code'])){
                   $model->bank_swift_code = $_POST['bank_swift_code']; 
                }
                 if(isset($_POST['tax_identification_pin'])){
                   $model->tax_identification_pin = $_POST['tax_identification_pin']; 
                }
                if(isset($_POST['vat_number'])){
                   $model->vat_number = $_POST['vat_number']; 
                }
                if(isset($_POST['contact_person_name'])){
                   $model->contact_person_name = $_POST['contact_person_name']; 
                }
                if(isset($_POST['contact_person_mobile_number'])){
                   $model->contact_person_mobile_number = $_POST['contact_person_mobile_number']; 
                }
                if(isset($_POST['contact_person_email'])){
                   $model->contact_person_email = $_POST['contact_person_email']; 
                }
                if(isset($_POST['contractor_type'])){
                   $model->contractor_type = $_POST['contractor_type']; 
                }
                $model->contractorid = $_POST['contractorid'];
               if(isset($_POST['description'])){
                   $model->description = $_POST['description']; 
                }
                
                $model->update_time = new CDbExpression('NOW()');
                $model->update_user_id = Yii::app()->user->id;
                if($model->save()){
                         // $result['success'] = 'true';
                          $msg = 'Successfully updated this contractor information';
                          header('Content-Type: application/json');
                          echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                        "msg" => $msg)
                           );
                     }else {
                         //$result['success'] = 'false';
                         $msg = 'Contractor update was unsuccessful';
                         header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysql_errno() != 0,
                                        "msg" => $msg)
                           );
                    } 
            
        }
        
        
        /**
	 * Deletes a particular model instance
	 * 
         **/
	public function actiondeleteonecontractor()
	{
            
            $_id = $_REQUEST['id'];
            $model=  Contractor::model()->findByPk($_id);
            
            //get the contractor name
            $contractor_name = $_REQUEST['name'];
            
            if($model === null){
                $data['success'] = 'undefined';
                $data['msg'] = 'No such record exist';
                header('Content-Type: application/json');
                echo CJSON::encode($data);
                                      
            }else if($model->delete()){
                    $data['success'] = 'true';
                    $data['msg'] = "'$contractor_name' contractor was successfully deleted";
                     header('Content-Type: application/json');
                    echo CJSON::encode($data);
            } else {
                    $data['success'] = 'false';
                    $data['msg'] = 'deletion unsuccessful';
                     header('Content-Type: application/json');
                    echo CJSON::encode($data);
                            
                }
	}
        
        
        /**
         * This is the function that list all contractors assigned to a city
         */
        public function actionlistcontractorsforacity(){
            $model = new ContractorForCity;
            $city_id = $_REQUEST['city_id'];
            
            $target = [];
            
            //get all the contractors assigned for this city
            $contractors = $model->getAllContractorsForThisCity($city_id);
            
           foreach($contractors as $contra){
               $criteria = new CDbCriteria();
              $criteria->select = '*';
              $criteria->condition='id=:id';
              $criteria->params = array(':id'=>$contra);
              $contractor= Contractor::model()->find($criteria);
              
              $target[] = $contractor;
           
           }
           
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                    "contractor"=>$target
                                   
                    
                            ));
        }
        
        
        
        /**
         * This is the function that list all delivery contractors assigned to a city
         */
        public function actionlistAllDeliveryContractorsForThisCity(){
            $model = new ContractorForCity;
            
            $city_id = $_REQUEST['city_id'];
            
            //list all contractors assigned to this city
            $contractors = $model->getAllContractorsForThisCity($city_id);
            $target = [];
            foreach($contractors as $contrat){
                if($this->isThisADeliveryContractor($contrat)){
                    $criteria = new CDbCriteria();
                    $criteria->select = '*';
                     $criteria->condition='id=:id';
                    $criteria->params = array(':id'=>$contrat);
                    $contractor= Contractor::model()->find($criteria);
                    
                    $target[] = $contractor;
                    
                }
            }
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                    "contractor"=>$target
                                   
                    
                            ));
        }
        
        
        
        /**
         * This is the function that list all packaging contractors assigned to a city
         */
        public function actionlistAllPackagingContractorsForThisCity(){
            $model = new ContractorForCity;
            
            $city_id = $_REQUEST['city_id'];
            
            //list all contractors assigned to this city
            $contractors = $model->getAllContractorsForThisCity($city_id);
            $target = [];
            foreach($contractors as $contrat){
                if($this->isThisAPackagingContractor($contrat)){
                    $criteria = new CDbCriteria();
                    $criteria->select = '*';
                     $criteria->condition='id=:id';
                    $criteria->params = array(':id'=>$contrat);
                    $contractor= Contractor::model()->find($criteria);
                    
                    $target[] = $contractor;
                    
                }
            }
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                    "contractor"=>$target
                                   
                    
                            ));
        }
        
        
        /**
         * This is the function that confirms if a contractor is a delivery contractor
         */
        public function isThisADeliveryContractor($contractor_id){
            $model = new Contractor;
            return $model->isThisADeliveryContractor($contractor_id);
        }
        
        
        
         /**
         * This is the function that confirms if a contractor is a packaging contractor
         */
        public function isThisAPackagingContractor($contractor_id){
            $model = new Contractor;
            return $model->isThisAPackagingContractor($contractor_id);
        }
}
