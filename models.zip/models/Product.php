<?php

/**
 * This is the model class for table "product".
 *
 * The followings are the available columns in table 'product':
 * @property string $id
 * @property string $product_type_id
 * @property string $name
 * @property string $description
 * @property string $icon
 * @property string $product_front_view
 * @property string $product_right_side_view
 * @property string $product_top_view
 * @property string $product_inside_view
 * @property string $product_back_view
 * @property string $product_left_side_view
 * @property string $product_bottom_view
 * @property string $create_time
 * @property integer $create_user_id
 * @property string $update_time
 * @property integer $update_user_id
 *
 * The followings are the available model relations:
 * @property Inventory[] $inventories
 * @property OrderItem[] $orderItems
 * @property ProductType $productType
 */
class Product extends CActiveRecord
{
	/**
	 * @return string the associated database table name
	 */
	public function tableName()
	{
		return 'product';
	}

	/**
	 * @return array validation rules for model attributes.
	 */
	public function rules()
	{
		// NOTE: you should only define rules for those attributes that
		// will receive user inputs.
		return array(
			array('product_type_id, name', 'required'),
			array('create_user_id, update_user_id', 'numerical', 'integerOnly'=>true),
			array('product_type_id', 'length', 'max'=>10),
			array('name, icon, product_front_view, product_right_side_view, product_top_view, product_inside_view, product_back_view, product_left_side_view, product_bottom_view', 'length', 'max'=>250),
			array('description, create_time, update_time', 'safe'),
			// The following rule is used by search().
			// @todo Please remove those attributes that should not be searched.
			array('id, product_type_id, name, description, icon, product_front_view, product_right_side_view, product_top_view, product_inside_view, product_back_view, product_left_side_view, product_bottom_view, create_time, create_user_id, update_time, update_user_id', 'safe', 'on'=>'search'),
		);
	}

	/**
	 * @return array relational rules.
	 */
	public function relations()
	{
		// NOTE: you may need to adjust the relation name and the related
		// class name for the relations automatically generated below.
		return array(
			'inventories' => array(self::HAS_MANY, 'Inventory', 'product_id'),
			'orderItems' => array(self::HAS_MANY, 'OrderItem', 'product_id'),
			'productType' => array(self::BELONGS_TO, 'ProductType', 'product_type_id'),
		);
	}

	/**
	 * @return array customized attribute labels (name=>label)
	 */
	public function attributeLabels()
	{
		return array(
			'id' => 'ID',
			'product_type_id' => 'Product Type',
			'name' => 'Name',
			'description' => 'Description',
			'icon' => 'Icon',
			'product_front_view' => 'Product Front View',
			'product_right_side_view' => 'Product Right Side View',
			'product_top_view' => 'Product Top View',
			'product_inside_view' => 'Product Inside View',
			'product_back_view' => 'Product Back View',
			'product_left_side_view' => 'Product Left Side View',
			'product_bottom_view' => 'Product Bottom View',
			'create_time' => 'Create Time',
			'create_user_id' => 'Create User',
			'update_time' => 'Update Time',
			'update_user_id' => 'Update User',
		);
	}

	/**
	 * Retrieves a list of models based on the current search/filter conditions.
	 *
	 * Typical usecase:
	 * - Initialize the model fields with values from filter form.
	 * - Execute this method to get CActiveDataProvider instance which will filter
	 * models according to data in model fields.
	 * - Pass data provider to CGridView, CListView or any similar widget.
	 *
	 * @return CActiveDataProvider the data provider that can return the models
	 * based on the search/filter conditions.
	 */
	public function search()
	{
		// @todo Please modify the following code to remove attributes that should not be searched.

		$criteria=new CDbCriteria;

		$criteria->compare('id',$this->id,true);
		$criteria->compare('product_type_id',$this->product_type_id,true);
		$criteria->compare('name',$this->name,true);
		$criteria->compare('description',$this->description,true);
		$criteria->compare('icon',$this->icon,true);
		$criteria->compare('product_front_view',$this->product_front_view,true);
		$criteria->compare('product_right_side_view',$this->product_right_side_view,true);
		$criteria->compare('product_top_view',$this->product_top_view,true);
		$criteria->compare('product_inside_view',$this->product_inside_view,true);
		$criteria->compare('product_back_view',$this->product_back_view,true);
		$criteria->compare('product_left_side_view',$this->product_left_side_view,true);
		$criteria->compare('product_bottom_view',$this->product_bottom_view,true);
		$criteria->compare('create_time',$this->create_time,true);
		$criteria->compare('create_user_id',$this->create_user_id);
		$criteria->compare('update_time',$this->update_time,true);
		$criteria->compare('update_user_id',$this->update_user_id);

		return new CActiveDataProvider($this, array(
			'criteria'=>$criteria,
		));
	}

	/**
	 * Returns the static model of the specified AR class.
	 * Please note that you should have this exact method in all your CActiveRecord descendants!
	 * @param string $className active record class name.
	 * @return Product the static model class
	 */
	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}
        
        
         /**
         * This is the function that determines the type and size of image file
         */
        public function isImageTypeAndSizeLegal(){
            
           $size = []; 
            if(isset($_FILES['icon']['name'])){
                $tmpName = $_FILES['icon']['tmp_name'];
                $iconFileName = $_FILES['icon']['name'];    
                $iconFileType = $_FILES['icon']['type'];
                $iconFileSize = $_FILES['icon']['size'];
            } 
           if (isset($_FILES['icon'])) {
                $filename = $_FILES['icon']['tmp_name'];
                list($width, $height) = getimagesize($filename);
           }
      
         
           if(($iconFileType == 'image/png'|| $iconFileType == 'image/jpg' || $iconFileType == 'image/jpeg')){
              if($width>=400 && $height>=400){
                   return true;
              }else{
                  return false;
              }
               
            }else{
                return false;
            }
            
        }
        
        
        
     /**
         * This is the function that moves icons to its directory
         */
        public function moveTheIconToItsPathAndReturnTheFilename($model,$icon_filename){
            
            if(isset($_FILES['icon']['name'])){
                        $tmpName = $_FILES['icon']['tmp_name'];
                        $iconName = $_FILES['icon']['name'];    
                        $iconType = $_FILES['icon']['type'];
                        $iconSize = $_FILES['icon']['size'];
                  
                   }
                    
                    if($icon_filename !== null) {
                        if($model->id === null){
                          //$iconFileName = $icon_filename;  
                          if($icon_filename != NULL){
                                $iconFileName = time().'_'.$icon_filename;  
                            }else{
                                $iconFileName = $icon_filename;  
                            }  
                          
                           // upload the icon file
                        if($iconName !== NULL){
                            	$iconPath = Yii::app()->params['images'].$iconFileName;
				move_uploaded_file($tmpName,  $iconPath);
                                        
                        
                                return $iconFileName;
                        }else{
                            $iconFileName = $icon_filename;
                            return $iconFileName;
                        } // validate to save file
                        }else{
                            if($this->noNewIconFileProvided($model->id,$icon_filename)){
                                $iconFileName = $icon_filename; 
                                return $iconFileName;
                            }else{
                            if($icon_filename != NULL){
                                if($this->removeTheExistingIconFile($model->id)){
                                 $iconFileName = time().'_'.$icon_filename; 
                                 //$iconFileName = time().$icon_filename;  
                                   $iconPath = Yii::app()->params['images'].$iconFileName;
                                   move_uploaded_file($tmpName,$iconPath);
                                   return $iconFileName;
                                    
                                   // $iconFileName = time().'_'.$icon_filename;  
                                    
                             }
                                
                            }
                                
                                
                            }
                            
                            //$iconFileName = $icon_filename; 
                                              
                            
                        }
                      
                     }else{
                         $iconFileName = $icon_filename;
                         return $iconFileName;
                     }
					
                       
                               
        }
        
		
		
		 /**
         * This is the function that removes an existing video file
         */
        public function removeTheExistingIconFile($id){
            
            //retreve the existing zip file from the database
            
            if($this->isTheIconNotTheDefault($id)){
                
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$id);
                $icon= Product::model()->find($criteria);
                
                //$directoryPath =  dirname(Yii::app()->request->scriptFile);
                $directoryPath = "../ecommerce_images/images/";
               // $iconpath = '..\appspace_assets\icons'.$icon['icon'];
                $filepath =$directoryPath.$icon['icon'];
                //$filepath = $directoryPath.$iconpath;
                
                if(unlink($filepath)){
                    return true;
                }else{
                    return false;
                }
                
            }else{
                return true;
            }
                
            
            
        }
        
	
        /**
         * This is the function that determines if  a tooltype icon is the default
         */
        public function isTheIconNotTheDefault($id){
            
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$id);
                $icon= Product::model()->find($criteria);
                
                if($icon['icon'] ===NULL){
                    return false;
                }else{
                    return true;
                }
        }
		
		
		
		/**
         * This is the function to ascertain if a new icon was provided or not
         */
        public function noNewIconFileProvided($id,$icon_filename){
            
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$id);
                $icon= Product::model()->find($criteria);
                
                if($icon['icon']==$icon_filename){
                    return true;
                }else{
                    return false;
                }
            
        }
        
        
        /**
         * This is the function that retrieves the previous icon of the task in question
         */
        public function retrieveThePreviousIconImage($id){
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';   
            $criteria->params = array(':id'=>$id);
            $icon = Product::model()->find($criteria);
            
            
            return $icon['icon'];
            
            
        }
        
        
        //the front view image
        
        
        /**
         * This is the function that moves icons to its directory
         */
        public function moveTheFrontImageToItsPathAndReturnTheFilename($model,$icon_filename){
            
            if(isset($_FILES['product_front_view']['name'])){
                        $tmpName = $_FILES['product_front_view']['tmp_name'];
                        $iconName = $_FILES['product_front_view']['name'];    
                        $iconType = $_FILES['product_front_view']['type'];
                        $iconSize = $_FILES['product_front_view']['size'];
                  
                   }
                    
                    if($icon_filename !== null) {
                        if($model->id === null){
                          //$iconFileName = $icon_filename;  
                          if($icon_filename != NULL){
                                $iconFileName = time().'_'.$icon_filename;  
                            }else{
                                $iconFileName = $icon_filename;  
                            }  
                          
                           // upload the icon file
                        if($iconName !== NULL){
                            	$iconPath = Yii::app()->params['images'].$iconFileName;
				move_uploaded_file($tmpName,  $iconPath);
                                        
                        
                                return $iconFileName;
                        }else{
                            $iconFileName = $icon_filename;
                            return $iconFileName;
                        } // validate to save file
                        }else{
                            if($this->noNewFrontImageFileProvided($model->id,$icon_filename)){
                                $iconFileName = $icon_filename; 
                                return $iconFileName;
                            }else{
                            if($icon_filename != NULL){
                                if($this->removeTheExistingFrontImageFile($model->id)){
                                 $iconFileName = time().'_'.$icon_filename; 
                                 //$iconFileName = time().$icon_filename;  
                                   $iconPath = Yii::app()->params['images'].$iconFileName;
                                   move_uploaded_file($tmpName,$iconPath);
                                   return $iconFileName;
                                    
                                   // $iconFileName = time().'_'.$icon_filename;  
                                    
                             }
                                
                            }
                                
                                
                            }
                            
                            //$iconFileName = $icon_filename; 
                                              
                            
                        }
                      
                     }else{
                         $iconFileName = $icon_filename;
                         return $iconFileName;
                     }
					
                       
                               
        }
        
		
		
		 /**
         * This is the function that removes an existing video file
         */
        public function removeTheExistingFrontImageFile($id){
            
            //retreve the existing zip file from the database
            
            if($this->isTheFrontImageNotTheDefault($id)){
                
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$id);
                $icon= Product::model()->find($criteria);
                
                //$directoryPath =  dirname(Yii::app()->request->scriptFile);
                $directoryPath = "../ecommerce_images/images/";
               // $iconpath = '..\appspace_assets\icons'.$icon['icon'];
                $filepath =$directoryPath.$icon['product_front_view'];
                //$filepath = $directoryPath.$iconpath;
                
                if(unlink($filepath)){
                    return true;
                }else{
                    return false;
                }
                
            }else{
                return true;
            }
                
            
            
        }
        
	
        /**
         * This is the function that determines if  a tooltype icon is the default
         */
        public function isTheFrontImageNotTheDefault($id){
            
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$id);
                $icon= Product::model()->find($criteria);
                
                if($icon['product_front_view'] ===NULL){
                    return false;
                }else{
                    return true;
                }
        }
		
		
		
		/**
         * This is the function to ascertain if a new icon was provided or not
         */
        public function noNewFrontImageFileProvided($id,$icon_filename){
            
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$id);
                $icon= Product::model()->find($criteria);
                
                if($icon['product_front_view']==$icon_filename){
                    return true;
                }else{
                    return false;
                }
            
        }
        
        
        /**
         * This is the function that retrieves the previous icon of the task in question
         */
        public function retrieveThePreviousFrontImage($id){
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';   
            $criteria->params = array(':id'=>$id);
            $icon = Product::model()->find($criteria);
            
            
            return $icon['product_front_view'];
            
            
        }
        
        
        
        //the product_right_side_view image
        
        
        /**
         * This is the function that moves icons to its directory
         */
        public function moveTheRightImageToItsPathAndReturnTheFilename($model,$icon_filename){
            
            if(isset($_FILES['product_right_side_view']['name'])){
                        $tmpName = $_FILES['product_right_side_view']['tmp_name'];
                        $iconName = $_FILES['product_right_side_view']['name'];    
                        $iconType = $_FILES['product_right_side_view']['type'];
                        $iconSize = $_FILES['product_right_side_view']['size'];
                  
                   }
                    
                    if($icon_filename !== null) {
                        if($model->id === null){
                          //$iconFileName = $icon_filename;  
                          if($icon_filename != NULL){
                                $iconFileName = time().'_'.$icon_filename;  
                            }else{
                                $iconFileName = $icon_filename;  
                            }  
                          
                           // upload the icon file
                        if($iconName !== NULL){
                            	$iconPath = Yii::app()->params['images'].$iconFileName;
				move_uploaded_file($tmpName,  $iconPath);
                                        
                        
                                return $iconFileName;
                        }else{
                            $iconFileName = $icon_filename;
                            return $iconFileName;
                        } // validate to save file
                        }else{
                            if($this->noNewRightImageFileProvided($model->id,$icon_filename)){
                                $iconFileName = $icon_filename; 
                                return $iconFileName;
                            }else{
                            if($icon_filename != NULL){
                                if($this->removeTheExistingRightImageFile($model->id)){
                                 $iconFileName = time().'_'.$icon_filename; 
                                 //$iconFileName = time().$icon_filename;  
                                   $iconPath = Yii::app()->params['images'].$iconFileName;
                                   move_uploaded_file($tmpName,$iconPath);
                                   return $iconFileName;
                                    
                                   // $iconFileName = time().'_'.$icon_filename;  
                                    
                             }
                                
                            }
                                
                                
                            }
                            
                            //$iconFileName = $icon_filename; 
                                              
                            
                        }
                      
                     }else{
                         $iconFileName = $icon_filename;
                         return $iconFileName;
                     }
					
                       
                               
        }
        
		
		
		 /**
         * This is the function that removes an existing video file
         */
        public function removeTheExistingRightImageFile($id){
            
            //retreve the existing zip file from the database
            
            if($this->isTheRightImageNotTheDefault($id)){
                
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$id);
                $icon= Product::model()->find($criteria);
                
                //$directoryPath =  dirname(Yii::app()->request->scriptFile);
                $directoryPath = "../ecommerce_images/images/";
               // $iconpath = '..\appspace_assets\icons'.$icon['icon'];
                $filepath =$directoryPath.$icon['product_right_side_view'];
                //$filepath = $directoryPath.$iconpath;
                
                if(unlink($filepath)){
                    return true;
                }else{
                    return false;
                }
                
            }else{
                return true;
            }
                
            
            
        }
        
	
        /**
         * This is the function that determines if  a tooltype icon is the default
         */
        public function isTheRightImageNotTheDefault($id){
            
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$id);
                $icon= Product::model()->find($criteria);
                
                if($icon['product_right_side_view'] ===NULL){
                    return false;
                }else{
                    return true;
                }
        }
		
		
		
		/**
         * This is the function to ascertain if a new icon was provided or not
         */
        public function noNewRightImageFileProvided($id,$icon_filename){
            
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$id);
                $icon= Product::model()->find($criteria);
                
                if($icon['product_right_side_view']==$icon_filename){
                    return true;
                }else{
                    return false;
                }
            
        }
        
        
        /**
         * This is the function that retrieves the previous icon of the task in question
         */
        public function retrieveThePreviousRightImage($id){
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';   
            $criteria->params = array(':id'=>$id);
            $icon = Product::model()->find($criteria);
            
            
            return $icon['product_right_side_view'];
         
        }
        
        
        
        //the product_top_view image
        
        
        /**
         * This is the function that moves icons to its directory
         */
        public function moveTheTopToItsPathAndReturnTheFilename($model,$icon_filename){
            
            if(isset($_FILES['product_top_view']['name'])){
                        $tmpName = $_FILES['product_top_view']['tmp_name'];
                        $iconName = $_FILES['product_top_view']['name'];    
                        $iconType = $_FILES['product_top_view']['type'];
                        $iconSize = $_FILES['product_top_view']['size'];
                  
                   }
                    
                    if($icon_filename !== null) {
                        if($model->id === null){
                          //$iconFileName = $icon_filename;  
                          if($icon_filename != NULL){
                                $iconFileName = time().'_'.$icon_filename;  
                            }else{
                                $iconFileName = $icon_filename;  
                            }  
                          
                           // upload the icon file
                        if($iconName !== NULL){
                            	$iconPath = Yii::app()->params['images'].$iconFileName;
				move_uploaded_file($tmpName,  $iconPath);
                                        
                        
                                return $iconFileName;
                        }else{
                            $iconFileName = $icon_filename;
                            return $iconFileName;
                        } // validate to save file
                        }else{
                            if($this->noNewTopImageFileProvided($model->id,$icon_filename)){
                                $iconFileName = $icon_filename; 
                                return $iconFileName;
                            }else{
                            if($icon_filename != NULL){
                                if($this->removeTheExistingTopImageFile($model->id)){
                                 $iconFileName = time().'_'.$icon_filename; 
                                 //$iconFileName = time().$icon_filename;  
                                   $iconPath = Yii::app()->params['images'].$iconFileName;
                                   move_uploaded_file($tmpName,$iconPath);
                                   return $iconFileName;
                                    
                                   // $iconFileName = time().'_'.$icon_filename;  
                                    
                             }
                                
                            }
                                
                                
                            }
                            
                            //$iconFileName = $icon_filename; 
                                              
                            
                        }
                      
                     }else{
                         $iconFileName = $icon_filename;
                         return $iconFileName;
                     }
					
                       
                               
        }
        
		
		
		 /**
         * This is the function that removes an existing video file
         */
        public function removeTheExistingTopImageFile($id){
            
            //retreve the existing zip file from the database
            
            if($this->isTheTopImageNotTheDefault($id)){
                
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$id);
                $icon= Product::model()->find($criteria);
                
                //$directoryPath =  dirname(Yii::app()->request->scriptFile);
                $directoryPath = "../ecommerce_images/images/";
               // $iconpath = '..\appspace_assets\icons'.$icon['icon'];
                $filepath =$directoryPath.$icon['product_top_view'];
                //$filepath = $directoryPath.$iconpath;
                
                if(unlink($filepath)){
                    return true;
                }else{
                    return false;
                }
                
            }else{
                return true;
            }
                
            
            
        }
        
	
        /**
         * This is the function that determines if  a tooltype icon is the default
         */
        public function isTheTopImageNotTheDefault($id){
            
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$id);
                $icon= Product::model()->find($criteria);
                
                if($icon['product_top_view'] ===NULL){
                    return false;
                }else{
                    return true;
                }
        }
		
		
		
		/**
         * This is the function to ascertain if a new icon was provided or not
         */
        public function noNewTopImageFileProvided($id,$icon_filename){
            
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$id);
                $icon= Product::model()->find($criteria);
                
                if($icon['product_top_view']==$icon_filename){
                    return true;
                }else{
                    return false;
                }
            
        }
        
        
        /**
         * This is the function that retrieves the previous icon of the task in question
         */
        public function retrieveThePreviousTopImage($id){
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';   
            $criteria->params = array(':id'=>$id);
            $icon = Product::model()->find($criteria);
            
            
            return $icon['product_top_view'];
         
        }
        
        
        
        
        //the product_inside_view image
        
        
        /**
         * This is the function that moves icons to its directory
         */
        public function moveTheInsideImageToItsPathAndReturnTheFilename($model,$icon_filename){
            
            if(isset($_FILES['product_inside_view']['name'])){
                        $tmpName = $_FILES['product_inside_view']['tmp_name'];
                        $iconName = $_FILES['product_inside_view']['name'];    
                        $iconType = $_FILES['product_inside_view']['type'];
                        $iconSize = $_FILES['product_inside_view']['size'];
                  
                   }
                    
                    if($icon_filename !== null) {
                        if($model->id === null){
                          //$iconFileName = $icon_filename;  
                          if($icon_filename != NULL){
                                $iconFileName = time().'_'.$icon_filename;  
                            }else{
                                $iconFileName = $icon_filename;  
                            }  
                          
                           // upload the icon file
                        if($iconName !== NULL){
                            	$iconPath = Yii::app()->params['images'].$iconFileName;
				move_uploaded_file($tmpName,  $iconPath);
                                        
                        
                                return $iconFileName;
                        }else{
                            $iconFileName = $icon_filename;
                            return $iconFileName;
                        } // validate to save file
                        }else{
                            if($this->noNewInsideImageFileProvided($model->id,$icon_filename)){
                                $iconFileName = $icon_filename; 
                                return $iconFileName;
                            }else{
                            if($icon_filename != NULL){
                                if($this->removeTheExistingInsideImageFile($model->id)){
                                 $iconFileName = time().'_'.$icon_filename; 
                                 //$iconFileName = time().$icon_filename;  
                                   $iconPath = Yii::app()->params['images'].$iconFileName;
                                   move_uploaded_file($tmpName,$iconPath);
                                   return $iconFileName;
                                    
                                   // $iconFileName = time().'_'.$icon_filename;  
                                    
                             }
                                
                            }
                                
                                
                            }
                            
                            //$iconFileName = $icon_filename; 
                                              
                            
                        }
                      
                     }else{
                         $iconFileName = $icon_filename;
                         return $iconFileName;
                     }
					
                       
                               
        }
        
		
		
		 /**
         * This is the function that removes an existing video file
         */
        public function removeTheExistingInsideImageFile($id){
            
            //retreve the existing zip file from the database
            
            if($this->isTheInsideImageNotTheDefault($id)){
                
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$id);
                $icon= Product::model()->find($criteria);
                
                //$directoryPath =  dirname(Yii::app()->request->scriptFile);
                $directoryPath = "../ecommerce_images/images/";
               // $iconpath = '..\appspace_assets\icons'.$icon['icon'];
                $filepath =$directoryPath.$icon['product_inside_view'];
                //$filepath = $directoryPath.$iconpath;
                
                if(unlink($filepath)){
                    return true;
                }else{
                    return false;
                }
                
            }else{
                return true;
            }
                
            
            
        }
        
	
        /**
         * This is the function that determines if  a tooltype icon is the default
         */
        public function isTheInsideImageNotTheDefault($id){
            
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$id);
                $icon= Product::model()->find($criteria);
                
                if($icon['product_inside_view'] ===NULL){
                    return false;
                }else{
                    return true;
                }
        }
		
		
		
		/**
         * This is the function to ascertain if a new icon was provided or not
         */
        public function noNewInsideImageFileProvided($id,$icon_filename){
            
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$id);
                $icon= Product::model()->find($criteria);
                
                if($icon['product_inside_view']==$icon_filename){
                    return true;
                }else{
                    return false;
                }
            
        }
        
        
        /**
         * This is the function that retrieves the previous icon of the task in question
         */
        public function retrieveThePreviousInsideImage($id){
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';   
            $criteria->params = array(':id'=>$id);
            $icon = Product::model()->find($criteria);
            
            
            return $icon['product_inside_view'];
         
        }
        
        
        
        
        //the product_back_view image
        
        
        /**
         * This is the function that moves icons to its directory
         */
        public function moveTheBackImageToItsPathAndReturnTheFilename($model,$icon_filename){
            
            if(isset($_FILES['product_back_view']['name'])){
                        $tmpName = $_FILES['product_back_view']['tmp_name'];
                        $iconName = $_FILES['product_back_view']['name'];    
                        $iconType = $_FILES['product_back_view']['type'];
                        $iconSize = $_FILES['product_back_view']['size'];
                  
                   }
                    
                    if($icon_filename !== null) {
                        if($model->id === null){
                          //$iconFileName = $icon_filename;  
                          if($icon_filename != NULL){
                                $iconFileName = time().'_'.$icon_filename;  
                            }else{
                                $iconFileName = $icon_filename;  
                            }  
                          
                           // upload the icon file
                        if($iconName !== NULL){
                            	$iconPath = Yii::app()->params['images'].$iconFileName;
				move_uploaded_file($tmpName,  $iconPath);
                                        
                        
                                return $iconFileName;
                        }else{
                            $iconFileName = $icon_filename;
                            return $iconFileName;
                        } // validate to save file
                        }else{
                            if($this->noNewBackImageFileProvided($model->id,$icon_filename)){
                                $iconFileName = $icon_filename; 
                                return $iconFileName;
                            }else{
                            if($icon_filename != NULL){
                                if($this->removeTheExistingBackImageFile($model->id)){
                                 $iconFileName = time().'_'.$icon_filename; 
                                 //$iconFileName = time().$icon_filename;  
                                   $iconPath = Yii::app()->params['images'].$iconFileName;
                                   move_uploaded_file($tmpName,$iconPath);
                                   return $iconFileName;
                                    
                                   // $iconFileName = time().'_'.$icon_filename;  
                                    
                             }
                                
                            }
                                
                                
                            }
                            
                            //$iconFileName = $icon_filename; 
                                              
                            
                        }
                      
                     }else{
                         $iconFileName = $icon_filename;
                         return $iconFileName;
                     }
					
                       
                               
        }
        
		
		
		 /**
         * This is the function that removes an existing video file
         */
        public function removeTheExistingBackImageFile($id){
            
            //retreve the existing zip file from the database
            
            if($this->isTheBackImageNotTheDefault($id)){
                
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$id);
                $icon= Product::model()->find($criteria);
                
                //$directoryPath =  dirname(Yii::app()->request->scriptFile);
                $directoryPath = "../ecommerce_images/images/";
               // $iconpath = '..\appspace_assets\icons'.$icon['icon'];
                $filepath =$directoryPath.$icon['product_back_view'];
                //$filepath = $directoryPath.$iconpath;
                
                if(unlink($filepath)){
                    return true;
                }else{
                    return false;
                }
                
            }else{
                return true;
            }
                
            
            
        }
        
	
        /**
         * This is the function that determines if  a tooltype icon is the default
         */
        public function isTheBackImageNotTheDefault($id){
            
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$id);
                $icon= Product::model()->find($criteria);
                
                if($icon['product_back_view'] ===NULL){
                    return false;
                }else{
                    return true;
                }
        }
		
		
		
		/**
         * This is the function to ascertain if a new icon was provided or not
         */
        public function noNewBackImageFileProvided($id,$icon_filename){
            
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$id);
                $icon= Product::model()->find($criteria);
                
                if($icon['product_back_view']==$icon_filename){
                    return true;
                }else{
                    return false;
                }
            
        }
        
        
        /**
         * This is the function that retrieves the previous icon of the task in question
         */
        public function retrieveThePreviousBackImage($id){
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';   
            $criteria->params = array(':id'=>$id);
            $icon = Product::model()->find($criteria);
            
            
            return $icon['product_back_view'];
         
        }
        
        
        
        
         //the product_left_side_view image
        
        
        /**
         * This is the function that moves icons to its directory
         */
        public function moveTheLeftImageToItsPathAndReturnTheFilename($model,$icon_filename){
            
            if(isset($_FILES['product_left_side_view']['name'])){
                        $tmpName = $_FILES['product_left_side_view']['tmp_name'];
                        $iconName = $_FILES['product_left_side_view']['name'];    
                        $iconType = $_FILES['product_left_side_view']['type'];
                        $iconSize = $_FILES['product_left_side_view']['size'];
                  
                   }
                    
                    if($icon_filename !== null) {
                        if($model->id === null){
                          //$iconFileName = $icon_filename;  
                          if($icon_filename != NULL){
                                $iconFileName = time().'_'.$icon_filename;  
                            }else{
                                $iconFileName = $icon_filename;  
                            }  
                          
                           // upload the icon file
                        if($iconName !== NULL){
                            	$iconPath = Yii::app()->params['images'].$iconFileName;
				move_uploaded_file($tmpName,  $iconPath);
                                        
                        
                                return $iconFileName;
                        }else{
                            $iconFileName = $icon_filename;
                            return $iconFileName;
                        } // validate to save file
                        }else{
                            if($this->noNewLeftImageFileProvided($model->id,$icon_filename)){
                                $iconFileName = $icon_filename; 
                                return $iconFileName;
                            }else{
                            if($icon_filename != NULL){
                                if($this->removeTheExistingLeftImageFile($model->id)){
                                 $iconFileName = time().'_'.$icon_filename; 
                                 //$iconFileName = time().$icon_filename;  
                                   $iconPath = Yii::app()->params['images'].$iconFileName;
                                   move_uploaded_file($tmpName,$iconPath);
                                   return $iconFileName;
                                    
                                   // $iconFileName = time().'_'.$icon_filename;  
                                    
                             }
                                
                            }
                                
                                
                            }
                            
                            //$iconFileName = $icon_filename; 
                                              
                            
                        }
                      
                     }else{
                         $iconFileName = $icon_filename;
                         return $iconFileName;
                     }
					
                       
                               
        }
        
		
		
		 /**
         * This is the function that removes an existing video file
         */
        public function removeTheExistingLeftImageFile($id){
            
            //retreve the existing zip file from the database
            
            if($this->isTheLeftImageNotTheDefault($id)){
                
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$id);
                $icon= Product::model()->find($criteria);
                
                //$directoryPath =  dirname(Yii::app()->request->scriptFile);
                $directoryPath = "../ecommerce_images/images/";
               // $iconpath = '..\appspace_assets\icons'.$icon['icon'];
                $filepath =$directoryPath.$icon['product_left_side_view'];
                //$filepath = $directoryPath.$iconpath;
                
                if(unlink($filepath)){
                    return true;
                }else{
                    return false;
                }
                
            }else{
                return true;
            }
                
            
            
        }
        
	
        /**
         * This is the function that determines if  a tooltype icon is the default
         */
        public function isTheLeftImageNotTheDefault($id){
            
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$id);
                $icon= Product::model()->find($criteria);
                
                if($icon['product_left_side_view'] ===NULL){
                    return false;
                }else{
                    return true;
                }
        }
		
		
		
		/**
         * This is the function to ascertain if a new icon was provided or not
         */
        public function noNewLeftImageFileProvided($id,$icon_filename){
            
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$id);
                $icon= Product::model()->find($criteria);
                
                if($icon['product_left_side_view']==$icon_filename){
                    return true;
                }else{
                    return false;
                }
            
        }
        
        
        /**
         * This is the function that retrieves the previous icon of the task in question
         */
        public function retrieveThePreviousLeftImage($id){
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';   
            $criteria->params = array(':id'=>$id);
            $icon = Product::model()->find($criteria);
            
            
            return $icon['product_left_side_view'];
         
        }
        
        
        
        
        
         //the product_bottom_view image
        
        
        /**
         * This is the function that moves icons to its directory
         */
        public function moveTheBottomImageToItsPathAndReturnTheFilename($model,$icon_filename){
            
            if(isset($_FILES['product_bottom_view']['name'])){
                        $tmpName = $_FILES['product_bottom_view']['tmp_name'];
                        $iconName = $_FILES['product_bottom_view']['name'];    
                        $iconType = $_FILES['product_bottom_view']['type'];
                        $iconSize = $_FILES['product_bottom_view']['size'];
                  
                   }
                    
                    if($icon_filename !== null) {
                        if($model->id === null){
                          //$iconFileName = $icon_filename;  
                          if($icon_filename != NULL){
                                $iconFileName = time().'_'.$icon_filename;  
                            }else{
                                $iconFileName = $icon_filename;  
                            }  
                          
                           // upload the icon file
                        if($iconName !== NULL){
                            	$iconPath = Yii::app()->params['images'].$iconFileName;
				move_uploaded_file($tmpName,  $iconPath);
                                        
                        
                                return $iconFileName;
                        }else{
                            $iconFileName = $icon_filename;
                            return $iconFileName;
                        } // validate to save file
                        }else{
                            if($this->noNewBottomImageFileProvided($model->id,$icon_filename)){
                                $iconFileName = $icon_filename; 
                                return $iconFileName;
                            }else{
                            if($icon_filename != NULL){
                                if($this->removeTheExistingBottomImageFile($model->id)){
                                 $iconFileName = time().'_'.$icon_filename; 
                                 //$iconFileName = time().$icon_filename;  
                                   $iconPath = Yii::app()->params['images'].$iconFileName;
                                   move_uploaded_file($tmpName,$iconPath);
                                   return $iconFileName;
                                    
                                   // $iconFileName = time().'_'.$icon_filename;  
                                    
                             }
                                
                            }
                                
                                
                            }
                            
                            //$iconFileName = $icon_filename; 
                                              
                            
                        }
                      
                     }else{
                         $iconFileName = $icon_filename;
                         return $iconFileName;
                     }
					
                       
                               
        }
        
		
		
		 /**
         * This is the function that removes an existing video file
         */
        public function removeTheExistingBottomImageFile($id){
            
            //retreve the existing zip file from the database
            
            if($this->isTheBottomImageNotTheDefault($id)){
                
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$id);
                $icon= Product::model()->find($criteria);
                
                //$directoryPath =  dirname(Yii::app()->request->scriptFile);
                $directoryPath = "../ecommerce_images/images/";
               // $iconpath = '..\appspace_assets\icons'.$icon['icon'];
                $filepath =$directoryPath.$icon['product_bottom_view'];
                //$filepath = $directoryPath.$iconpath;
                
                if(unlink($filepath)){
                    return true;
                }else{
                    return false;
                }
                
            }else{
                return true;
            }
                
            
            
        }
        
	
        /**
         * This is the function that determines if  a tooltype icon is the default
         */
        public function isTheBottomImageNotTheDefault($id){
            
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$id);
                $icon= Product::model()->find($criteria);
                
                if($icon['product_bottom_view'] ===NULL){
                    return false;
                }else{
                    return true;
                }
        }
		
		
		
		/**
         * This is the function to ascertain if a new icon was provided or not
         */
        public function noNewBottomImageFileProvided($id,$icon_filename){
            
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$id);
                $icon= Product::model()->find($criteria);
                
                if($icon['product_bottom_view']==$icon_filename){
                    return true;
                }else{
                    return false;
                }
            
        }
        
        
        /**
         * This is the function that retrieves the previous icon of the task in question
         */
        public function retrieveThePreviousBottonImage($id){
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';   
            $criteria->params = array(':id'=>$id);
            $icon = Product::model()->find($criteria);
            
            
            return $icon['product_bottom_view'];
         
        }
        
        
         /**
         * This is the function that determines the type and size of image file
         */
        public function isFrontImageTypeAndSizeLegal(){
            
           $size = []; 
            if(isset($_FILES['product_front_view']['name'])){
                $tmpName = $_FILES['product_front_view']['tmp_name'];
                $iconFileName = $_FILES['product_front_view']['name'];    
                $iconFileType = $_FILES['product_front_view']['type'];
                $iconFileSize = $_FILES['product_front_view']['size'];
            } 
           if (isset($_FILES['product_front_view'])) {
                $filename = $_FILES['product_front_view']['tmp_name'];
                list($width, $height) = getimagesize($filename);
           }
      
         
           if(($iconFileType == 'image/png'|| $iconFileType == 'image/jpg' || $iconFileType == 'image/jpeg')){
              if($width>=400 && $height>=400){
                   return true;
              }else{
                  return false;
              }
               
            }else{
                return false;
            }
            
        }
        
        
        
        /**
         * This is the function that determines the type and size of image file
         */
        public function isRightImageTypeAndSizeLegal(){
            
           $size = []; 
            if(isset($_FILES['product_right_side_view']['name'])){
                $tmpName = $_FILES['product_right_side_view']['tmp_name'];
                $iconFileName = $_FILES['product_right_side_view']['name'];    
                $iconFileType = $_FILES['product_right_side_view']['type'];
                $iconFileSize = $_FILES['product_right_side_view']['size'];
            } 
           if (isset($_FILES['product_right_side_view'])) {
                $filename = $_FILES['product_right_side_view']['tmp_name'];
                list($width, $height) = getimagesize($filename);
           }
      
         
           if(($iconFileType == 'image/png'|| $iconFileType == 'image/jpg' || $iconFileType == 'image/jpeg')){
              if($width>=400 && $height>=400){
                   return true;
              }else{
                  return false;
              }
               
            }else{
                return false;
            }
            
        }
        
        
        /**
         * This is the function that determines the type and size of image file
         */
        public function isTopImageTypeAndSizeLegal(){
            
           $size = []; 
            if(isset($_FILES['product_top_view']['name'])){
                $tmpName = $_FILES['product_top_view']['tmp_name'];
                $iconFileName = $_FILES['product_top_view']['name'];    
                $iconFileType = $_FILES['product_top_view']['type'];
                $iconFileSize = $_FILES['product_top_view']['size'];
            } 
           if (isset($_FILES['product_top_view'])) {
                $filename = $_FILES['product_top_view']['tmp_name'];
                list($width, $height) = getimagesize($filename);
           }
      
         
           if(($iconFileType == 'image/png'|| $iconFileType == 'image/jpg' || $iconFileType == 'image/jpeg')){
              if($width>=400 && $height>=400){
                   return true;
              }else{
                  return false;
              }
               
            }else{
                return false;
            }
            
        }
        
        
         /**
         * This is the function that determines the type and size of image file
         */
        public function isInsideImageTypeAndSizeLegal(){
            
           $size = []; 
            if(isset($_FILES['product_inside_view']['name'])){
                $tmpName = $_FILES['product_inside_view']['tmp_name'];
                $iconFileName = $_FILES['product_inside_view']['name'];    
                $iconFileType = $_FILES['product_inside_view']['type'];
                $iconFileSize = $_FILES['product_inside_view']['size'];
            } 
           if (isset($_FILES['product_inside_view'])) {
                $filename = $_FILES['product_inside_view']['tmp_name'];
                list($width, $height) = getimagesize($filename);
           }
      
         
           if(($iconFileType == 'image/png'|| $iconFileType == 'image/jpg' || $iconFileType == 'image/jpeg')){
              if($width>=400 && $height>=400){
                   return true;
              }else{
                  return false;
              }
               
            }else{
                return false;
            }
            
        }
        
        
        
        /**
         * This is the function that determines the type and size of image file
         */
        public function isBackImageTypeAndSizeLegal(){
            
           $size = []; 
            if(isset($_FILES['product_back_view']['name'])){
                $tmpName = $_FILES['product_back_view']['tmp_name'];
                $iconFileName = $_FILES['product_back_view']['name'];    
                $iconFileType = $_FILES['product_back_view']['type'];
                $iconFileSize = $_FILES['product_back_view']['size'];
            } 
           if (isset($_FILES['product_back_view'])) {
                $filename = $_FILES['product_back_view']['tmp_name'];
                list($width, $height) = getimagesize($filename);
           }
      
         
           if(($iconFileType == 'image/png'|| $iconFileType == 'image/jpg' || $iconFileType == 'image/jpeg')){
              if($width>=400 && $height>=400){
                   return true;
              }else{
                  return false;
              }
               
            }else{
                return false;
            }
            
        }
        
        
        
        
        /**
         * This is the function that determines the type and size of image file
         */
        public function isLeftImageTypeAndSizeLegal(){
            
           $size = []; 
            if(isset($_FILES['product_left_side_view']['name'])){
                $tmpName = $_FILES['product_left_side_view']['tmp_name'];
                $iconFileName = $_FILES['product_left_side_view']['name'];    
                $iconFileType = $_FILES['product_left_side_view']['type'];
                $iconFileSize = $_FILES['product_left_side_view']['size'];
            } 
           if (isset($_FILES['product_left_side_view'])) {
                $filename = $_FILES['product_left_side_view']['tmp_name'];
                list($width, $height) = getimagesize($filename);
           }
      
         
           if(($iconFileType == 'image/png'|| $iconFileType == 'image/jpg' || $iconFileType == 'image/jpeg')){
              if($width>=400 && $height>=400){
                   return true;
              }else{
                  return false;
              }
               
            }else{
                return false;
            }
            
        }
        
        
        
        /**
         * This is the function that determines the type and size of image file
         */
        public function isBottomImageTypeAndSizeLegal(){
            
           $size = []; 
            if(isset($_FILES['product_bottom_view']['name'])){
                $tmpName = $_FILES['product_bottom_view']['tmp_name'];
                $iconFileName = $_FILES['product_bottom_view']['name'];    
                $iconFileType = $_FILES['product_bottom_view']['type'];
                $iconFileSize = $_FILES['product_bottom_view']['size'];
            } 
           if (isset($_FILES['product_bottom_view'])) {
                $filename = $_FILES['product_bottom_view']['tmp_name'];
                list($width, $height) = getimagesize($filename);
           }
      
         
           if(($iconFileType == 'image/png'|| $iconFileType == 'image/jpg' || $iconFileType == 'image/jpeg')){
              if($width>=400 && $height>=400){
                   return true;
              }else{
                  return false;
              }
               
            }else{
                return false;
            }
            
        }
        
        
       /**
         * This is the function that confirms if the removal of a country name is a success
         */
        public function isTheRemovalOfProductImagesASuccess($id){
            $counter = 0;
            if($this->isThisProductWithIcon($id)){
                if($this->removeTheExistingIconFile($id)){
                    $counter = $counter + 1;
                }
                         
            }else{
                $counter = $counter + 1;
            }
            
            
            if($this->isThisProductWithFrontImage($id)){
                if($this->removeTheExistingFrontImageFile($id)){
                    $counter = $counter + 1;
                }
                         
            }else{
                $counter = $counter + 1;
            }
            
            
            if($this->isThisProductWithRightImage($id)){
                if($this->removeTheExistingRightImageFile($id)){
                    $counter = $counter + 1;
                }
                         
            }else{
                $counter = $counter + 1;
            }
            
            
            
             if($this->isThisProductWithTopImage($id)){
                if($this->removeTheExistingTopImageFile($id)){
                    $counter = $counter + 1;
                }
                         
            }else{
                $counter = $counter + 1;
            }
            
            
            if($this->isThisProductWithInsideImage($id)){
                if($this->removeTheExistingInsideImageFile($id)){
                    $counter = $counter + 1;
                }
                         
            }else{
                $counter = $counter + 1;
            }
            
            
            
            if($this->isThisProductWithBackImage($id)){
                if($this->removeTheExistingBackImageFile($id)){
                    $counter = $counter + 1;
                }
                         
            }else{
                $counter = $counter + 1;
            }
            
            
             if($this->isThisProductWithLeftImage($id)){
                if($this->removeTheExistingLeftImageFile($id)){
                    $counter = $counter + 1;
                }
                         
            }else{
                $counter = $counter + 1;
            }
            
            
            
            if($this->isThisProductWithBottomImage($id)){
                if($this->removeTheExistingBottomImageFile($id)){
                    $counter = $counter + 1;
                }
                         
            }else{
                $counter = $counter + 1;
            }
            
            return $counter;
            
        }
        
        
        
        
        /**
         * This is the function that confirms if a product right image was exist
         */
        public function isThisProductWithBottomImage($id){
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$id);
            $product = Product::model()->find($criteria); 
            
            if($product['product_bottom_view']==NULL){
                return false;
            }else{
                return true;
            }
        }
        
        
        
        
         /**
         * This is the function that confirms if a product right image was exist
         */
        public function isThisProductWithLeftImage($id){
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$id);
            $product = Product::model()->find($criteria); 
            
            if($product['product_left_side_view']==NULL){
                return false;
            }else{
                return true;
            }
        }
        
        
        
         /**
         * This is the function that confirms if a product right image was exist
         */
        public function isThisProductWithBackImage($id){
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$id);
            $product = Product::model()->find($criteria); 
            
            if($product['product_back_view']==NULL){
                return false;
            }else{
                return true;
            }
        }
        
         /**
         * This is the function that confirms if a product right image was exist
         */
        public function isThisProductWithInsideImage($id){
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$id);
            $product = Product::model()->find($criteria); 
            
            if($product['product_inside_view']==NULL){
                return false;
            }else{
                return true;
            }
        }
        
        
        
        /**
         * This is the function that confirms if a product right image was exist
         */
        public function isThisProductWithTopImage($id){
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$id);
            $product = Product::model()->find($criteria); 
            
            if($product['product_top_view']==NULL){
                return false;
            }else{
                return true;
            }
        }
        
        
        
        
         /**
         * This is the function that confirms if a product right image was exist
         */
        public function isThisProductWithRightImage($id){
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$id);
            $product = Product::model()->find($criteria); 
            
            if($product['product_right_side_view']==NULL){
                return false;
            }else{
                return true;
            }
        }
        
        
        
         /**
         * This is the function that confirms if a product front image was exist
         */
        public function isThisProductWithFrontImage($id){
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$id);
            $product = Product::model()->find($criteria); 
            
            if($product['product_front_view']==NULL){
                return false;
            }else{
                return true;
            }
        }
        
        
        
        
        /**
         * This is the function that confirms if a product icon was exist
         */
        public function isThisProductWithIcon($id){
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$id);
            $product = Product::model()->find($criteria); 
            
            if($product['icon']==NULL){
                return false;
            }else{
                return true;
            }
        }
        
        
        /**
         * This is the function that retrieves a merchant id of a user
         */
        public function getTheMerchantIdOfThisUser($user_id){
            $model = new User;
            return $model->getTheMerchantIdOfThisUser($user_id);
        }
        
        
        /**
         * This is the function that retrieves the category id of a product
         */
        public function getTheCategoryIdOfThisProduct($product_id){
            $model = new SubCategory;
            //get the product type of this product
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$product_id);
            $product = Product::model()->find($criteria); 
            
            //get the subcategory
            
            $sub_id = $this->getTheSubcategoryOfThisProductType($product['product_type_id']);
            
            //return the category id of this subcategory
            
            return $model->getTheCategoryIdOfThisSucategory($sub_id);
            
            
        }
        
        
        /**
         * This is the function that gets the subcategory of a product type
         */
        public function getTheSubcategoryOfThisProductType($product_type_id){
            $model = new ProductType;
            return $model->getTheSubcategoryOfThisProductType($product_type_id);
        }
        
        
        /**
         * This is the function that gets the classification of a product
         */
        public function getTheClassificationOfThisProduct($product_id){
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$product_id);
            $product = Product::model()->find($criteria); 
            
            return $product['classification_id'];
            
        }
       
        
        /**
         * This is the function that confirms if a product belongs to a merchant
         */
        public function isThisOrderItemForThisMerchant($product_id,$merchant_id){
            $cmd =Yii::app()->db->createCommand();
                $cmd->select('COUNT(*)')
                    ->from('product')
                    ->where("id =$product_id and merchant_id=$merchant_id");
                $result = $cmd->queryScalar();
                
                if($result>0){
                    return true;
                }else{
                    return false;
                }
        }
        
        
        /**
         * This is the function that confirms if  product images are unique
         */
        public function areTheProductImagesUnique($icon,$product_front_view,$product_right_side_view,$product_top_view,$product_inside_view,$product_back_view,$product_left_side_view,$product_bottom_view){
           $error_counter = 0; 
            if($this->isIconImageUnique($icon,$product_front_view,$product_right_side_view,$product_top_view,$product_inside_view,$product_back_view,$product_left_side_view,$product_bottom_view) == false){
                $error_counter = $error_counter + 1;
            }
            
            if($this->isProductFrontViewImageUnique($icon,$product_front_view,$product_right_side_view,$product_top_view,$product_inside_view,$product_back_view,$product_left_side_view,$product_bottom_view) == false){
                 $error_counter = $error_counter + 1;
            }
            
            if($this->isProductRightSideViewImageUnique($icon,$product_front_view,$product_right_side_view,$product_top_view,$product_inside_view,$product_back_view,$product_left_side_view,$product_bottom_view) == false){
                $error_counter = $error_counter + 1;
            }
            
            if($this->isProductTopViewImageUnique($icon,$product_front_view,$product_right_side_view,$product_top_view,$product_inside_view,$product_back_view,$product_left_side_view,$product_bottom_view) == false){
                $error_counter = $error_counter + 1;
            }
            
            if($this->isProductInsideViewImageUnique($icon,$product_front_view,$product_right_side_view,$product_top_view,$product_inside_view,$product_back_view,$product_left_side_view,$product_bottom_view)== false){
                $error_counter = $error_counter + 1;
            }
            
            if($this->isProductBackViewImageUnique($icon,$product_front_view,$product_right_side_view,$product_top_view,$product_inside_view,$product_back_view,$product_left_side_view,$product_bottom_view) == false){
                 $error_counter = $error_counter + 1;
            }
            
            if($this->isProductLeftSideViewImageUnique($icon,$product_front_view,$product_right_side_view,$product_top_view,$product_inside_view,$product_back_view,$product_left_side_view,$product_bottom_view) == false){
                $error_counter = $error_counter + 1;
            }
            
            if($this->isProductBottomViewImageUnique($icon,$product_front_view,$product_right_side_view,$product_top_view,$product_inside_view,$product_back_view,$product_left_side_view,$product_bottom_view) == false){
                $error_counter = $error_counter + 1;
            }
            
            if($error_counter == 0){
                return true;
            }else{
                return false;
            }
            
        }
        
        
        /**
         * This is the function that confirms that icon image is unique
         */
        public function isIconImageUnique($icon,$product_front_view,$product_right_side_view,$product_top_view,$product_inside_view,$product_back_view,$product_left_side_view,$product_bottom_view){
           
          if($icon == null){
              return true;
          }else if($icon == ""){
              return true;
          }else if("$icon" == "$product_front_view"){
                return false;
            }else if("$icon" =="$product_right_side_view"){
                return false;
            }else if("$icon" =="$product_top_view"){
                return false;
            }else if("$icon" =="$product_inside_view"){
                return false;
            }else if("$icon" =="$product_back_view"){
                return false;
            }else if("$icon" =="$product_left_side_view"){
                return false;
            }else if("$icon" =="$product_bottom_view"){
                return false;
            }else{
                return true;
            }
        }
        
        
        
        /**
         * This is the function that confirms that product_front_view image is unique
         */
        public function isProductFrontViewImageUnique($icon,$product_front_view,$product_right_side_view,$product_top_view,$product_inside_view,$product_back_view,$product_left_side_view,$product_bottom_view){
            
          if($product_front_view == null){
              return true;
          }else if($product_front_view == ""){
              return true;
          }else if("$icon" == "$product_front_view"){
                return false;
            }else if("$product_front_view" =="$product_right_side_view"){
                return false;
            }else if("$product_front_view" =="$product_top_view"){
                return false;
            }else if("$product_front_view" =="$product_inside_view"){
                return false;
            }else if("$product_front_view" =="$product_back_view"){
                return false;
            }else if("$product_front_view" =="$product_left_side_view"){
                return false;
            }else if("$product_front_view" =="$product_bottom_view"){
                return false;
            }else{
                return true;
            }
        }
        
        
         /**
         * This is the function that confirms that product_right_side_view image is unique
         */
        public function isProductRightSideViewImageUnique($icon,$product_front_view,$product_right_side_view,$product_top_view,$product_inside_view,$product_back_view,$product_left_side_view,$product_bottom_view){
            
           if($product_right_side_view == null){
              return true;
          }else if($product_right_side_view == ""){
              return true;
          }else if("$icon" == "$product_right_side_view"){
                return false;
            }else if("$product_front_view" =="$product_right_side_view"){
                return false;
            }else if("$product_right_side_view" =="$product_top_view"){
                return false;
            }else if("$product_right_side_view" =="$product_inside_view"){
                return false;
            }else if("$product_right_side_view" =="$product_back_view"){
                return false;
            }else if("$product_right_side_view" =="$product_left_side_view"){
                return false;
            }else if("$product_right_side_view" =="$product_bottom_view"){
                return false;
            }else{
                return true;
            }
        }
        
        
        
        /**
         * This is the function that confirms that product_top_view image is unique
         */
        public function isProductTopViewImageUnique($icon,$product_front_view,$product_right_side_view,$product_top_view,$product_inside_view,$product_back_view,$product_left_side_view,$product_bottom_view){
            
          if($product_top_view == null){
              return true;
          }else if($product_top_view == ""){
              return true;
          }else if("$icon" == "$product_top_view"){
                return false;
            }else if("$product_front_view" =="$product_top_view"){
                return false;
            }else if("$product_right_side_view" =="$product_top_view"){
                return false;
            }else if("$product_top_view" =="$product_inside_view"){
                return false;
            }else if("$product_top_view" =="$product_back_view"){
                return false;
            }else if("$product_top_view" =="$product_left_side_view"){
                return false;
            }else if("$product_top_view" =="$product_bottom_view"){
                return false;
            }else{
                return true;
            }
        }
        
        
         /**
         * This is the function that confirms that product_inside_view image is unique
         */
        public function isProductInsideViewImageUnique($icon,$product_front_view,$product_right_side_view,$product_top_view,$product_inside_view,$product_back_view,$product_left_side_view,$product_bottom_view){
            
           if($product_inside_view == null){
              return true;
          }else if($product_inside_view == ""){
              return true;
          }else if("$icon" == "$product_inside_view"){
                return false;
            }else if("$product_front_view" =="$product_inside_view"){
                return false;
            }else if("$product_right_side_view" =="$product_inside_view"){
                return false;
            }else if("$product_top_view" =="$product_inside_view"){
                return false;
            }else if("$product_inside_view" =="$product_back_view"){
                return false;
            }else if("$product_inside_view" =="$product_left_side_view"){
                return false;
            }else if("$product_inside_view" =="$product_bottom_view"){
                return false;
            }else{
                return true;
            }
        }
        
        
        
         /**
         * This is the function that confirms that product_back_view image is unique
         */
        public function isProductBackViewImageUnique($icon,$product_front_view,$product_right_side_view,$product_top_view,$product_inside_view,$product_back_view,$product_left_side_view,$product_bottom_view){
            
          if($product_back_view == null){
              return true;
          }else if($product_back_view == ""){
              return true;
          }else if("$icon" == "$product_back_view"){
                return false;
            }else if("$product_front_view" =="$product_back_view"){
                return false;
            }else if("$product_right_side_view" =="$product_back_view"){
                return false;
            }else if("$product_top_view" =="$product_back_view"){
                return false;
            }else if("$product_inside_view" =="$product_back_view"){
                return false;
            }else if("$product_back_view" =="$product_left_side_view"){
                return false;
            }else if("$product_back_view" =="$product_bottom_view"){
                return false;
            }else{
                return true;
            }
        }
        
        
        
         /**
         * This is the function that confirms that product_left_side_view image is unique
         */
        public function isProductLeftSideViewImageUnique($icon,$product_front_view,$product_right_side_view,$product_top_view,$product_inside_view,$product_back_view,$product_left_side_view,$product_bottom_view){
            
            if($product_left_side_view == null){
              return true;
          }else if($product_left_side_view == ""){
              return true;
          }else if("$icon" == "$product_left_side_view"){
                return false;
            }else if("$product_front_view" =="$product_left_side_view"){
                return false;
            }else if("$product_right_side_view" =="$product_left_side_view"){
                return false;
            }else if("$product_top_view" =="$product_left_side_view"){
                return false;
            }else if("$product_inside_view" =="$product_left_side_view"){
                return false;
            }else if("$product_back_view" =="$product_left_side_view"){
                return false;
            }else if("$product_left_side_view" =="$product_bottom_view"){
                return false;
            }else{
                return true;
            }
        }
        
        
        
        /**
         * This is the function that confirms that product_bottom_view image is unique
         */
        public function isProductBottomViewImageUnique($icon,$product_front_view,$product_right_side_view,$product_top_view,$product_inside_view,$product_back_view,$product_left_side_view,$product_bottom_view){
            
         if($product_bottom_view == null){
              return true;
          }else if($product_bottom_view == ""){
              return true;
          }else if("$icon" == "$product_bottom_view"){
                return false;
            }else if("$product_front_view" =="$product_bottom_view"){
                return false;
            }else if("$product_right_side_view" =="$product_bottom_view"){
                return false;
            }else if("$product_top_view" =="$product_bottom_view"){
                return false;
            }else if("$product_inside_view" =="$product_bottom_view"){
                return false;
            }else if("$product_back_view" =="$product_bottom_view"){
                return false;
            }else if("$product_left_side_view" =="$product_bottom_view"){
                return false;
            }else{
                return true;
            }
        }
        
        
        /**
         * This is the function that retrieves all classifications of products unders a category
         */
        public function getAllProductsClassificationForThisCategory($category){
            $target = [];
            //get all products in this category
            $products = $this->AllProductsInThisCategory($category);
            
            foreach($products as $prod){
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$prod);
                $product = Product::model()->find($criteria); 
            
                $target[] =  $product['classification'];
                
            }
            return array_unique($target);
            
            
        }
        
        
         /**
         * This is the function that retrieves all classifications of products unders a category
         */
        public function getAllProductsClassificationForThisCategoryForNgadi($category){
            $target = [];
            //get all products in this category
            $products = $this->AllProductsInThisCategoryForNgadi($category);
            
            foreach($products as $prod){
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$prod);
                $product = Product::model()->find($criteria); 
            
                $target[] =  $product['classification'];
                
            }
            return array_unique($target);
            
            
        }
        
        
        //This is the function that gets a products in a a category
        public function AllProductsInThisCategory($category){
            $model = new SubCategory;
            $target = [];
            
            $subcategories = $model->getAllSubcategoriesOfThisCategory($category);
            
            foreach($subcategories as $subcat){
                
                $producttypes = $this->getAllProductTypesOfThisSubcategory($subcat);
                
                foreach($producttypes as $type){
                    $criteria = new CDbCriteria();
                    $criteria->select = '*';
                    $criteria->condition='product_type_id=:type_id';
                    $criteria->params = array(':type_id'=>$type);
                    $products = Product::model()->findAll($criteria); 
                    
                    foreach($products as $prod){
                        $target[] = $prod['id'];
                        
                    }
                    
                }
                
            }
            
            return array_unique($target);
            
        }
        
        
         //This is the function that gets a products in a a category
        public function AllProductsInThisCategoryForNgadi($category){
            $model = new SubCategory;
            $target = [];
            
            $subcategories = $model->getAllSubcategoriesOfThisCategoryForNgadi($category);
            
            foreach($subcategories as $subcat){
                
                $producttypes = $this->getAllProductTypesOfThisSubcategory($subcat);
                
                foreach($producttypes as $type){
                    $criteria = new CDbCriteria();
                    $criteria->select = '*';
                    $criteria->condition='product_type_id=:type_id';
                    $criteria->params = array(':type_id'=>$type);
                    $products = Product::model()->findAll($criteria); 
                    
                    foreach($products as $prod){
                        $target[] = $prod['id'];
                        
                    }
                    
                }
                
            }
            
            return array_unique($target);
            
        }
        
        
        /**
         * This is the function that gets all product types of a subcategory 
         */
        public function getAllProductTypesOfThisSubcategory($subcat_id){
            $model = new ProductType;
            return $model->getAllProductTypesOfThisSubcategory($subcat_id);
            
        }
        
        
        
         /**
         * This is the function that retrieves all classifications of products unders a product type
         */
        public function getAllProductsClassificationForThisType($type){
            $target = [];
            //get all products in this category
            $products = $this->allProductsInThisProductType($type);
            
            foreach($products as $prod){
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$prod);
                $product = Product::model()->find($criteria); 
            
                $target[] =  $product['classification'];
                
            }
            return array_unique($target);
            
            
        }
        
        
        //This is the function that gets a products in a product type
        public function allProductsInThisProductType($type){
            $model = new SubCategory;
            $target = [];
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='product_type_id=:type_id';
            $criteria->params = array(':type_id'=>$type);
            $products = Product::model()->findAll($criteria); 
                    
            foreach($products as $prod){
                        $target[] = $prod['id'];
                        
                    }
                    
            
            return array_unique($target);
            
        }
        
        
        /**
         * This is the function that confirms if a product type has products
         */
        public function isProductTypeWithProducts($type_id){
            $cmd =Yii::app()->db->createCommand();
                $cmd->select('COUNT(*)')
                    ->from('product')
                    ->where("product_type_id =$type_id");
                $result = $cmd->queryScalar();
                
                if($result>0){
                    return true;
                }else{
                    return false;
                }
        }
        
        
         /**
         * This is the function that confirms if a product classification has products
         */
        public function isThisClassificationWithProducts($classification){
            $cmd =Yii::app()->db->createCommand();
                $cmd->select('COUNT(*)')
                    ->from('product')
                    ->where("classification ='$classification'");
                $result = $cmd->queryScalar();
                
                if($result>0){
                    return true;
                }else{
                    return false;
                }
        }
}


