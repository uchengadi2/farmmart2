# ext-theme-neptune-bc3ee7c3-0ab4-4298-a6a3-15f3446dcabb/resources

This folder contains static resources (typically an `"images"` folder as well).
