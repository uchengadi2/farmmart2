# ext-theme-neptune-446f4bbe-6932-4ba8-a2d9-78826a291345/resources

This folder contains static resources (typically an `"images"` folder as well).
