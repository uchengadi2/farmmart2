# ext-theme-neptune-006af4bc-75b5-43c4-8616-22c55ce1a5ac/resources

This folder contains static resources (typically an `"images"` folder as well).
